#!/usr/bin/env python3
"""Read-only audit of the submitted 0.112 screen/certificate results.
Does NOT open production bank NPZs or reevaluate physical quantities.
Recomputes exact-count arithmetic and certificate over supplied evidence.
"""
import argparse, ast, copy, hashlib, itertools, json, math, os, sys, zipfile
from pathlib import Path
from fractions import Fraction
from collections import Counter
ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);ap.add_argument('--input-dir',type=Path,default=Path('/mnt/data'));a=ap.parse_args()
w=a.work.resolve(); src=w/'source/phaseB'; raw=w/'raw'; out=w/'results';out.mkdir(exist_ok=True)
sys.path.insert(0,str(src));sys.dont_write_bytecode=True
from step1_engine import serialization as ser
from step1_engine.infeasibility import check_screen_record,bind_screen_record,check_certificate,blocking_rows_from_screen,infeasibility_certificate,typed_equal,wilson_blocking_count
from step1_engine.d3_profile import twelve_context
from step1_engine.d4c0_registry import load_registered_w2_context,load_registered_pseudo_columns
from step1_engine.checkpoint import binding_manifest
from step1_engine.official_gate import _blas_check
from step1_engine.calibration import any_family_truth,calibrate
from step1_engine.truth import UNKNOWN,TECH

def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def desc(p):return {'sha256':sha(p),'bytes':Path(p).stat().st_size}
def tree_map(p):return {str(q.relative_to(p)):desc(q) for q in sorted(p.rglob('*')) if q.is_file()}
initial={'source':tree_map(src),'raw':tree_map(raw),'screens':tree_map(w/'screens')}
checks=[]
def ck(n,x):
 ok=bool(x);checks.append({'check':n,'ok':ok})
 if not ok:raise AssertionError(n)
def eq(n,x,y):ck(n,typed_equal(x,y))
plan=load(a.input_dir/'D4C2_screen_certificate_0.112.0_execution_decision.json');fixed=plan['fixed_source']; settings=plan['settings'];fm=load(raw/'file_map.json')
ck('execution_decision_hash',sha(a.input_dir/'D4C2_screen_certificate_0.112.0_execution_decision.json')==fm['decision_basis']['sha256'])
ck('outer_report_identical', (raw/'D4C2_screen_certificate_report.md').read_bytes()==(a.input_dir/'D4C2_screen_certificate_report.md').read_bytes())
ck('outer_file_map_complete',set(fm['files'])==set(initial['raw'])-{'file_map.json','D4C2_screen_certificate_report.md'})
for p,d in fm['files'].items():eq('outer/'+p,desc(raw/p),d)
ck('source_zip_fixed',sha(a.input_dir/'phaseB_D4C2a_v5_0.112.0.zip')==fixed['source_zip']['sha256'])
for p,key in [('B2_completion_inventory.json','inventory'),('d/d3_pins.json','pins'),('d/d4c1_calibration.py','script'),('d/MirrorTopology_Step1_D4C2_screen_v0.1.ipynb','screen_notebook')]:ck('fixed/'+p,sha(src/p)==fixed[key]['sha256'])
inv=load(src/'B2_completion_inventory.json'); inv_count=0
for name,prefix in [('modules','step1_engine'),('tests_sha256','tests'),('fixtures_sha256','tests'),('assets_sha256',''),('documents_sha256',''),('b3_sha256',''),('registered_assets_sha256',''),('d_sha256','')]:
 for p,h in inv[name].items():
  if sha(src/prefix/p)!=h:raise AssertionError('inventory '+name+' '+p)
  inv_count+=1
ck('all_inventory_entries',inv_count==2237)
pins=load(src/'d/d3_pins.json');dt=ast.parse((src/'d/d4c1_calibration.py').read_text());req={}
for n in dt.body:
 if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('REQUIRED_SCREEN','REQUIRED_CERTIFICATE'):req[n.targets[0].id]=list(ast.literal_eval(n.value))
ctx=twelve_context(str(src)); ids=ctx.identities; w2=load_registered_w2_context(str(src),ctx); cols=load_registered_pseudo_columns(str(src),ctx)
wc=w2[0]; dec={k:wc.decision_for(k,wc.context_sha256) for k in wc.decisions};pid={'n':cols['n'],'sha256_T1':cols['identity']['T1_sha256'],'sha256_T2':cols['identity']['T2_sha256']}
ledger=load(src/'registered_assets/d2/d2_generation_ledger.json'); current_binding=binding_manifest(); baseline_nb=load(src/'d/MirrorTopology_Step1_D4C2_screen_v0.1.ipynb')
metrics={}; screens={};runs={}; allmaps=[];known_flags=['D4C1_PARTIAL_PASS','D4C1_COMBINE_PASS','D4C1_SUBPARTIAL_PASS','D4C1_SCREEN_COMPLETE','D4C1_CERTIFICATE_COMPLETE']; ordering=[]
raw_rates=0;raw_envelopes=0;mixed_choices=0
for F in ('E2','E7','E8'):
 sd=w/'screens'/F;info=fm['screens'][F];att=info['attempt'];rd=sd/('run_'+att);lp=sd/'d4c1_screen_lock.json';fp=sd/'d4c1_screen_final_record.json';rp=rd/f'd4c1_screen_{F}_run.json';sp=rd/f'd4c1_screen_{F}_record.json'
 L,Rf,R,S=map(load,(lp,fp,rp,sp));screens[F]=S;runs[F]=R;ordering.append((Rf['started_utc'],Rf['finished_utc']))
 eq(F+'/inner_map',tree_map(sd),info['members'])
 eq(F+'/lock_copy',Rf['lock'],L);ck(F+'/lock_SHA',sha(lp)==Rf['lock_sha256']==R['attempt']['launcher_lock_sha256'])
 ck(F+'/attempt',att==R['attempt']['attempt_id']==Rf['attempt_id']==Path(Rf['run_dir']).name.removeprefix('run_'))
 eq(F+'/run_directory',Rf['run_dir'],R['out']);ck(F+'/run_sha',sha(rp)==Rf['record_sha256'])
 for k,v in [('commit',fixed['commit']),('engine','0.112.0'),('family',F),('row_range',None),('stage_local',True),('stage_root','/content/stage'),('campaign_id',settings['common_editable_cell']['CAMPAIGN_ID']),('target_commitment',settings['common_editable_cell']['TARGET_COMMITMENT']),('out_root',settings['common_editable_cell']['OUT_ROOT']),('d2_run_root',settings['family_editable_cells'][F]['D2_RUN_ROOT'])]:eq(F+'/lock/'+k,L[k],v)
 for k,v in [('inventory_sha256',sha(src/'B2_completion_inventory.json')),('script_sha256',sha(src/'d/d4c1_calibration.py')),('pins_sha256',sha(src/'d/d3_pins.json'))]:ck(F+'/source/'+k,L[k]==R['source'][k]==v)
 eq(F+'/engine',R['engine_version'],'0.112.0');ck(F+'/pins_top',R['pins_sha256']==sha(src/'d/d3_pins.json'))
 ck(F+'/registered_assets_map', all(sha(src/p)==h and inv['registered_assets_sha256'][p]==h for p,h in L['registered_assets_sha256'].items()))
 for b in ('live_source_precheck','live_source_prelaunch'):
  obs=Rf['bindings'][b];ck(F+'/'+b,obs['head']==L['commit'] and obs['clean'] is True and all(typed_equal(obs[k],L[k]) for k in ('inventory_sha256','script_sha256','inventory_script_sha256','pins_sha256','registered_assets_sha256','engine')))
 for k in ('screen_complete','D4C1_SCREEN_COMPLETE','gates_ok','bindings_ok','evidence_ok'):eq(F+'/final/'+k,Rf[k],True)
 for k,v in [('stage','complete'),('exit_code',0),('launcher_fallback',False),('failures',[]),('exception',None)]:eq(F+'/final/'+k,Rf[k],v)
 ck(F+'/RAM',Rf['ram']['total_bytes']>40000000000)
 for k,v in [('schema','d4c1_run_record_v1'),('mode','screen'),('family',F),('stage','complete'),('failures',[]),('selftest',False),('formal',True),('probe',False),('probe_n',None),('row_range',None),('instrument',False),('profile','production_official')]:eq(F+'/run/'+k,R[k],v)
 eq(F+'/required_inventory',R['required_inventory'],req['REQUIRED_SCREEN']);ck(F+'/gate_set',set(R['gates'])==set(req['REQUIRED_SCREEN']) and all(v is True for v in R['gates'].values()) and R['required_all_true'] is True);eq(F+'/final_gate_copy',Rf['gates'],R['gates'])
 ck(F+'/flags',all(R[k] is (k=='D4C1_SCREEN_COMPLETE') for k in known_flags))
 ck(F+'/env',all(R['env'][k]==settings['environment'][k]==pins['environment'][k] for k in ('python','numpy','scipy','healpy','camb','pot')) and _blas_check(R['env']['blas_threads']))
 eq(F+'/context',R['context_identities'],ids);eq(F+'/pseudo_identity',R['pseudo']['identity'],cols['identity']);ck(F+'/W2_SHA',R['w2_context']['context_sha256']==wc.context_sha256==S['w2_context_sha256'])
 for k,v in current_binding.items():eq(F+'/binding/'+k,S['binding'][k],v)
 eq(F+'/publication',R['published_evidence'],{sp.name:desc(sp)})
 le=ledger['families'][F];ir=R['inputs']['d2'];ck(F+'/registered_run',ir['run_id']==le['run_id'] and ir['run_root']==le['run_root'] and ir['commit']==le['commit'] and ir['registry_sha256']==le['records']['bank_registry_sha256'])
 ck(F+'/staging_root',ir['root']==Rf['staged_inputs']['d2']=='/content/stage/d2');ck(F+'/no_d3b_input',R['inputs']['d3b']=={} and R['inputs']['resolution_failures']==[])
 ck(F+'/supplies_scope',set(R['supplies'])=={f'{c}/{sys_}' for c in le['configuration_ids'] for sys_ in ('matched','native')})
 for label,sup in R['supplies'].items():
  c=int(label.split('/')[0]);m=sup['manifests'];u=le['units']
  expected={'eval':{str(b):u[f'cfg{c}_b{b}']['manifest_sha256'] for b in (0,1)},'ref':{str(b):u[f'ref_{F}_b{b}']['manifest_sha256'] for b in (0,1)},'fit':u[f'cfg{c}_fit']['manifest_sha256'],'ref_fit':u[f'ref_{F}_fit']['manifest_sha256']}
  eq(F+'/manifests/'+label,m,expected);eq(F+'/clusters/'+label,sup['n_clusters'],{'0':10000,'1':30000});eq(F+'/fitting/'+label,sup['fitting_clusters'],2000)
 cfg={}
 for c in ctx.d2_spec['configurations'].values():
  if c['family']==F:cfg.setdefault(c['size_id'],[]).append(c['config_id'])
 b=bind_screen_record(S,registry_sha256=ids['registry_sha256'],manifest_sha256=ids['manifest_sha256'],w2_context_sha256=wc.context_sha256,w2_decisions=dec,pseudo_identity=pid,T1=cols['T1'],T2=cols['T2'],config_ids=cfg,family=F,campaign_id=R['campaign_id'],target_commitment=R['target_commitment'])
 ck(F+'/registered_screen_bind',b['ok'] and b['bound']);eq(F+'/row_inventory',S['rows'],list(range(2000)));ck(F+'/rows_number',len(S['results'])==S['n_rows']==2000)
 maxratio=0.;minp=1.;max_by_size={s:0. for s in S['sizes']};minhits=10**9
 for idx,x in enumerate(S['results']):
  assert type(x['row']) is int and x['row']==idx
  assert x['threshold']==[float(cols['T1'][idx]),float(cols['T2'][idx])]
  assert set(x['sizes'])==set(S['sizes']);row_block=True
  for sn,z in x['sizes'].items():
   assert set(z['positions'])=={'1','2','3'};rates=[];fvals=[];pair=[]
   for pos,p in z['positions'].items():
    assert type(p['evaluation_id']) is int and p['evaluation_id'] in cfg[sn] and p['evaluation_id']%100==int(pos)
    assert p['bank_stages']==['N0','N4'] and list(p['stages'])==['N0','N4'];vals=[]
    for st,n in [('N0',1000000),('N4',4000000)]:
     q=p['stages'][st];h=q['hits'];assert type(h) is int and type(q['N']) is int and q['N']==n and 0<h<=n
     val=h/n;assert type(q['P']) is float and q['P']==val
     rates.append(val);vals.append(val);fvals.append(Fraction(h,n));raw_rates+=1;minhits=min(minhits,h)
    h0=p['stages']['N0']['hits'];h4=p['stages']['N4']['hits'];assert 0<=h4-h0<=3000000
    pair.append(vals)
   lo,hi=min(rates),max(rates);rb=hi/lo
   assert z['min_P']==lo and z['max_P']==hi and z['ratio_bound']==rb
   assert z['all_positive'] is True and z['ok'] is True and rb<=2 and z['complete_coverage'] is True
   assert max(fvals)<=2*min(fvals)  # integer/rational cross-check, no scientific tolerance
   for combo in itertools.product(*pair):
    assert max(combo)/min(combo)<=rb<=2;mixed_choices+=1
   raw_envelopes+=1;maxratio=max(maxratio,rb);max_by_size[sn]=max(max_by_size[sn],rb);minp=min(minp,lo)
  assert x['blocking'] is True and x['complete_coverage'] is True
 ck(F+'/all_count_arithmetic_and_mixed_prefixes',True)
 ck(F+'/all_blocking',S['n_blocking']==2000 and S['w2_applicable'] is True and S['complete_coverage'] is True)
 eq(F+'/screen_summary_max',R['screen']['ratio_bound_max'],max_by_size)
 d3l=load(src/'registered_assets/d3c/d3c_profile_ledger.json');d3f=d3l['families'][F]
 ck(F+'/D3c_plan_identity',R['plan_identity']['identity_sha256']==d3f['plan_identity']['identity_sha256'])
 ck(F+'/D3c_plan_constants',all(R['plan_identity'][k]==d3f['constants'][k] for k in ('B','B_KDE','seeds')))
 ck(F+'/D3c_UID_identity',R['uids']['ordered_uid_sha256']==d3f['ordered_uid_sha256'] and all(R['uids'][k]==d3f['constants'][k] for k in ('K0','K1','m','K_fit','n_fit','evaluation_group')))
 eq(F+'/input_fingerprint_record_consistency',S['fingerprints'],R['first_wave_fingerprints'])
 nb=load(raw/info['notebook']);base=baseline_nb;ck(F+'/notebook_cell_count',len(nb['cells'])==len(base['cells']))
 ci=[i for i,c in enumerate(nb['cells']) if c['cell_type']=='code'];first=ci[0]
 ck(F+'/notebook_unedited_code',all(''.join(nb['cells'][i]['source'])==''.join(base['cells'][i]['source']) for i in range(len(base['cells'])) if i!=first))
 t=ast.parse(''.join(nb['cells'][first]['source']));ns={}
 for node in t.body:
  if isinstance(node,ast.Assign):ns[node.targets[0].id]=ast.literal_eval(node.value)
 want=dict(settings['common_editable_cell'],**settings['family_editable_cells'][F]);ck(F+'/notebook_config',all(typed_equal(ns[k],v) for k,v in want.items()))
 ck(F+'/notebook_counts',[nb['cells'][i].get('execution_count') for i in ci]==[1,2,3,4]);outputs=[]
 for i in ci:
  for o in nb['cells'][i].get('outputs',[]):
   assert o['output_type']!='error'
   if 'text' in o:outputs.append(''.join(o['text']))
 text='\n'.join(outputs);ck(F+'/notebook_lock_attempt',sha(lp) in text and att in text and L['commit'] in text)
 # preflight prints the full JSON lock; compare rather than relying only on substrings.
 printlock=ast.literal_eval(next(line for line in text.splitlines() if line.startswith("{'schema': 'd4c1_screen_launcher_lock_v1'")));eq(F+'/notebook_printed_lock',printlock,{k:v for k,v in L.items() if k!='registered_assets_sha256'})
 stde=(sd/f'd4c1_screen_stderr_{att}.txt').read_text();ck(F+'/stderr_preserved',stde.strip() in Rf.get('stderr','').strip() if 'stderr' in Rf else 'Could not find cuda drivers' in stde)
 # These are counts/derived values from records, not bank reevaluation.
 metrics[F]={'attempt':att,'n_rows':2000,'n_blocking':2000,'max_ratio':maxratio,'max_ratio_by_size':max_by_size,'min_P':minp,'min_hits':minhits,'total_seconds':Rf['seconds_total'],'script_seconds':R['seconds'],'screen_seconds':R['timings']['screen_seconds'],'screen_stage_seconds':R['timings']['screen']-R['timings']['first_wave_views'],'peak_rss_mb':max(R['stages_peak_rss_mb'].values()),'staging':Rf['staging'],'screen_content_sha256':S['binding']['screen_sha256'],'screen_file':desc(sp),'run_file':desc(rp),'lock_file':desc(lp),'final_file':desc(fp),'inner_zip':desc(raw/info['zip']),'notebook':desc(raw/info['notebook'])}
 allmaps.append(blocking_rows_from_screen(S,formal=True))
ck('sequential_nonoverlap',all(ordering[i][1]<ordering[i+1][0] for i in range(2)))
certp=raw/'certificate/out_20261007T152500Z/d4c1_certificate_record.json';crp=certp.with_name('d4c1_certificate_run.json');cert=load(certp);cr=load(crp)
eq('certificate_required',cr['required_inventory'],req['REQUIRED_CERTIFICATE']);ck('certificate_gates',set(cr['gates'])==set(req['REQUIRED_CERTIFICATE']) and all(v is True for v in cr['gates'].values()))
for k,v in [('stage','complete'),('selftest',False),('formal',True),('profile','production_official'),('mode','certificate'),('probe',False),('instrument',False),('failures',[])]:eq('certificate_run/'+k,cr[k],v)
ck('certificate_flags',all(cr[k] is (k=='D4C1_CERTIFICATE_COMPLETE') for k in known_flags));eq('certificate_source',{k:cr['source'][k] for k in ('script_sha256','inventory_sha256','pins_sha256','engine_version')},{k:runs['E2']['source'][k] for k in ('script_sha256','inventory_sha256','pins_sha256','engine_version')})
eq('certificate_publication',cr['published_evidence'],{certp.name:desc(certp)});eq('certificate_sources',cert['sources'],cr['sources']);ck('certificate_only_screens',[s['kind'] for s in cert['sources']]==['screen']*3)
for F,s0 in zip(('E2','E7','E8'),cert['sources']):
 eq('certificate_source_family/'+F,s0['family'],F);ck('certificate_source_files/'+F,s0['sha256']==metrics[F]['screen_file']['sha256'] and s0['run_sha256']==metrics[F]['run_file']['sha256'] and s0['screen_sha256']==metrics[F]['screen_content_sha256']);eq('certificate_source_attempt/'+F,s0['attempt'],runs[F]['attempt'])
ck('certificate_original_checker',check_certificate(cert)['ok'])
regenerated=infeasibility_certificate(2000,allmaps,pseudo_identity=pid,campaign=cert['campaign'],target_commitment=cert['target_commitment'],sources=cert['sources'])
ck('certificate_fully_rederived_with_original_provenance',typed_equal(regenerated,ser.from_jsonable(cert)))
ck('certificate_canonical_bytes_identical',ser.dumps(regenerated).encode()==certp.read_bytes())
replay=load(w/'replayed_certificate/d4c1_certificate_record.json');exclude={'sources','binding'}
eq('fresh_CLI_scientific_document',{k:v for k,v in replay.items() if k not in exclude},{k:v for k,v in cert.items() if k not in exclude})
ck('fresh_CLI_rc0',(out/'certificate_replay.rc').read_text().strip()=='0')
# source paths differ in new replay; prove all other source fields and binding fields (besides content hash) identical.
eq('replay_sources_except_local_dirs',[{k:v for k,v in s.items() if k!='dir'} for s in replay['sources']],[{k:v for k,v in s.items() if k!='dir'} for s in cert['sources']])
eq('replay_binding_except_payload',{k:v for k,v in replay['binding'].items() if k!='certificate_sha256'},{k:v for k,v in cert['binding'].items() if k!='certificate_sha256'})
# Independent counting and registered Wilson formula, not production calibration code.
def wilson(k,n,z=1.959964):
 p=k/n;return (p+z*z/(2*n)+z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n)
limits={};
for lvl,tol in [('support',0.05),('strong',0.01)]:
 threshold=next(k for k in range(2001) if wilson(k,2000)>tol);d=cert['levels'][lvl]
 counts=Counter()
 for j in range(2000):
  r=cert['rows'][str(j)];assert set(r['families'])=={'E2','E7','E8'};assert len(r['evidence'])==3
  for F in r['families']:assert r['families'][F][lvl]=='unknown_or_technical'
  q=r['levels'][lvl];assert q=={'aggregate':'unknown_or_technical','blocking':True,'technical':False,'possibly_technical':True};counts['blocking']+=1
  for ev in r['evidence']:
   F=ev['family'];assert ev['source_sha256']==metrics[F]['screen_content_sha256'];assert ev['ratio_bounds']=={sn:screens[F]['results'][j]['sizes'][sn]['ratio_bound'] for sn in screens[F]['sizes']}
 assert d['threshold']==tol and d['first_blocking_count']==threshold and d['proven_blocking_rows']==counts['blocking']==2000
 assert d['technical_rows']==0 and d['possibly_technical_rows']==2000 and d['retained_false_rows']==0
 assert d['usable_true_impossible_by_wilson'] is True and d['wilson_upper_if_remaining_all_false']==wilson(2000,2000)==1.0
 limits[lvl]={'threshold':tol,'first_blocking_count':threshold,'previous_upper':wilson(threshold-1,2000),'blocking_upper':wilson(threshold,2000),'proven_blocking_rows':2000,'conditional_upper':1.0}
ck('independent_certificate_all_2000_rows_and_Wilson',True)
for F,m in zip(('E2','E7','E8'),allmaps):
 solo=infeasibility_certificate(2000,[m],pseudo_identity=pid)
 ck(F+'/alone_suffices_to_block_original_global_scope',all(solo['levels'][k]['usable_true_impossible_by_wilson'] for k in ('support','strong')))
ck('E1_cannot_rescue_row',all(any_family_truth([UNKNOWN,e])!=False for e in [True,False,UNKNOWN,TECH]))
result={'schema':'independent_screen_certificate_audit_v1','record_checks':checks,'n_record_checks':len(checks),'n_failed':sum(not c['ok'] for c in checks),'inventory_sha_entries':inv_count,'screens':metrics,'arithmetic':{'stored_probability_recomputations':raw_rates,'size_envelopes':raw_envelopes,'mixed_prefix_combinations':mixed_choices,'bank_counts_regenerated':False,'registered_Wilson':limits},'certificate':{'file':desc(certp),'content_sha256':cert['binding']['certificate_sha256'],'original_document_rederived_byte_exact':True,'fresh_cli_replayed':True,'fresh_cli_content_hash':replay['binding']['certificate_sha256'],'fresh_cli_changes':'only source absolute directories and resulting content hash; consumer run metadata is separate'},'environment':{'audit_python':sys.version},'raw_file_map':initial['raw'],'inner_file_map':initial['screens']}
now={'source':tree_map(src),'raw':tree_map(raw),'screens':tree_map(w/'screens')}
result['preservation']={k:{'files':len(initial[k]),'unchanged':initial[k]==now[k]} for k in initial}
assert all(x['unchanged'] for x in result['preservation'].values())
(out/'audit_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ('record_checks','raw_file_map','inner_file_map')},ensure_ascii=False,indent=2))
