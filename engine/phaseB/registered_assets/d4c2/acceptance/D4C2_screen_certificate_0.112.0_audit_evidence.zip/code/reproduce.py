#!/usr/bin/env python3
"""Reproduce this read-only audit. Requires the three named prior/current attachments.
Usage: python reproduce.py --inputs DIR_CONTAINING_ATTACHMENTS --work NEW_DIRECTORY
No production banks, Colab, target evaluation or network are used.
"""
import argparse,hashlib,json,os,stat,subprocess,sys,zipfile
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--inputs',type=Path,required=True);ap.add_argument('--work',type=Path,required=True);a=ap.parse_args();inp=a.inputs.resolve();w=a.work.resolve()
if w.exists():raise SystemExit('Use a new, nonexistent work directory.')
w.mkdir(parents=True);(w/'results').mkdir()
expected={'phaseB_D4C2a_v5_0.112.0.zip':'0f52a66f53656fd0e686d2ff9a095724e3f834bcd1db26259509005ca323b62c','D4C2_screen_certificate_0.112.0_results.zip':'567092dae35b2a9f8ba64ef28af000b680546502b69c890d22af756d309a7cc7','D4C2_screen_certificate_0.112.0_execution_decision.json':'0477d7b2fb546634c3444cb0613aef993d181730e4556cbfc97f6116f5473282','D4C2_screen_certificate_report.md':'b9a96cecd1cd6b9d27030381198512d4f05525a8451cb2d4e2d4125b7d179d02'}
for name,h in expected.items():
 if hashlib.sha256((inp/name).read_bytes()).hexdigest()!=h:raise SystemExit('Input SHA differs: '+name)
def extract(p,d):
 with zipfile.ZipFile(p) as z:
  names=z.namelist()
  if len(names)!=len(set(names)) or z.testzip() is not None:raise ValueError('Duplicate/corrupt archive')
  for i in z.infolist():
   q=Path(i.filename)
   if q.is_absolute() or '..' in q.parts or stat.S_ISLNK(i.external_attr>>16):raise ValueError('Unsafe member')
  z.extractall(d)
extract(inp/'phaseB_D4C2a_v5_0.112.0.zip',w/'source');extract(inp/'D4C2_screen_certificate_0.112.0_results.zip',w/'raw')
for F in ('E2','E7','E8'):extract(next((w/'raw/screens').glob('d4c1_screen_'+F+'*.zip')),w/'screens'/F)
p=w/'source/phaseB';cmd=[sys.executable,str(p/'d/d4c1_calibration.py'),'--phaseb',str(p),'--mode','certificate']
for F in ('E2','E7','E8'):cmd+=['--screen',str(next((w/'screens'/F).glob('run_*')))]
cmd+=['--target-commitment','9efa1b8d82fec2e23ac685d24dbaece7932e29955c94fc5a2955ba793c70b326','--campaign-id','D4C2_9efa1b8d82fe','--out',str(w/'replayed_certificate')]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
def run(args,label):
 with open(w/'results'/f'{label}.stdout','w') as fo,open(w/'results'/f'{label}.stderr','w') as fe:r=subprocess.run(args,env=env,stdout=fo,stderr=fe)
 (w/'results'/f'{label}.rc').write_text(str(r.returncode))
 if r.returncode:raise SystemExit(f'{label} failed; see the saved logs')
run(cmd,'certificate_replay');here=Path(__file__).resolve().parent
run([sys.executable,str(here/'audit_results.py'),'--work',str(w),'--input-dir',str(inp)],'audit')
# Rejection controls are separate; same production source, copied data only.
run([sys.executable,str(here/'rejection_controls.py'),'--work',str(w)],'rejections')
print('Audit and rejection controls completed; see',w/'results')
