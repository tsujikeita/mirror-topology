#!/usr/bin/env python3
"""Additional real-record mutation controls, performed only on in-memory copies."""
import argparse,ast,copy,hashlib,json,sys
from pathlib import Path
from types import SimpleNamespace
ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);a=ap.parse_args();w=a.work.resolve();src=w/'source/phaseB';sys.path.insert(0,str(src));sys.dont_write_bytecode=True
from step1_engine import serialization as ser
from step1_engine.infeasibility import *
from step1_engine.d3_profile import twelve_context
from step1_engine.d4c0_registry import load_registered_w2_context,load_registered_pseudo_columns
from step1_engine.calibration import any_family_truth,calibrate
from step1_engine.truth import UNKNOWN,TECH
from step1_engine.errors import InputContractError
L=lambda p:json.loads(p.read_text());sd=w/'screens/E2';S=L(next(sd.glob('run*/*_record.json')));R=L(next(sd.glob('run*/*_run.json')));C=L(w/'raw/certificate/out_20261007T152500Z/d4c1_certificate_record.json')
ctx=twelve_context(str(src));wc,_=load_registered_w2_context(str(src),ctx);cols=load_registered_pseudo_columns(str(src),ctx)
cfg={}
for c in ctx.d2_spec['configurations'].values():
 if c['family']=='E2':cfg.setdefault(c['size_id'],[]).append(c['config_id'])
kwargs=dict(registry_sha256=ctx.identities['registry_sha256'],manifest_sha256=ctx.identities['manifest_sha256'],w2_context_sha256=wc.context_sha256,w2_decisions={k:wc.decision_for(k,wc.context_sha256) for k in wc.decisions},pseudo_identity=dict(n=2000,sha256_T1=cols['identity']['T1_sha256'],sha256_T2=cols['identity']['T2_sha256']),T1=cols['T1'],T2=cols['T2'],config_ids=cfg,family='E2',campaign_id=R['campaign_id'],target_commitment=R['target_commitment'])
res=[]
def refusal(name,fn):
 try:fn()
 except Exception as e:res.append(dict(name=name,expected='refusal',passed=True,error=type(e).__name__,message=str(e)[:200]));return
 raise AssertionError('not refused: '+name)
def stamp(d,key):d['binding'][key]=hashlib.sha256(ser.dumps({k:v for k,v in d.items() if k!='binding'}).encode()).hexdigest();return d
assert bind_screen_record(S,**kwargs)['bound']
for name,edit in [
 ('screen_W2_Bfinal_restamped',lambda d:d['w2']['L1.20'].__setitem__('B_final',400)),
 ('screen_W2_trigger_restamped',lambda d:d['w2']['L1.00'].__setitem__('trigger','unknown')),
 ('screen_threshold_restamped',lambda d:d['results'][0]['threshold'].__setitem__(0,d['results'][0]['threshold'][0]+1)),
 ('screen_missing_N4_restamped',lambda d:d['results'][0]['sizes']['L1.00']['positions']['1']['stages'].pop('N4')),
 ('screen_blocking_false_restamped',lambda d:d['results'][0].__setitem__('blocking',False)),
 ('screen_hit_changed_without_P_restamped',lambda d:d['results'][0]['sizes']['L1.00']['positions']['1']['stages']['N0'].__setitem__('hits',1)),
 ('screen_missing_row_restamped',lambda d:d['results'].pop()),
]:
 d=copy.deepcopy(S);edit(d);stamp(d,'screen_sha256');refusal(name,lambda:bind_screen_record(d,**kwargs))
for name,edit in [
 ('certificate_threshold_swap_restamped',lambda d:d.__setitem__('thresholds',{'support':0.01,'strong':0.05})),
 ('certificate_inflated_count_restamped',lambda d:d['levels']['support'].__setitem__('proven_blocking_rows',6000)),
 ('certificate_proven_count_restamped',lambda d:d.__setitem__('n_rows_proven',1999)),
 ('certificate_outcome_false_restamped',lambda d:d['levels']['support'].__setitem__('usable_true_impossible_by_wilson',False)),
]:
 d=copy.deepcopy(C);edit(d);stamp(d,'certificate_sha256');refusal(name,lambda:check_certificate(d))
# Execute only the original AST source-admission predicate, not a substitute implementation.
tree=ast.parse((src/'d/d4c1_calibration.py').read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_certificate')
ns={'a':SimpleNamespace(campaign_id=R['campaign_id'],target_commitment=R['target_commitment']),'formal':True,'me_src':R['source'],'_hex64':lambda x:isinstance(x,str) and len(x)==64 and all(c in '0123456789abcdef' for c in x)}
for n in tree.body:
 if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id.startswith('REQUIRED_'):
  try:ns[n.targets[0].id]=ast.literal_eval(n.value)
  except Exception:pass
for n in main.body:
 if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('_FLAG','_ALL_FLAGS'):exec(compile(ast.Module([n],type_ignores=[]),'original-constants','exec'),ns)
for n in main.body:
 if isinstance(n,ast.FunctionDef) and n.name in ('trusted_inventory','run_ok'):exec(compile(ast.Module([n],type_ignores=[]),'original-run-predicate','exec'),ns)
assert ns['run_ok'](R,('screen',))
for name,edit in [
 ('producer_required_removed_both',lambda d:(d['required_inventory'].remove('G_inputs_resolved'),d['gates'].pop('G_inputs_resolved'))),
 ('producer_gate_integer',lambda d:d['gates'].__setitem__('G_env_lock',1)),
 ('producer_attempt_empty',lambda d:d.__setitem__('attempt',{})),
 ('producer_failed_stage',lambda d:d.__setitem__('stage','exception')),
 ('producer_other_pins',lambda d:d['source'].__setitem__('pins_sha256','0'*64)),
 ('producer_probe',lambda d:d.__setitem__('probe',True))]:
 d=copy.deepcopy(R);edit(d);ok=ns['run_ok'](d,('screen',));assert ok is False
 res.append(dict(name=name,expected='predicate False',passed=True))
# Algebraic implication only; these are NOT uncomputed real E1 results.
truth_controls=[]
for e in (False,True,UNKNOWN,TECH):
 t=any_family_truth([e,UNKNOWN,UNKNOWN,UNKNOWN]);q=calibrate([t]*2000,.05,expected_n=2000)
 assert q.usable is not True
 truth_controls.append({'E1_test_value':e,'global_test_value':t,'usable':q.usable,'status':q.status,'synthetic_algebra_only':True})
output={'normal_screen_binding':True,'normal_certificate_checker':check_certificate(C),'normal_original_source_predicate':True,'refusal_controls':res,'refusal_count':len(res),'synthetic_E1_algebra':truth_controls,'limitations':'Mutated copies of real evidence, not reruns of real bank computations. Source predicate uses original AST only after preflight; full unmodified certificate CLI baseline was separately executed.'}
(w/'results/rejection_controls.json').write_text(json.dumps(output,ensure_ascii=False,indent=2));print('passed rejection controls',len(res));print(json.dumps(truth_controls,ensure_ascii=False))
