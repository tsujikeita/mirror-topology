# D4C2 screen/certificate audit evidence

The input data are the user-provided, fixed 0.112.0 source/results and prior execution GO.
No production bank computation was performed. See the report for the scientific scope.

## Reproduce

Place these original attachments in one directory:
- phaseB_D4C2a_v5_0.112.0.zip
- D4C2_screen_certificate_0.112.0_results.zip
- D4C2_screen_certificate_0.112.0_execution_decision.json
- D4C2_screen_certificate_report.md

Run `python code/reproduce.py --inputs /path/to/attachments --work /path/to/new-work`.
This needs Python plus NumPy/SciPy and dependencies used by the registered reader. The certificate-only path does not require healpy/POT/CAMB or production banks. pytest is only needed to repeat the separate selected tests recorded below.

`audit_results.json`: actual 470 direct checks, real saved-count arithmetic, reference binding, canonical original certificate reconstruction, and preservation.
`rejection_controls.json`: 17 mutation controls on copies of the submitted evidence; four E1 state controls are synthetic algebra, not target/family evaluations.
`certificate_replay.*`: the unmodified driver's actual CLI run in this audit environment.
`selected_pytest.*`: five original tests selected from test_d4c2a.py.
`fresh_scope.json`: a second fresh CLI replay completed; the subsequent full audit exceeded the wrapper's 180 s tool limit and is not claimed complete.
`harness_*.stderr`: initial audit-harness errors, corrected only in audit code; not producer failures.

No report/tool success is a proof about all cosmological models, all future pseudo samples, or a completed sealed calibration.
