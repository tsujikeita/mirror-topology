"""Independent exact-function contract tests. No numerical bank calculations."""
from pathlib import Path
import sys,ast,json,copy,hashlib,types
A=Path(__file__).resolve().parents[1];P=A/'submitted/phaseB';sys.path.insert(0,str(P))
from step1_engine.official_gate import registered_environments,recorded_environment_registered,EXPECTED_VERS,EXPECTED_VERS_HISTORY,VERSION_KEYS
from step1_engine.errors import InputContractError
import importlib.util
spec=importlib.util.spec_from_file_location('actual_driver',P/'d/d4c1_calibration.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
src=dict(inventory_sha256=sha(P/'B2_completion_inventory.json'),script_sha256=sha(P/'d/d4c1_calibration.py'),pins_sha256=sha(P/'d/d3_pins.json'),engine_version='0.111.0')
t=ast.parse((P/'d/d4c1_calibration.py').read_text());fn=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='_certificate')
keep=[]
for n in fn.body:
 if isinstance(n,ast.FunctionDef) and n.name in ('trusted_inventory','run_ok'):keep.append(n)
 if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id in ('_FLAG','_ALL_FLAGS') for x in n.targets):keep.append(n)
ns=dict(vars(M),formal=True,me_src=src,a=types.SimpleNamespace(campaign_id='AUDIT_FIXED_CAMPAIGN',target_commitment='a'*64));exec(compile(ast.fix_missing_locations(ast.Module(body=keep,type_ignores=[])),'<unaltered producer validator>','exec'),ns)
mutations={
 'missing_gate_and_list':lambda r:(r['gates'].pop(r['required_inventory'][-1]),r['required_inventory'].pop()),
 'env_only':lambda r:r.update(gates={'G_env_lock':True},required_inventory=['G_env_lock']),
 'extra_gate_and_list':lambda r:(r['gates'].update(EXTRA=True),r['required_inventory'].append('EXTRA')),
 'wrong_order':lambda r:r['required_inventory'].reverse(),
 'int_true':lambda r:r['gates'].update(G_pins_loaded=1),
 'empty_attempt':lambda r:r.update(attempt={}),
 'empty_attempt_id':lambda r:r['attempt'].update(attempt_id=''),
 'bad_lock_sha':lambda r:r['attempt'].update(launcher_lock_sha256='bad'),
 'source_pins_wrong':lambda r:r['source'].update(pins_sha256='0'*64),
 'top_pins_wrong':lambda r:r.update(pins_sha256='0'*64),
 'top_engine_wrong':lambda r:r.update(engine_version='0.110.0'),
 'wrong_profile':lambda r:r.update(profile='other'),
 'probe_true':lambda r:r.update(probe=True),
 'instrument_true':lambda r:r.update(instrument=True),
 'certificate_flag_true':lambda r:r.update(D4C1_CERTIFICATE_COMPLETE=True),
 'failed_stage':lambda r:r.update(stage='exception',failures=['failure'])}
results=[]
for kind,req in [('screen',M.REQUIRED_SCREEN),('partial',M.REQUIRED_PARTIAL),('subpartial',M.REQUIRED_SUBPARTIAL),('combine-family',M.REQUIRED_COMBINE_FAMILY)]:
 mode='partial' if kind=='subpartial' else kind
 r=dict(schema='d4c1_run_record_v1',mode=mode,stage='complete',failures=[],profile='production_official',required_inventory=list(req),gates={k:True for k in req},source=copy.deepcopy(src),attempt={'attempt_id':'AUDIT_TEST_ONLY','launcher_lock_sha256':'e'*64},engine_version=src['engine_version'],pins_sha256=src['pins_sha256'],probe=False,instrument=False,probe_n=None,campaign_id='AUDIT_FIXED_CAMPAIGN',target_commitment='a'*64,formal=True,selftest=False,required_all_true=True,subpartial=(kind=='subpartial'),row_range=[0,3] if kind=='subpartial' else None)
 r.update({flag:flag==ns['_FLAG'][kind] for flag in ns['_ALL_FLAGS']})
 assert ns['run_ok'](r,(mode,));results.append(dict(mode=kind,case='valid',accepted=True))
 for tag,mut in mutations.items():
  v=copy.deepcopy(r);mut(v);got=ns['run_ok'](v,(mode,));assert got is False,(kind,tag)
  results.append(dict(mode=kind,case=tag,accepted=got))
pins=json.loads((P/'d/d3_pins.json').read_text());envresults=[]
assert registered_environments(pins)==[{k:EXPECTED_VERS[k] for k in VERSION_KEYS}]+[{k:h[k] for k in VERSION_KEYS} for h in EXPECTED_VERS_HISTORY]
mut={
'missing':lambda p:p.pop('environment_history'),'null':lambda p:p.update(environment_history=None),'dict':lambda p:p.update(environment_history={}),
'empty':lambda p:p.update(environment_history=[]),'extra_entry':lambda p:p['environment_history'].append(copy.deepcopy(p['environment_history'][0])),
'wrong_version':lambda p:p['environment_history'][0].update(python='3.13.14'),'missing_version':lambda p:p['environment_history'][0].pop('numpy'),
'float_version':lambda p:p['environment_history'][0].update(numpy=2.1),'wrong_label':lambda p:p['environment_history'][0].update(registered_until='other'),
'missing_label':lambda p:p['environment_history'][0].pop('registered_until'),'extra_key':lambda p:p['environment_history'][0].update(extra=True),
'missing_amendment':lambda p:p['environment_history'][0].pop('amendment'),'null_amendment':lambda p:p['environment_history'][0].update(amendment=None),'empty_amendment':lambda p:p['environment_history'][0].update(amendment='')}
for tag,fn in mut.items():
 p=copy.deepcopy(pins);fn(p)
 for route,func in [('environments',lambda:registered_environments(p)),('recorded',lambda:recorded_environment_registered(EXPECTED_VERS_HISTORY[0],p))]:
  try:func();raise AssertionError((tag,route,'accepted'))
  except InputContractError as e:envresults.append(dict(case=tag,route=route,rejected=True,error=str(e)))
p=copy.deepcopy(pins);p['environment_history'][0]['amendment']='metadata_other_document.md';assert registered_environments(p)==registered_environments(pins)
(A/'results/guards.json').write_text(json.dumps(dict(scope=__doc__,producer=results,history=envresults,metadata_only_rename_accepted=True),indent=2));print('producer',len(results),'history',len(envresults),'all expected')
