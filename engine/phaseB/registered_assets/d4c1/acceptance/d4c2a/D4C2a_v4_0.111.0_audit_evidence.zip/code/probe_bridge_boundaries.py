"""Independent TEST-ONLY 0.110 producer / 0.111 verifier cross-tree bridge contract probes.
Synthetic new records from accepted baseline; NO new physical/bank/bootstrap execution.
Original spec and original producer modules remain unmodified.
"""
from pathlib import Path
import os,sys,json,hashlib,ast,shutil,subprocess,importlib.util
A=Path(__file__).resolve().parents[1]; new=A/'submitted/phaseB'; old=A/'previous/phaseB'
os.environ['PYTHONDONTWRITEBYTECODE']='1'; sys.dont_write_bytecode=True
sys.path[:0]=[str(old),str(old/'tests')]
# Reuse author's synthetic fixture algorithm but bind it to the approved producer .110 tree.
# This is a fixture adaptation, not a change to the comparator or any engine module.
t=ast.parse((new/'tests/test_d4c2_bridge.py').read_text()); keep=[]
for n in t.body:
 if isinstance(n,(ast.Import,ast.ImportFrom)):keep.append(n)
 elif isinstance(n,ast.FunctionDef) and n.name=='probes':n.decorator_list=[];keep.append(n)
ns={'__file__':str(old/'tests/test_d4c2_bridge.py')};exec(compile(ast.fix_missing_locations(ast.Module(body=keep,type_ignores=[])),'<author fixture bound to old producer>','exec'),ns)
SPEC=Path(os.environ.get('BRIDGE_SPEC', '/mnt/data/D4C2a_v3_0.110.0_bridge_comparison_spec.json'))
ns.update(P=str(old),SPEC=str(SPEC),PROBE_DIR=str(old/'registered_assets/d4c1/probes/20261005T100239Z_386d63207c'),sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest())
ns['BASE_ZIP']=str(Path(ns['PROBE_DIR'])/'d4c1_partial_E2_231d37b89271.zip')
work=A/'tmp/bridge_controls';work.mkdir(exist_ok=True)
class Factory:
 def mktemp(self,tag):p=work/tag;p.mkdir();return p
fx=ns['probes'](Factory());(A/'results/bridge_fixture.json').write_text(json.dumps({k:v for k,v in fx.items() if k in ['root','base','new','nrun']},indent=2))
sha=ns['sha']; cases=[]
def execute(tag,edit=None,expect=None):
 root=work/tag;shutil.copytree(fx['new'],root);rd=root/Path(fx['nrun']).name
 rp=rd/'d4c1_probe_E2_run.json';p=json.loads(rp.read_text())
 if edit:edit(p,root,rd)
 rp.write_text(json.dumps(p))
 out=A/'results'/('bridge_'+tag+'.json')
 cmd=[sys.executable,str(new/'d/d4c2_bridge_compare.py'),'--phaseb',str(old),'--spec',str(SPEC),'--baseline',ns['BASE_ZIP'],'--new',str(root),'--out',str(out)]
 r=subprocess.run(cmd,capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
 (A/'logs'/('bridge_'+tag+'.log')).write_text(r.stdout+'\nSTDERR\n'+r.stderr)
 rep=json.loads(out.read_text()) if out.exists() else {}
 cases.append(dict(tag=tag,returncode=r.returncode,result=rep.get('result'),mismatches=rep.get('mismatches'),report_present=out.exists(),expected=expect))
 (A/'results/bridge_boundaries.json').write_text(json.dumps(dict(scope=__doc__,cases=cases),indent=2));print(cases[-1],flush=True)
execute('normal_old_producer',expect='accept synthetic contract baseline')
def renamed(p,*_):
 p['required_inventory'][p['required_inventory'].index('G_inputs_resolved')]='TEST_FAKE_GATE';p['gates']['TEST_FAKE_GATE']=p['gates'].pop('G_inputs_resolved')
execute('required_gate_renamed',renamed,'reject trusted inventory mismatch')
execute('required_order_reversed',lambda p,*_:p['required_inventory'].reverse(),'reject trusted inventory order')
execute('source_pins_wrong',lambda p,*_:p['source'].update(pins_sha256='0'*64),'reject wrong source pins')
execute('attempt_does_not_match_directory',lambda p,*_:p['attempt'].update(attempt_id='DIFFERENT_ATTEMPT'),'reject mismatch')
def badlock(p,root,rd):
 (root/'d4c1_partial_lock.json').write_text(json.dumps(dict(commit='WRONG_COMMIT',inventory_sha256='0'*64)))
 (root/'d4c1_partial_final_record.json').write_text(json.dumps(dict(exit_code=1,launcher_fallback=True,failures=['TEST_FAILURE'],bindings=dict(live_source_prelaunch=dict(head='WRONG_COMMIT',clean=False)))))
execute('bad_lock_and_failure_final',badlock,'reject lock/final/prelaunch mismatch')
def prof_missing(p,root,rd):
 fp=rd/'d4c1_probe_E2_profile.json'; d=json.loads(fp.read_text());d['missing_targets']=['TEST_MISSING_TARGET'];d['instrumentation']={'cprofile':False};fp.write_text(json.dumps(d));p['profile_record']=dict(sha256=sha(fp),bytes=fp.stat().st_size)
execute('profile_rehashed_missing_targets',prof_missing,'reject underlying profiler mismatch')
execute('actual_env_gate_false',lambda p,*_:p['gates'].update(G_env_lock=False),'reject')
execute('malformed_record',lambda p,root,rd:(rd/'d4c1_probe_E2_record.json').write_text('null'),'reject with report')
