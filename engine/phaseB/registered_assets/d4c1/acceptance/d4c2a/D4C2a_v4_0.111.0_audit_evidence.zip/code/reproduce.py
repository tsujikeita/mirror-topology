"""Reproduce the local audit. Requires the author's 0.111/0.110 ZIPs and original bridge spec.
Default: independent guard/algebra/bridge boundary checks. --full adds selected pytest,
the 24-case certificate/CLI audit and actual synthetic-False reader checks.
All fixtures are TEST-ONLY. No real bank generation, Colab execution, or network use.
"""
from pathlib import Path
import argparse,zipfile,stat,shutil,subprocess,os,sys,json,hashlib
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--current-zip',required=True);p.add_argument('--producer-zip',required=True);p.add_argument('--comparison-spec',required=True);p.add_argument('--out',required=True);p.add_argument('--full',action='store_true');a=p.parse_args()
root=Path(a.out).resolve()
if root.exists():raise SystemExit('--out must be new')
for n in ['code','results','logs','tmp','inputs']:(root/n).mkdir(parents=True,exist_ok=True)
for f in Path(__file__).resolve().parent.glob('*.py'):
 if f.name!='make_deliverables.py':shutil.copyfile(f,root/'code'/f.name)
for zpath,tag in [(a.current_zip,'submitted'),(a.producer_zip,'previous')]:
 with zipfile.ZipFile(zpath) as z:
  names=z.namelist();assert len(names)==len(set(names)) and z.testzip() is None
  for i in z.infolist():
   q=Path(i.filename);assert not q.is_absolute() and '..' not in q.parts and not stat.S_ISLNK(i.external_attr>>16)
  z.extractall(root/tag)
sp=root/'inputs/bridge_spec.json';shutil.copyfile(a.comparison_spec,sp)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',BRIDGE_SPEC=str(sp),AUDIT_WORKDIR=str(root/'tmp/fixtures'))
runlog=[]
def run(tag,cmd,cwd=None):
 with (root/'logs'/f'{tag}.log').open('w') as f:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 runlog.append({'tag':tag,'returncode':r.returncode});(root/'results/reproduce_commands.json').write_text(json.dumps(runlog,indent=2));print(tag,r.returncode,flush=True)
 if r.returncode:raise SystemExit(f'{tag} did not complete; see log (expected BAD bridge acceptances are reported inside a successful boundary probe, not as driver errors)')
def script(name):run(name,[sys.executable,str(root/'code'/name)])
script('metadata.py');script('probe_guards.py');script('probe_algebra.py');script('probe_bridge_boundaries.py');script('probe_bridge_extra.py')
if a.full:
 source=root/'submitted/phaseB'
 run('pytest_new',[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','tests/test_d4c2a.py','tests/test_d4c2a_script.py','tests/test_d4c2_bridge.py','--basetemp='+str(root/'tmp/pytest_new'),'--junitxml='+str(root/'results/pytest_new.xml')],source)
 run('pytest_registered',[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','tests/test_d4c0_registration.py','tests/test_d3c_tranche2.py','-k','not consumer_api_rebuild_and_refusals','--basetemp='+str(root/'tmp/pytest_registered'),'--junitxml='+str(root/'results/pytest_registered.xml')],source)
 script('probe_real_false_rows.py');script('probe_certificate.py')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();pres={}
for tag,snap in [('submitted','source_snapshot.json'),('previous','previous_snapshot.json')]:
 base=root/tag/'phaseB';now={str(q.relative_to(base)):sha(q) for q in base.rglob('*') if q.is_file()};old=json.loads((root/'results'/snap).read_text());pres[tag]={'files':len(old),'unchanged':now==old};assert now==old
(root/'results/reproduce_preservation.json').write_text(json.dumps(pres,indent=2))
