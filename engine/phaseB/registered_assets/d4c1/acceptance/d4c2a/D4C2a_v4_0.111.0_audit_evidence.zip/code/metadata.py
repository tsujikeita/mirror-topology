from pathlib import Path
import hashlib,json,ast,collections,zipfile,xml.etree.ElementTree as ET
BASE=Path(__file__).resolve().parents[1]; S=BASE/'submitted/phaseB'; O=BASE/'previous/phaseB'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
snap=lambda root:{str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
a,b=snap(S),snap(O)
inv=json.loads((S/'B2_completion_inventory.json').read_text()); errs=[]; found=[]
for section, d in inv.items():
 if not isinstance(d, dict): continue
 for k, v in d.items():
  if not isinstance(v, str) or len(v)!=64: continue
  prefix = 'step1_engine' if section=='modules' else 'tests' if section in ('tests_sha256','fixtures_sha256') else ''
  p = S/prefix/k
  if p.is_file():
   found.append(str(p.relative_to(S)))
   if sha(p)!=v: errs.append(str(p.relative_to(S)))
  else: errs.append('missing:'+section+':'+k)
py=[];nb=[]
for p in S.rglob('*.py'):compile(p.read_bytes(),str(p),'exec');py.append(str(p.relative_to(S)))
for nm in ['MirrorTopology_Step1_D4C1_partial_v0.1.ipynb','MirrorTopology_Step1_D4C1_combine_family_v0.1.ipynb','MirrorTopology_Step1_D4C2_screen_v0.1.ipynb']:
 for i,c in enumerate(json.loads((S/'d'/nm).read_text())['cells']):
  if c['cell_type']=='code': compile(''.join(c['source']),f'{nm}:{i}','exec');nb.append(f'{nm}:{i}')
counts=collections.Counter();tests=[]
for p in (S/'regression_logs/d4c2a_pytest').glob('j*.xml'):
 rt=ET.parse(p).getroot(); cases=list(rt.iter('testcase'));tests += [(x.get('classname'),x.get('name')) for x in cases]
 counts['junit_files']+=1;counts['cases']+=len(cases)
 for typ in ['failure','error','skipped']:counts[typ]+=sum(x.find(typ) is not None for x in cases)
R={'inventory_sha256':sha(S/'B2_completion_inventory.json'),'sha_entries':len(found),'sha_errors':errs,'compiled_py':len(py),'compiled_nb_cells':len(nb),'author_junit':dict(counts),'current_files':len(a),'previous_files':len(b),'changed':[k for k in b if k in a and a[k]!=b[k]],'added':[k for k in a if k not in b],'removed':[k for k in b if k not in a],'previous_registered_files':sum(k.startswith('registered_assets/') for k in b),'changed_old_registered':[k for k in b if k.startswith('registered_assets/') and a.get(k)!=b[k]]}
(BASE/'results/source_snapshot.json').write_text(json.dumps(a,indent=1));(BASE/'results/previous_snapshot.json').write_text(json.dumps(b,indent=1));(BASE/'results/metadata.json').write_text(json.dumps(R,indent=2));(BASE/'results/junit_nodes.json').write_text(json.dumps(tests))
print(json.dumps(R,indent=2))
