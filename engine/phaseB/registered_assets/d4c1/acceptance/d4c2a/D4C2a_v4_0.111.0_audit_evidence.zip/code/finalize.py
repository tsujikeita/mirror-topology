from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET,collections,sys,platform
A=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
preservation={}
for label,snapname in [('submitted','source_snapshot.json'),('previous','previous_snapshot.json')]:
 base=A/label/'phaseB'; old=json.loads((A/'results'/snapname).read_text());new={str(p.relative_to(base)):sha(p) for p in base.rglob('*') if p.is_file()}
 preservation[label]={'files':len(old),'changed':[k for k in old if new.get(k)!=old[k]],'added':[k for k in new if k not in old]};preservation[label]['unchanged']=old==new
 assert old==new,preservation[label]
F=A/'fresh_quick/submitted/phaseB';m=json.loads((A/'results/source_snapshot.json').read_text());fm={str(p.relative_to(F)):sha(p) for p in F.rglob('*') if p.is_file()};assert m==fm
preservation['fresh_quick']={'files':len(fm),'unchanged':m==fm}
r={}
for name in ['pytest_new','pytest_registered']:
 rt=ET.parse(A/'results'/f'{name}.xml').getroot();cases=list(rt.iter('testcase'));r[name]={'cases':len(cases),'passed':sum(not any(c.find(t) is not None for t in ('failure','error','skipped')) for c in cases),'failures':sum(c.find('failure') is not None for c in cases),'errors':sum(c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases),'skips':[{'name':c.get('name'),'reason':c.find('skipped').get('message')} for c in cases if c.find('skipped') is not None]}
r['total']={k:sum(x[k] for x in list(r.values())) for k in ['cases','passed','failures','errors','skipped']}
r['explicitly_deselected']='test_consumer_api_rebuild_and_refusals in test_d3c_tranche2.py (full-scale plan rebuild excluded)'
(A/'results/preservation.json').write_text(json.dumps(preservation,indent=2));(A/'results/tests_summary.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
