"""TEST-ONLY supplemental typed-identity and live-gate omission probes, no new physics."""
from pathlib import Path
import json,shutil,subprocess,os,sys
A=Path(__file__).resolve().parents[1];S=A/'submitted/phaseB';O=A/'previous/phaseB';fx=json.loads((A/'results/bridge_fixture.json').read_text());base=O/'registered_assets/d4c1/probes/20261005T100239Z_386d63207c/d4c1_partial_E2_231d37b89271.zip';out=[]
for case in ['typed_index_bool','twelve_live_gate_failed']:
 root=A/'tmp/bridge_controls'/case;shutil.copytree(fx['new'],root);rd=root/Path(fx['nrun']).name
 if case=='typed_index_bool':
  p=rd/'archive/index.json';d=json.loads(p.read_text())
  for e in d['entries']:
   if e['kind']=='family_result' and e['identity'].get('pseudo_index')==0:e['identity']['pseudo_index']=False
  p.write_text(json.dumps(d))
 else:
  p=rd/'d4c1_probe_E2_run.json';d=json.loads(p.read_text());d['twelve_gate']={'mode':'official','passed':False,'required_failures':['TEST_REQUIRED_FAILURE'],'diagnostics':{'environment_source':'injected_test_snapshot'}};p.write_text(json.dumps(d))
 rp=A/'results'/f'bridge_{case}.json'
 r=subprocess.run([sys.executable,str(S/'d/d4c2_bridge_compare.py'),'--phaseb',str(O),'--spec',os.environ.get('BRIDGE_SPEC','/mnt/data/D4C2a_v3_0.110.0_bridge_comparison_spec.json'),'--baseline',str(base),'--new',str(root),'--out',str(rp)],capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1'))
 (A/'logs'/f'bridge_{case}.log').write_text(r.stdout+'\n'+r.stderr);doc=json.loads(rp.read_text()) if rp.exists() else {}
 out.append(dict(case=case,returncode=r.returncode,result=doc.get('result'),mismatches=doc.get('mismatches')));print(out[-1],flush=True)
(A/'results/bridge_extra.json').write_text(json.dumps(dict(scope=__doc__,cases=out),indent=2))
