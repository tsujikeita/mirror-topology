# D4C-2a v4 / 0.111.0 independent audit evidence

All artificial screen and bridge inputs are **TEST-ONLY**. In particular, JSON reports that say
`BRIDGE_CONTRACT_SATISFIED` here are counterexample/control outputs from the submitted checker,
NOT new Colab results or an accepted environment bridge. The old scientific records were reused;
no physical simulation or new-environment numerical computation was performed.

## Files
- `code/`: independent probes and reproducible fixture adaptations; the submitted modules/checker were not patched.
- `results/`: actual results, source maps, metadata, JUnit and comparison summaries.
- `logs/`: actual stdout/stderr.
- `fresh_quick/`: guard/algebra-only fresh-source repeat (not all selected tests).
- Final audit report and decision JSON are included at the ZIP root.

## Reproduction
Requires local `phaseB_D4C2a_v4_0.111.0.zip`, `phaseB_D4C2a_v3_0.110.0.zip`, and the original
`D4C2a_v3_0.110.0_bridge_comparison_spec.json`, plus Python/NumPy/SciPy/pytest dependencies.
No network or production banks are required for the independent boundaries. External-asset
script tests may skip. The audit used Python3.13.5 / NumPy2.3.5 / SciPy1.17.0 / pytest9.0.2.

```
python code/reproduce.py \
  --current-zip /path/phaseB_D4C2a_v4_0.111.0.zip \
  --producer-zip /path/phaseB_D4C2a_v3_0.110.0.zip \
  --comparison-spec /path/D4C2a_v3_0.110.0_bridge_comparison_spec.json \
  --out /path/new_audit_work --full
```

Omit `--full` for guard/algebra/bridge boundaries only. Full replay runs the selected 118 tests
(not all1935), the certificate admission boundary and actual synthetic-False reader.
The composite `reproduce.py` was prepared from the individually executed commands; it was not
itself rerun end-to-end during this turn. The actual fresh repeat was only the two scripts
shown in `results/fresh_quick.json`. Some logs contain initial absolute container paths; fixture
adapters derive work paths relative to their copied `code/` directory. Source originals are
rehash-checked after runs. Prior source ZIPs are deliberately not duplicated in this evidence ZIP.

New bridge findings are scoped to the comparison consumer: trusted producer inventory and
lock/final/twelve-gate provenance; type-strict archive identity; actual profiler-document
coverage. Previous certificate C1/C2/D1 and the history guard are closed by this review.
