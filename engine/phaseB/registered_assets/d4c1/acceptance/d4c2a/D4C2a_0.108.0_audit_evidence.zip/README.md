# D4C-2a 0.108.0 監査証拠

本ZIPは監査側のコード・実行log・検査結果であり、正式screenや較正の成果物ではありません。

- `results/metadata.json`：2,217 SHA、compile、著者JUnitとcollectの照合、登録原本比較。
- `results/test_summary.json` / `selected.xml`：未改変選択pytest 90 PASS / 8 SKIP。
- `results/screen_launcher.json`：正常20gateとscript由来21gateの境界比較、正常/拒否対照。
- `results/certificate_boundaries.json`：証拠の認証不足、N4欠落、family集約と閾値の反例。
- `results/real_partial_certificate.json`：実際の合成partialを変更したとき、元readerは拒否、certificate helperは受理。
- `results/mode_profiler_boundaries.json`：certificate環境入口、segment外の行別保存、profiler entry例外のcleanup。
- `results/execution_settings.json`：今回GOを出した計測probe限定の値（nonceなし）。
- `results/source_excerpts.txt`：問題箇所の提出source line番号。
- `results/preservation.json`：sourceの保全。
- `fresh/`：別の空workで3つの境界scriptを再実行した結果。pytest全体の再実行ではありません。

追加probeは意図的に拒否不足を検出する対照を含みます。実行終了コード0は、提出実装が全件正しいという意味ではなく、記録した境界試験が完了したという意味です。提出pytestのPASS件数と混ぜないでください。

## 再現
元ZIP 2つ（0.108.0と0.107.0）をローカルに用意し、新しい作業先を指定します。

```bash
python code/reproduce.py \
  --source /path/phaseB_D4C2a_0.108.0.zip \
  --previous /path/phaseB_D4C1_v2_0.107.0.zip \
  --out /path/new_audit_work
```

`--quick`は独立境界とmetadataのみで、選択pytest・実合成partial比較を省きます。固定SHAが違う改訂版では停止します。原本とこの監査結果を上書きしません。監査環境はPython3.13.5 / NumPy2.3.5 / SciPy1.17.0、登録Colab環境ではありません。外部資産依存のscript試験はSKIPされています。

## 範囲
正式bankのintake、実2000行screen、正式certificate、Colab、実target、remote Gitの照合はしていません。合成試験やTEST-ONLY fixtureを正式な科学的成功へ昇格しません。全1,923件のpytestを独立実行したものではありません。
