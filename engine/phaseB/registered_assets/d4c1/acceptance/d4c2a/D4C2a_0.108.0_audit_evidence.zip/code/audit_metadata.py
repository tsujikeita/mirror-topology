from pathlib import Path
import json, hashlib, ast, collections, xml.etree.ElementTree as ET, sys
R=Path(__file__).resolve().parents[1]; P=R/'work/submitted/phaseB'; OLD=R/'work/previous/phaseB'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
i=json.loads((P/'B2_completion_inventory.json').read_text()); checks=[]
for section in ['modules','tests_sha256','fixtures_sha256','assets_sha256','documents_sha256','b3_sha256','registered_assets_sha256','d_sha256']:
 prefix={'modules':'step1_engine','tests_sha256':'tests','fixtures_sha256':'tests'}.get(section,'')
 for key,h in i[section].items():
  path=P/prefix/key;checks.append({'section':section,'path':str(path.relative_to(P)),'ok':path.is_file() and sha(path)==h})
compiled=[]
for p in P.rglob('*.py'):compile(p.read_bytes(),str(p),'exec');compiled.append(str(p.relative_to(P)))
nb_comp=[]
for name in ['MirrorTopology_Step1_D4C1_partial_v0.1.ipynb','MirrorTopology_Step1_D4C1_combine_family_v0.1.ipynb','MirrorTopology_Step1_D4C2_screen_v0.1.ipynb']:
 for j,c in enumerate(json.loads((P/'d'/name).read_text())['cells']):
  if c['cell_type']=='code':compile(''.join(c['source']),f'{name}:{j}','exec');nb_comp.append(f'{name}:{j}')
xmls=sorted((P/'regression_logs/d4c2a_pytest').glob('j*.xml'));tc=[n for x in xmls for n in ET.parse(x).iter('testcase')]
# JUnit classname uses tests.test_NAME. Some parametrizations contain absolute checkout paths.
author=collections.Counter((x.attrib.get('classname','').replace('.','/')+'.py::'+x.attrib['name']) for x in tc)
collect=[x.strip() for x in (R/'logs/collect.log').read_text().splitlines() if x.startswith('tests/') and '::' in x]
# only normalize absolute path prefix before /d/notebook.
import re
norm=lambda s:re.sub(r'(?<=\[)/[^\]]*?/d/(?=MirrorTopology_)','<SOURCE>/d/',s)
ac=collections.Counter();cc=collections.Counter()
for k,n in author.items(): ac[norm(k if k.startswith('tests/') else 'tests/'+k)]+=n
for k in collect:cc[norm(k)]+=1
oldreg=[p for p in (OLD/'registered_assets').rglob('*') if p.is_file()]
unchanged=all((P/p.relative_to(OLD)).is_file() and sha(p)==sha(P/p.relative_to(OLD)) for p in oldreg)
probe=P/'registered_assets/d4c1/probes/20261005T100239Z_386d63207c'
origcompare=[]
for p in probe.iterdir():
 o=Path('/mnt/data')/p.name
 if o.is_file():origcompare.append(dict(file=p.name,sha256=sha(p),matches_original=sha(p)==sha(o)))
res={'inventory_sha256':sha(P/'B2_completion_inventory.json'),'inventory_entries':len(checks),'inventory_failures':[c for c in checks if not c['ok']],
'python_compiled':len(compiled),'notebook_cells_compiled':len(nb_comp),'author_junit_files':len(xmls),'author_junit_cases':len(tc),'author_junit_failure':sum(len(x.findall('failure')) for x in tc),'author_junit_error':sum(len(x.findall('error')) for x in tc),'author_junit_skip':sum(len(x.findall('skipped')) for x in tc),'collect_cases':len(collect),'normalized_multiset_equal':ac==cc,'author_only':list((ac-cc).items())[:15],'collect_only':list((cc-ac).items())[:15], 'old_registered_files':len(oldreg),'registered_unchanged':unchanged,'probe_originals':origcompare}
(R/'results/metadata.json').write_text(json.dumps(res,indent=2,ensure_ascii=False));(R/'results/inventory_checks.json').write_text(json.dumps(checks,indent=2));print(json.dumps(res,indent=2,ensure_ascii=False))
