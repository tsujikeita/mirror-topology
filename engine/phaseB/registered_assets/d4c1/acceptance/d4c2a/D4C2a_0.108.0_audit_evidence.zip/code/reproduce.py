#!/usr/bin/env python3
"""Reproduce into a NEW work directory without altering this audit evidence.
No web/Colab or formal bank execution. Requires local numpy/scipy/pytest and
repository optional dependencies for tests not skipped by their own contracts.
"""
import argparse, pathlib, zipfile, hashlib, shutil, os, subprocess, sys, json
ap=argparse.ArgumentParser();ap.add_argument('--source',required=True);ap.add_argument('--previous',required=True);ap.add_argument('--out',required=True);ap.add_argument('--quick',action='store_true',help='only independent boundaries + metadata; skips selected tests and real-partial comparison')
a=ap.parse_args();out=pathlib.Path(a.out).resolve()
if out.exists():raise SystemExit('--out must not exist; keep original audit evidence unchanged')
inputs=[('submitted',pathlib.Path(a.source),'a0fab34aa540b87bf927d9bd0fcb50f1bdc92e4695149ec91bfdaec4738b4b45'),('previous',pathlib.Path(a.previous),'5ce358e12b9d4f756e561912066d9c284792038bc57ed90c4b879410c3795775')]
for label,path,want in inputs:
 if hashlib.sha256(path.read_bytes()).hexdigest()!=want:raise SystemExit('fixed input SHA mismatch: '+label)
for d in ['code','results','logs','work']:(out/d).mkdir(parents=True)
for p in pathlib.Path(__file__).parent.glob('*.py'):shutil.copy2(p,out/'code'/p.name)
for label,path,want in inputs:
 dst=out/'work'/label;dst.mkdir()
 with zipfile.ZipFile(path) as z:
  seen=set();mp={}
  for info in z.infolist():
   pp=pathlib.PurePosixPath(info.filename)
   if info.filename in seen or pp.is_absolute() or '..' in pp.parts or (info.external_attr>>16)&0o170000==0o120000:raise SystemExit('unsafe ZIP member')
   seen.add(info.filename)
   if not info.is_dir():mp[info.filename]=hashlib.sha256(z.read(info)).hexdigest()
  if z.testzip() is not None:raise SystemExit('ZIP CRC mismatch')
  z.extractall(dst)
 (out/'results'/f'{label}_original_map.json').write_text(json.dumps(mp,indent=2))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
P=out/'work/submitted/phaseB';history=[]
def run(tag,args,cwd=P):
 with open(out/'logs'/(tag+'.log'),'w') as log:r=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 history.append({'tag':tag,'returncode':r.returncode});print(tag,r.returncode,flush=True)
 if r.returncode:raise SystemExit('reproduction command failed; log preserved: '+tag)
run('collect',[sys.executable,'-m','pytest','--collect-only','-q','-p','no:cacheprovider'])
run('metadata',[sys.executable,str(out/'code/audit_metadata.py')])
if not a.quick:
 run('selected',[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','tests/test_d4c2a.py','tests/test_d4c2a_script.py','tests/test_d4c1.py','tests/test_d4c1_script.py','--basetemp='+str(out/'work/pytest'),'--junitxml='+str(out/'results/selected.xml')])
for p in ['probe_certificate_boundaries.py','probe_screen_launcher.py','probe_mode_and_profiler_contracts.py']+([] if a.quick else ['probe_real_partial_certificate.py']):run(pathlib.Path(p).stem,[sys.executable,str(out/'code'/p)])
pr={}
for label,_,_ in inputs:
 mp=json.loads((out/'results'/f'{label}_original_map.json').read_text());base=out/'work'/label;bad=[k for k,v in mp.items() if hashlib.sha256((base/k).read_bytes()).hexdigest()!=v];pr[label]={'files':len(mp),'changed':bad,'unchanged':not bad}
(out/'results/reproduction.json').write_text(json.dumps({'commands':history,'preservation':pr,'quick':a.quick},indent=2));print(out)
