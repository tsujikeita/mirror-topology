"""Execute unchanged screen notebook anchor/attempt cells with TEST-ONLY child/Git.
Compare promised 20-key record and script's actually added 21st key.
No Colab, physical bank or real screen execution here.
"""
from pathlib import Path
import os,sys,json,hashlib,types,contextlib,io,ast,copy
R=Path(__file__).resolve().parents[1];P=R/'work/submitted/phaseB';sys.path[:0]=[str(P),str(P/'tests')]
from test_d4c1_script import _fake_source,_roots,_ns,_lock_src
nb=P/'d/MirrorTopology_Step1_D4C2_screen_v0.1.ipynb';locksrc,attemptsrc=_lock_src(nb)
tree=ast.parse((P/'d/d4c1_calibration.py').read_text()); req=next(ast.literal_eval(st.value) for st in tree.body if isinstance(st,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='REQUIRED_SCREEN' for x in st.targets))
# execute exact script assignment that happens before the screen dispatch
assign=next(x for x in ast.walk(tree) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Subscript) and ast.unparse(t)=="G['G_d3b_units_accepted']" for t in x.targets))
probeG={k:True for k in req}; env={'G':probeG,'twelve':True,'formal':False};exec(compile(ast.Module(body=[assign],type_ignores=[]),'submitted-assignment','exec'),env)
assert set(probeG)-set(req)=={'G_d3b_units_accepted'}
results=[]
for case in ['exact20_baseline','script21_extra_gate','missing_gate','nonobject_doc','wrong_context','staged_baseline','script_changed_prelaunch']:
 temp=R/'work/launcher'/case;temp.mkdir(parents=True,exist_ok=True);mt,pb,RA=_fake_source(temp/'scratch');d2,d3=_roots(temp);out=temp/'out';ns=_ns(temp,'a'*40,mt,pb,RA,out,d2,d3,case.startswith('staged'),fam='E2')
 with contextlib.redirect_stdout(io.StringIO()):exec(compile(locksrc,'screen_anchor','exec'),ns)
 calls=[]
 def check_output(args,**kw):return ns['lock']['commit'] if args[-1]=='HEAD' else ''
 def child(args,**kw):
  calls.append(args);lock=ns['lock'];rd=Path(args[args.index('--out')+1]);rd.mkdir();att=args[args.index('--attempt-id')+1]
  doc={'schema':'position_envelope_screen_v1','family':'E2','engine_version':lock['engine'],'target_commitment':lock['target_commitment'],'pseudo':dict(n=2000,sha256_T1='t'*64,sha256_T2='u'*64),'w2_context_sha256':'c'*64,'rows':list(range(2000)),'n_rows':2000,'results':[{}]*2000,'w2':{s:{} for s in ['L1.00','L1.20','L1.50']},'binding':{'screen_sha256':'s'*64},'campaign':{'id':lock['campaign_id'],'screen':True}}
  if case=='nonobject_doc':doc=None
  if case=='wrong_context':doc['w2_context_sha256']='0'*64
  f='d4c1_screen_E2_record.json';b=json.dumps(doc).encode();(rd/f).write_bytes(b)
  g={k:True for k in req}
  if case=='script21_extra_gate':g=dict(probeG)
  if case=='missing_gate':del g['G_env_lock']
  v={'schema':'d4c1_run_record_v1','mode':'screen','family':'E2','D4C1_SCREEN_COMPLETE':True,'D4C1_PARTIAL_PASS':False,'row_range':None,'stage':'complete','gates':g,'required_inventory':list(req),'required_all_true':True,'failures':[],'seconds':1.,'selftest':False,'formal':True,'probe':False,'profile':'production_official','screen':{'screen_sha256':'s'*64,'n_blocking':0},'pseudo':{'identity':{'T1_sha256':'t'*64,'T2_sha256':'u'*64,'paired_sha256':'p'*64}},'w2_context':{'context_sha256':'c'*64},'published_evidence':{f:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}},'attempt':{'attempt_id':att,'launcher_lock_sha256':ns['LOCK_SHA256']},'source':{'script_sha256':lock['script_sha256'],'inventory_sha256':lock['inventory_sha256'],'pins_sha256':lock['pins_sha256'],'engine_version':lock['engine']},'target_commitment':lock['target_commitment'],'campaign_id':lock['campaign_id']}
  (rd/'d4c1_screen_E2_run.json').write_text(json.dumps(v));return types.SimpleNamespace(returncode=0,stdout='TEST-ONLY',stderr='')
 ns['subprocess']=types.SimpleNamespace(check_output=check_output,run=child)
 if case=='script_changed_prelaunch':Path(ns['SCRIPT']).write_text(Path(ns['SCRIPT']).read_text()+'\n# TEST mutation\n')
 stdout=io.StringIO()
 with contextlib.redirect_stdout(stdout):exec(compile(attemptsrc,'screen_attempt','exec'),ns)
 fin=json.loads((out/'d4c1_screen_final_record.json').read_text());(R/'logs'/f'screen_launcher_{case}.log').write_text(stdout.getvalue())
 results.append({'case':case,'child_calls':len(calls),'screen_complete':fin['screen_complete'],'gates_ok':fin['gates_ok'],'bindings_ok':fin['bindings_ok'],'evidence_ok':fin['evidence_ok'],'failures':fin['failures'],'stage':fin['stage']})
(R/'results/screen_launcher.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
