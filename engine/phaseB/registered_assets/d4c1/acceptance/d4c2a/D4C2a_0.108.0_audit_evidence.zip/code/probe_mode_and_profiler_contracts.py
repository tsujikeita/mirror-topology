"""Source-bound small boundary probes; no Colab or production bank."""
from pathlib import Path
import ast,json,sys,types,time
R=Path(__file__).resolve().parents[1];P=R/'work/submitted/phaseB';sys.path.insert(0,str(P))
from step1_engine.official_gate import current_env, EXPECTED_VERS
from step1_engine.profiling import Profiler
from step1_engine import serialization as ser, archive as aa
from step1_engine import orchestrator as oo
from step1_engine import d4c1_partial as dp
from step1_engine import threshold_evaluator as te
source=(P/'d/d4c1_calibration.py').read_text();t=ast.parse(source); main=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='main')
G={'G_env_lock':False};rr={'failures':[]}; a=types.SimpleNamespace(mode='certificate',selftest_skip_env_lock=False)
node=next(x for x in ast.walk(main) if isinstance(x,ast.If) and 'not G[\'G_env_lock\']' in ast.unparse(x.test))
f=ast.FunctionDef(name='guard',args=ast.arguments(posonlyargs=[],args=[],kwonlyargs=[],kw_defaults=[],defaults=[]),body=[node,ast.Return(value=ast.Constant(value='CONTINUE'))],decorator_list=[])
ns={'G':G,'a':a,'R':rr,'finish':lambda code,stage:dict(code=code,stage=stage)};exec(compile(ast.fix_missing_locations(ast.Module(body=[f],type_ignores=[])),'actual-main-env-guard','exec'),ns)
out={'certificate_environment_guard':{'guard_source':ast.get_source_segment(source,node),'without_skip':ns['guard'](),'failures':list(rr['failures']),'actual_env':current_env().get('python'),'expected_python':EXPECTED_VERS['python']}}
a.selftest_skip_env_lock=True;out['certificate_environment_guard']['with_selftest_skip']=ns['guard']();out['certificate_environment_guard']['note']='main defines selftest = selftest_small OR selftest_skip_env_lock OR selftest_fixture, so skip prevents formal COMPLETE.'
# Outside-segment includes per-row persistence. Demonstrate via two wrappers with
# TEST-ONLY lightweight evaluator substituted, not the numerical evaluator.
originals=[(te,'evaluate_family_full',te.evaluate_family_full),(dp,'evaluate_family_full',dp.evaluate_family_full)]
import step1_engine.integrated_runner as ir
originals.append((ir,'evaluate_family_full',ir.evaluate_family_full))
def lightweight(): return 'TEST_ONLY'
for mod,key,_ in originals:setattr(mod,key,lightweight)
counts=[]
try:
 for n in [1,3]:
  d=R/'work'/f'profile_outside_{n}'; ar=aa.Archive(str(d),deferred_index=True)
  with Profiler(targets={'threshold_evaluator.evaluate_family_full':[('threshold_evaluator','evaluate_family_full'),('d4c1_partial','evaluate_family_full'),('integrated_runner','evaluate_family_full')],'archive.Archive.put':[('archive','Archive.put')],'archive.Archive.flush':[('archive','Archive.flush')]}) as pr:
   for j in range(n):te.evaluate_family_full(); ar.put('transition',{'test':j},{'kind':'TEST_ONLY'})
   ar.flush()
  rec=pr.report();counts.append({'n':n,'segments':rec['segments']['count'],'outside_put_calls':rec['targets']['archive.Archive.put']['outside_segments']['calls']})
finally:
 for mod,key,orig in originals:setattr(mod,key,orig)
out['outside_is_not_all_fixed']=counts
# Alias mismatch during __enter__: test-only changed alias triggers normal guard.
orig1,orig2=oo._family_Q,oo._family_logD
try:
 te._audit_alias_for_profile=lambda:None
 pr=Profiler(targets={'orchestrator._family_Q':[('orchestrator','_family_Q')], 'orchestrator._family_logD':[('orchestrator','_family_logD'),('threshold_evaluator','_audit_alias_for_profile')]})
 try:pr.__enter__();out['enter_failure']='unexpected success'
 except Exception as ex:out['enter_failure']={'error':repr(ex),'first_target_restored':oo._family_Q is orig1,'active':pr._active,'installed_count':len(pr._installed)}
finally:
 oo._family_Q=orig1;oo._family_logD=orig2
 if hasattr(te,'_audit_alias_for_profile'):del te._audit_alias_for_profile
(R/'results/mode_profiler_boundaries.json').write_text(json.dumps(out,indent=2,default=str));print(json.dumps(out,indent=2,default=str))
