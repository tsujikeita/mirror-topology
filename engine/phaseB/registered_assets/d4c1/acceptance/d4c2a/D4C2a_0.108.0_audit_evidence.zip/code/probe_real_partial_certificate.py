"""Replay a genuinely generated synthetic partial from selected tests. Edit only
its eligible status + payload checksum, leave referenced archive unchanged.
Compare the real partial reader to the submitted certificate consumer. Test-only,
smoke n=4; not a registered production certificate.
"""
from pathlib import Path
import sys, json, copy,types,importlib.util,hashlib
R=Path(__file__).resolve().parents[1];P=R/'work/submitted/phaseB';sys.path.insert(0,str(P))
from step1_engine import serialization as ser
from step1_engine.archive import Archive,ArchiveRef
from step1_engine.d4c1_partial import verify_partial_record,_payload_sha
ar=Archive(str(R/'work/pytest/subs0/combined'))
e=next(e for e in ar._entries() if e['kind']=='transition' and e['identity'].get('kind')=='family_partial_calibration')
d=ser.from_jsonable(ar.get(ArchiveRef(**{k:e[k] for k in ['kind','sha256','path','identity']})))
result={'baseline_reader':verify_partial_record(d,ar,current_source_binding=True)}
bad=copy.deepcopy(d);old=bad['per_pseudo_status'][0]['eligible_truths']['support'];bad['per_pseudo_status'][0]['eligible_truths']['support']=False if old is True else True;bad['binding']['partial_sha256']=_payload_sha(bad)
try:verify_partial_record(bad,ar,current_source_binding=True);result['changed_reader']='unexpected accepted'
except Exception as ex:result['changed_reader']={'rejected':True,'error':repr(ex)}
sp=importlib.util.spec_from_file_location('submitted_certificate',P/'d/d4c1_calibration.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
for label,doc in [('baseline',d),('edited',bad)]:
 folder=R/'work'/f'real_partial_{label}';folder.mkdir(exist_ok=True);out=R/'work'/f'real_partial_{label}_certificate';out.mkdir(exist_ok=True)
 (folder/'d4c1_partial_E7_record.json').write_text(ser.dumps(doc));(folder/'d4c1_partial_E7_run.json').write_text(json.dumps({'stage':'complete','failures':[],'campaign_id':'TEST_CERT_FROM_SMOKE','probe':False}))
 ps=doc['thresholds']['pseudo'];cols={'n':ps['n'],'identity':{'T1_sha256':ps['sha256_T1'],'T2_sha256':ps['sha256_T2']}};a=types.SimpleNamespace(screen=[],evaluated=[str(folder)],campaign_id='TEST_CERT_FROM_SMOKE',target_commitment=doc['thresholds']['target_commitment'])
 r={'failures':[]};g={k:True for k in m.REQUIRED_CERTIFICATE};f=lambda code,stage:{'code':code,'stage':stage}
 ret=m._certificate(a,str(out),r,g,lambda *x:None,lambda *x:None,f,cols,False,m._publish_record,ser)
 result[label+'_certificate_consumer']={'return':ret,'G_sources_loaded':g['G_sources_loaded'],'counts':r.get('certificate',{}).get('levels'),'failures':r['failures']}
result['edited_support']={'before':old,'after':bad['per_pseudo_status'][0]['eligible_truths']['support']}
(R/'results/real_partial_certificate.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
