"""Independent TEST-ONLY boundary probes. No production bank/official calibration is run.
Calls the submitted certificate helper after preflight, with real registered pseudo
identities but intentionally incomplete input run fixtures. Also checks public math APIs.
"""
from pathlib import Path
import sys,json,copy,hashlib,importlib.util,types,ast
R=Path(__file__).resolve().parents[1];P=R/'work/submitted/phaseB';sys.path.insert(0,str(P))
from step1_engine import serialization as ser
from step1_engine.infeasibility import *
from step1_engine.d4c0_registry import PSEUDO
sp=importlib.util.spec_from_file_location('submitted_d4',P/'d/d4c1_calibration.py'); mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
print('PSEUDO keys',list(PSEUDO))
# NPZ raw columns are exact registered artifact; this probe does NOT claim a genuine run.
npz=next((P/'registered_assets/d4c0/pseudo').rglob('d4_pseudo_columns.npz'))
import numpy as np
with np.load(npz,allow_pickle=False) as z:
 T1=z['T1'];T2=z['T2']
pid={'n':2000,'sha256_T1':hashlib.sha256(T1.tobytes()).hexdigest(),'sha256_T2':hashlib.sha256(T2.tobytes()).hexdigest()}
cols={'n':2000,'identity':{'T1_sha256':pid['sha256_T1'],'T2_sha256':pid['sha256_T2']}}
results=[];root=R/'work/cert_probes';root.mkdir(exist_ok=True)
def record(name,fn):
 try:out=fn();results.append({'name':name,'accepted':True,'result':out})
 except Exception as ex:results.append({'name':name,'accepted':False,'error':repr(ex)})
def ev(fam, val, r=0):return {r:dict(kind='evaluated',family=fam,status=dict(support=val,strong=val),source_sha256='a'*64)}
for name,maps in [('same_family_same',[ev('E2','unknown'),ev('E2','unknown')]),('different_family_true_unknown',[ev('E2','unknown'),ev('E7','True')]),('different_family_true_tech',[ev('E2','True'),ev('E7','technical_fail')]),('same_family_contradiction',[ev('E2','True'),ev('E2','unknown')])]:
 record(name,lambda maps=maps:infeasibility_certificate(2000,maps,pseudo_identity=pid)['levels'])
record('swapped_thresholds',lambda:infeasibility_certificate(2000,[{r:ev('E2','unknown',r)[r] for r in range(12)}],pseudo_identity=pid,thresholds={'support':0.01,'strong':0.05})['levels'])
# Each 81-row fixture has original registered column identities, but no archive,
# no valid partial schema/payload/gate/source: only fields the consumer reads.
def call_helper(tag,rec,run,kind='evaluated'):
 d=root/tag;d.mkdir(exist_ok=True);out=root/(tag+'_out');out.mkdir(exist_ok=True)
 prefix='screen' if kind=='screen' else 'partial'
 (d/f'd4c1_{prefix}_E2_record.json').write_text(ser.dumps(rec));(d/f'd4c1_{prefix}_E2_run.json').write_text(json.dumps(run))
 a=types.SimpleNamespace(screen=[str(d)] if kind=='screen' else [],evaluated=[str(d)] if kind!='screen' else [],campaign_id='TEST_CAMPAIGN',target_commitment='c'*64)
 rr={'failures':[]};gg={k:True for k in mod.REQUIRED_CERTIFICATE};finish=lambda code,stage:dict(code=code,stage=stage)
 ret=mod._certificate(a,str(out),rr,gg,lambda *a:None,lambda *a:None,finish,cols,True,mod._publish_record,ser)
 return {'finish':ret,'G_sources_loaded':gg['G_sources_loaded'],'gates_all_true':all(gg.values()),'levels':rr.get('certificate',{}).get('levels'),'failures':rr['failures'],'archive_exists':(d/'archive').exists()}
rec={'schema':'THIS_IS_NOT_A_PARTIAL','family':'E2','thresholds':{'pseudo':pid,'target_commitment':'c'*64},'per_pseudo_status':[{'family':'E2','eligible_truths':{'support':'unknown','strong':'unknown'}} for _ in range(81)],'binding':{'partial_sha256':'0'*64}}
run={'D4C1_PARTIAL_PASS':True,'campaign_id':'TEST_CAMPAIGN','stage':'exception','failures':['TEST_FAILURE'],'selftest':False,'probe':False}
record('unverified_evaluated_no_archive_wrong_schema_81',lambda:call_helper('unverified81',rec,run))
# An internally correct screen fixture, then an N4-omission attack (source hash in run is kept original).
scr={'schema':SCREEN_SCHEMA,'engine_version':'0.108.0','family':'E2','sizes':['L1.00','L1.20','L1.50'],'w2':{s:{'trigger':'unknown' if s=='L1.20' else False} for s in ['L1.00','L1.20','L1.50']},'w2_applicable':True,'pseudo':pid,'rows':list(range(81)),'n_rows':81,'n_blocking':0,'results':[],'target_commitment':'c'*64,'binding':{}}
for r in scr['rows']:
 sizes={}
 for s in scr['sizes']:
  positions={str(j):{'stages':{'N0':{'hits':100,'N':1000,'P':.1},'N4':{'hits':2000,'N':4000,'P':.5}}} for j in [1,2,3]}
  sizes[s]={'positions':positions,'min_P':.1,'max_P':.5,'ratio_bound':5.,'all_positive':True,'ok':False}
 scr['results'].append({'row':r,'threshold':[float(T1[r]),float(T2[r])],'sizes':sizes,'blocking':False})
def restamp(d):d['binding']['screen_sha256']=hashlib.sha256(ser.dumps({k:v for k,v in d.items() if k!='binding'}).encode()).hexdigest()
restamp(scr); original_sha=scr['binding']['screen_sha256'];record('screen_baseline_checked',lambda:check_screen_record(scr))
bad=copy.deepcopy(scr)
for x in bad['results']:
 for v in x['sizes'].values():
  for p in v['positions'].values():del p['stages']['N4']
  v.update(min_P=.1,max_P=.1,ratio_bound=1.,all_positive=True,ok=True)
 x['blocking']=True
bad['n_blocking']=81;restamp(bad)
record('screen_missing_N4_rehashed',lambda:check_screen_record(bad))
runS={'D4C1_SCREEN_COMPLETE':True,'campaign_id':'TEST_CAMPAIGN','stage':'exception','failures':['TEST_FAILURE'],'published_evidence':{'d4c1_screen_E2_record.json':{'sha256':'0'*64,'bytes':1}},'screen':{'screen_sha256':original_sha}}
record('certificate_missing_N4_stale_publication_and_failed_run',lambda:call_helper('screen_bad',bad,runS,'screen'))
(R/'results/certificate_boundaries.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
