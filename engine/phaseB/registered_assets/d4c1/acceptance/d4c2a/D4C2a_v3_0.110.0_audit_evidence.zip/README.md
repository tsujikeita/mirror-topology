# D4C-2a v3 / 0.110.0 audit evidence

This bundle contains the actual audit code, logs, results, the signed-scope-style decision (not a cryptographic signature), and the proposed predeclared environment-bridge comparison criteria. It contains NO production banks and NO valid production infeasibility certificate. The count tables and producer run records used by the certificate tests are explicitly TEST-ONLY boundary fixtures.

See the root audit report and decision. Python3.13.16/Colab was not run by the auditor. Actual audit environment: Python3.13.5, NumPy2.3.5, SciPy1.17.0. Official gate version controls use injected snapshots and remain whole-gate failures on synthetic profiles.

## Reproduction

Place these original inputs in one directory:
- phaseB_D4C2a_v3_0.110.0.zip
- phaseB_D4C2a_v2_0.109.0.zip
- D4C2a_v2_0.109.0_audit_evidence.zip
- d4c1_partial_E2_231d37b89271.zip

Run in an environment with the test dependencies installed:

```sh
python code/reproduce.py --input-dir /path/to/originals --output /path/to/new_audit_work
```

The output directory must not exist. Modules execute only in extracted source/work copies, with Python bytecode and pytest source cache suppressed. No Drive, Colab or network access is performed by these audit scripts. Source path strings in the original logs differ from a fresh reproduction. Some timings will differ; comparisons and refusal results are the evidence.

Actual executions in this audit: D4C2a submitted tests21 PASS/7 SKIP; registration regressions82 PASS/0 SKIP, one full-plan test deliberately excluded. Prior certificate and algebra probes were reused; real-partial admission uses the synthetic archive produced by the actual submitted tests. Fresh-copy replay repeated algebra and whole-hash metadata counterexamples only, NOT the entire suite. The all-in-one convenience wrapper itself was not executed end to end here.

`environment_controls_initial.*` preserves an audit-harness summary error (nonexistent as_dict method) after the W2 loader had returned. Corrected public-attribute summary and full rerun are in `environment_controls.*`; this is not a submission defect.

`whole_hash_counterexample.json` is a metadata-only in-memory counterexample, not new numerical output. `bridge_comparison_spec.json` fixes15 typed per-row scientific records and lists invariant fields; full engine/provenance-bearing hashes are intentionally NOT equality targets across epochs.
