"""Counterexample to an entire-record hash equality requirement across a source/version change.
Edits are on in-memory copies of the old probe metadata, NOT a run in Python 3.13.16.
"""
from pathlib import Path
import json,copy,zipfile,hashlib,sys,os
A=Path(__file__).resolve().parents[1];P=A/'work/current/phaseB';sys.path[:0]=[str(P)]
from step1_engine import serialization as ser,__version__
from step1_engine.d4c1_partial import _payload_sha
Z=Path(os.environ.get('AUDIT_INPUT_DIR','/mnt/data'))/'d4c1_partial_E2_231d37b89271.zip';z=zipfile.ZipFile(Z)
name=next(n for n in z.namelist() if n.endswith('/d4c1_probe_E2_record.json'));old=ser.loads(z.read(name).decode())
scientific_fields=['schema','kind','mode','family','registry_sha256','manifest_sha256','w2_context_sha256','w2_asset_sha256','sizes','fingerprints','thresholds','archive_refs','per_pseudo_status','per_pseudo_diagnostics','per_pseudo_manifest_keys','w2_context_ref','campaign','plan_objects','scope']
old_h=_payload_sha(old);assert old_h==old['binding']['partial_sha256']
variants=[]
for tag,fn in [('only_top_level_engine',lambda d:d.update(engine_version=__version__)),('only_recorded_python',lambda d:d['gate']['diagnostics']['env'].update(python='3.13.16'))]:
 d=copy.deepcopy(old);fn(d);h=_payload_sha(d)
 assert h!=old_h;assert all(ser.dumps(d[k])==ser.dumps(old[k]) for k in scientific_fields)
 variants.append(dict(tag=tag,payload_sha256=h,all_scientific_fields_unchanged=True,source_was_not_executed=True))
idxname=next(n for n in z.namelist() if n.endswith('/archive/index.json'));idx=ser.loads(z.read(idxname).decode());pre=idxname[:-len('index.json')];invariants=[];outside=[]
for e in idx['entries']:
 b=z.read(pre+e['path']);assert hashlib.sha256(b).hexdigest()==e['sha256'];d=ser.loads(b.decode())
 if e['kind'] in ('family_result','three_position_result') or d.get('kind')=='pseudo_family_plan':
  row=(d.get('pseudo_index') if d.get('kind')=='pseudo_family_plan' else d.get('evidence',{}).get('pseudo_index'))
  invariants.append(dict(kind=e['kind'],identity=e['identity'],sha256=e['sha256'],bytes=len(b),row=row,has_engine_field='engine_version' in d,has_binding_field='binding' in d))
 else:outside.append(dict(kind=e['kind'],document_kind=d.get('kind'),sha256=e['sha256']))
assert len(invariants)==15
spec=dict(schema='D4C2a_environment_bridge_comparison_spec_v1',scope='Acceptance criteria for one E2 N=3 environment/profiling probe; not a global numerical equivalence proof',baseline_zip_sha256=hashlib.sha256(Z.read_bytes()).hexdigest(),baseline_partial_payload=old_h,new_engine=__version__,old_python='3.13.15',new_python='3.13.16',whole_partial_sha_must_match=False,whole_archive_sha_set_must_match=False,raw_originals_must_be_preserved=True,required_exact_per_row_records=invariants,other_archive_records=outside,required_equal_partial_fields=scientific_fields,comparison_notes=[
 'Map records by their typed identity and global row/size; require exact canonical bytes and content SHA for these 15 per-row records, with no missing/extra/duplicate rows.',
 'The fourth transition is the aggregate family_partial_calibration record, not a per-row pseudo_family_plan. Its whole SHA is allowed and expected to change.',
 'Verify the old and new record payload/file hashes and archived references separately. New record must pass its unmodified own reader with current_source_binding=True.',
 'Do NOT overwrite the old record or re-label the new record as engine0.107 or Python3.13.15.',
 'New binding must identify the new fixed module SHA map, rules/tables and registered constants; invariant science/input dependency fields must equal baseline.',
 'Do not require whole gate dict equality: recorded env and registered expected Python differ. Both gates must be independently valid in their own execution epoch; new precheck/prelaunch and twelve gate must be live collected, exact new six versions and BLAS constraints.',
 'Exact numeric per-row comparison is for the fixed first3 only; it excludes unexercised N4/KDE-CI/12-position numerical paths and does not approve screening/certificates/target.',
 'On mismatch preserve artifacts and stop for analysis; distinguish expected metadata differences from any actual numeric/state/identity differences. No retry-until-match or retrospectively chosen tolerance.'
])
(A/'results/bridge_comparison_spec.json').write_text(json.dumps(spec,indent=2))
(A/'results/whole_hash_counterexample.json').write_text(json.dumps(dict(baseline_payload=old_h,variants=variants,per_row_entries=len(invariants),other_entries=outside),indent=2));print(json.dumps(dict(baseline_payload=old_h,variants=variants,per_row_entries=len(invariants),other_entries=outside),indent=2))
