import subprocess,os,json,time
from pathlib import Path
A=Path(__file__).resolve().parents[1];P=A/'work/current/phaseB'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',PYTHONPATH=str(P)+':'+str(P/'tests'))
tasks=[('collect',['python','-m','pytest','--collect-only','-q','-p','no:cacheprovider']),('newtests',['python','-m','pytest','tests/test_d4c2a.py','tests/test_d4c2a_script.py','-q','-p','no:cacheprovider','--basetemp='+str(A/'work/pytest_new'),'--junitxml='+str(A/'results/newtests.xml')]),('previous_certificate',['python',str(A/'code/probe_certificate_v2.py')]),('previous_algebra',['python',str(A/'code/probe_algebra_v2.py')])]
res=[]
for tag,cmd in tasks:
 t=time.monotonic()
 with open(A/'logs'/f'{tag}.log','w') as f:
  p=subprocess.run(cmd,cwd=P,env=env,stdout=f,stderr=subprocess.STDOUT)
 res.append(dict(tag=tag,command=cmd,rc=p.returncode,seconds=time.monotonic()-t));(A/'results/task_execution.json').write_text(json.dumps(res,indent=2)); print(tag,p.returncode,flush=True)
