"""Reproduce the audit in a NEW directory; never edits submitted archives.
Needs four input ZIPs listed in README.md. The numerical production banks and Colab
are not required; the submitted end-to-end tests with missing assets remain SKIP.
"""
from pathlib import Path
import argparse,shutil,subprocess,os,sys,json
p=argparse.ArgumentParser();p.add_argument('--input-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
source=Path(__file__).resolve().parent;out=a.output.resolve()
if out.exists():raise SystemExit('Output must be new; existing output is never overwritten.')
for d in ('code','logs','results','work'):(out/d).mkdir(parents=True,exist_ok=True)
for f in source.glob('*.py'):shutil.copy2(f,out/'code'/f.name)
env=dict(os.environ,AUDIT_INPUT_DIR=str(a.input_dir.resolve()),PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2')
steps=['prepare.py','run_tasks.py','audit_environment.py','audit_metadata.py','probe_real_partial_admission.py','audit_comparison_contract.py']
status=[]
for s in steps:
 with (out/'logs'/('reproduce_'+s+'.log')).open('w') as f:r=subprocess.run([sys.executable,str(out/'code'/s)],env=env,stdout=f,stderr=subprocess.STDOUT)
 status.append({'script':s,'rc':r.returncode});(out/'results/reproduction_status.json').write_text(json.dumps(status,indent=2))
 if r.returncode:raise SystemExit('Step failed: '+s+'; see saved log.')
# Explicitly selected registered regressions; exclude the memory-heavy full-plan consumer.
cmd=[sys.executable,'-m','pytest','tests/test_d4c0_registration.py','tests/test_d3c_tranche2.py','-k','not consumer_api','-q','-p','no:cacheprovider','--basetemp='+str(out/'work/pytest_registered'),'--junitxml='+str(out/'results/registered_tests.xml')]
with (out/'logs/registered_tests.log').open('w') as f:r=subprocess.run(cmd,cwd=out/'work/current/phaseB',env=env,stdout=f,stderr=subprocess.STDOUT)
status.append({'script':'registered regressions','rc':r.returncode});(out/'results/reproduction_status.json').write_text(json.dumps(status,indent=2))
print(json.dumps(status,indent=2));raise SystemExit(r.returncode)
