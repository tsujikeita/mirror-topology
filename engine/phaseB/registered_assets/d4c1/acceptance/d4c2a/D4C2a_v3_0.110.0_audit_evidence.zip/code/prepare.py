from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,stat,os
BASE=Path(__file__).resolve().parents[1]
INPUT=Path(os.environ.get('AUDIT_INPUT_DIR','/mnt/data'))

def sha(b): return hashlib.sha256(b).hexdigest()
def extract(src,out):
 z=zipfile.ZipFile(src); names=z.namelist(); assert len(names)==len(set(names)); assert z.testzip() is None
 for i in z.infolist():
  p=PurePosixPath(i.filename)
  assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(i.external_attr>>16)
 out.mkdir(parents=True,exist_ok=True); z.extractall(out)
 return {i.filename:sha(z.read(i)) for i in z.infolist() if not i.is_dir()}
meta={}
for name,loc in [('phaseB_D4C2a_v3_0.110.0.zip','current'),('phaseB_D4C2a_v2_0.109.0.zip','previous'),('D4C2a_v2_0.109.0_audit_evidence.zip','previous_evidence')]:
 p=INPUT/name
 m=extract(p,BASE/'work'/loc);meta[loc]={'file':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'files':len(m)}
 (BASE/'results'/f'{loc}_initial_map.json').write_text(json.dumps(m,indent=2))
meta['diff']={'added':sorted(set(json.loads((BASE/'results/current_initial_map.json').read_text()))-set(json.loads((BASE/'results/previous_initial_map.json').read_text())))}
a=json.loads((BASE/'results/current_initial_map.json').read_text());b=json.loads((BASE/'results/previous_initial_map.json').read_text())
meta['diff']['changed']=[k for k in a.keys()&b.keys() if a[k]!=b[k]];meta['diff']['removed']=sorted(b.keys()-a.keys())
(BASE/'results/preparation.json').write_text(json.dumps(meta,indent=2)); print(json.dumps(meta,indent=2))
