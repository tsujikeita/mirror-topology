from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET,shutil,zipfile
A=Path(__file__).resolve().parents[1];P=A/'work/current/phaseB'; OUT=Path('/mnt/data')
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((A/'results/metadata.json').read_text());prep=json.loads((A/'results/preparation.json').read_text())
def totals(path):
 cs=ET.parse(path).getroot().findall('.//testcase')
 return {'cases':len(cs),'passed':sum(not any(c.find(s) is not None for s in ('failure','error','skipped')) for c in cs),'failed':sum(c.find('failure') is not None for c in cs),'errors':sum(c.find('error') is not None for c in cs),'skipped':sum(c.find('skipped') is not None for c in cs),'skip_names':[c.attrib['name'] for c in cs if c.find('skipped') is not None]}
new=totals(A/'results/newtests.xml');reg=totals(A/'results/registered_tests.xml')
preserve={}
for name,base in [('current',A/'work/current'),('previous',A/'work/previous'),('fresh_quick',A/'fresh_quick/work/current')]:
 orig=json.loads((A/'results'/('current_initial_map.json' if name=='fresh_quick' else name+'_initial_map.json')).read_text());now={str(p.relative_to(base)):sha(p.read_bytes()) for p in base.rglob('*') if p.is_file()}
 preserve[name]={'files':len(now),'changed':[k for k in orig.keys()&now.keys() if orig[k]!=now[k]],'added':sorted(now.keys()-orig.keys()),'missing':sorted(orig.keys()-now.keys()),'unchanged':orig==now}
 assert preserve[name]['unchanged']
(A/'results/preservation.json').write_text(json.dumps(preserve,indent=2))
baseprobe=json.loads((OUT/'D4C2a_0.108.0_audit_decision.json').read_text())['probe_execution_settings']
settings=dict(baseprobe,REPO_COMMIT='39082b641d8621989ae69a273f4e88e0c59673ba',EXPECTED_INVENTORY_SHA256=m['inventory_sha256'],scope='E2 first 3 paired rows, current Python3.13.16, instrumented ENVIRONMENT BRIDGE / resource probe ONLY; revised comparison contract applies; no screen/certificate/formal execution')
(A/'results/execution_settings.json').write_text(json.dumps(settings,indent=2))
spec=json.loads((A/'results/bridge_comparison_spec.json').read_text())
specname='D4C2a_v3_0.110.0_bridge_comparison_spec.json';(OUT/specname).write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
dec={
 'schema':'step1_D4C2a_v3_0110_environment_review_v1','date_JST':'2026-10-06',
 'decision':'ENVIRONMENT_AMENDMENT_IN_PRINCIPLE__FIXED_SOURCE_BRIDGE_PROBE_ONLY_GO__SCREEN_CERTIFICATE_HOLD',
 'subject':dict(prep['current'],author_supplied_commit=settings['REPO_COMMIT'],engine='0.110.0',inventory_sha256=m['inventory_sha256'],remote_tree_independently_verified=False,key_files=m['keyfiles']),
 'audit_baseline':{'decision':'D4C2a_v2_0.109.0_audit_decision.json','sha256':sha((OUT/'D4C2a_v2_0.109.0_audit_decision.json').read_bytes()),'note':'The latest three blockers, not just the earlier 0.108 A-D descriptions, are the acceptance baseline.'},
 'GO':{'whole_packet_implementation_acceptance':False,'environment_amendment_policy_in_principle':True,'environment_numerical_bridge_acceptance':False,'fixed_0110_instrumented_E2_N3_HighRAM_bridge_probe_execution':True,'screen_E2_E7_E8_execution':False,'certificate_execution':False,'formal_subpartial_or_combination_execution':False,'formal_global_calibration':False,'usable_or_PhaseE_actual_target':False,'bank_pseudo_W2_regeneration':False},
 'findings':[
 {'id':'R-D4C2A-C1-TRUSTED-RUN-INVENTORY','status':'OPEN_UNCHANGED','evidence':'Driver bytes identical to0.109; unchanged prior probe: remove gate from both inventories, env-only inventory, extra gate in both, empty attempt, wrong pins/profile accepted. Fixed trusted mode inventory and source/attempt/profile checks still needed.'},
 {'id':'R-D4C2A-C2-W2-SUMMARY-BINDING','status':'OPEN_UNCHANGED','evidence':'infeasibility.py bytes identical; registered checksum paired with conflicting B_final/trigger accepted.'},
 {'id':'R-D4C2A-D1-FALSE-EVIDENCE-RETENTION','status':'OPEN_UNCHANGED','evidence':'Both-level False rows discarded before reconciliation; verified synthetic E2 4-row partial yields empty rows, conflicting same-family screen then accepted.'},
 {'id':'R-D4ENV-COMPARISON-CONTRACT','status':'REPLACED_BY_THIS_AUDIT_CONTRACT_FOR_PROBE_ONLY','evidence':'Full partial hash contains engine/modules and gate environment. Editing only engine0.107->0.110 or only env.python15->16 changes hash with all science fields held unchanged. Fourth transition is the partial itself, not a per-row plan.', 'required_condition':'Follow the attached bridge comparison specification; never require old full payload SHA for new provenance; keep original bytes; exact15 per-row content records plus declared invariant fields; source/env separately verified.'},
 {'id':'N-D4ENV-HISTORY-PIN-COMPLETENESS','status':'FIXED_PACKET_PROBE_NOT_BLOCKED__GENERAL_CONTRACT_NEEDS_CLARIFICATION_OR_GUARD','evidence':'Missing/null environment_history is accepted by helper and genuine copied-tree D3c intake; empty/wrong version rejected; metadata-only change accepted. Current submitted six pins have the correct version history and are inventory-bound. Engine whitelist remains limited to exact3.13.15/16 tuples; no new-run15 bypass shown.', 'recommendation':'When pins supplied, require the history field and validate its schema/version tuples; explicitly define whether amendment labels are metadata or authenticated equality fields. Missing/null refusal tests.'}
 ],
 'probe_execution_settings':settings,'comparison_spec':{'file':specname,'sha256':sha((OUT/specname).read_bytes())},
 'probe_conditions':[
 'Fresh default Colab High-RAM runtime; live interpreter must really be3.13.16 with the other five pinned library versions and BLAS rules. Do not install an alternate Python3.12 run or fake/skip gates.',
 'Use exactly the submitted partial notebook and commit/inventory; E2 PROBE_N=3 ROW_RANGE=None INSTRUMENT=True. No self-test flag, no target nonce, no changed seed/pseudo order/rules/banks.',
 'Read historical assets through registered loaders using the exact current pins/inventory; preserve old15 records. No asset regeneration.',
 'Save both failed preflight screenshots/notebooks/logs as failed environment checks, separately from the new attempt; no successful-run promotion.',
 'New partial must pass its own unmodified reader with current_source_binding=True; run/final/lock must agree, all24 gates true, rc0, no fallback/failures, official twelve gate live_collected. Probe formal PASS flags remain False.',
 'Collect profile JSON+receipt, segments=3, missing_targets=[], cProfile; old vs new exact scientific/typed per-row checks as in specification. Outside segments includes row persistence; do not interpret instrumented timings as production speedup.',
 'Full file/payload/archive/index SHA may change due to new provenance; require each original independently valid and never overwrite old metadata to make hashes match.',
 'Any actual science/state/input/plan mismatch: retain evidence and stop for differential analysis, not retry-until-match or retrospective tolerance.',
 'Bridge result must be reviewed before claiming the environment amendment numerically validated; success does not approve certificate, screening or full calibration. No automatic transfer of GO to another commit.'
 ],
 'tests':{'submitted_D4C2a':new,'registered_regressions':reg,'unmodified_pytest_total':{'passed':new['passed']+reg['passed'],'failed':new['failed']+reg['failed'],'errors':new['errors']+reg['errors'],'skipped':new['skipped']+reg['skipped'],'explicitly_deselected':1,'deselected_test':'D3c consumer_api_rebuild_and_refusals (full plan regeneration not part of this review)'},'author_junit_cases':m['junit_cases'],'author_junit_files':len(m['junit']),'author_junit_failures_errors_skips':sum(x['fail']+x['error']+x['skip'] for x in m['junit']),'collect_count':m['collect_cases'],'normalized_multiset_equal':m['multiset_equal'],'all_1927_independently_executed':False,'independent_certificate_cases':18,'independent_accepted_adversarial_cases':8,'environment_controls':19,'whole_hash_metadata_only_counterexamples':2,'exact_per_row_baseline_records':15,'algebra_4family_combinations':256,'fresh_replay':'algebra and hash-contract scripts only; no full pytest repeat'},
 'metadata':{'inventory_hash_entries':m['inventory_hash_entries'],'compiled_python':m['compiled_python'],'compiled_notebook_cells':m['compiled_notebook_cells'],'registered_files':m['registered_files'],'registered_changed':m['registered_changed'],'runtime_used_for_audit':m['environment']},'preservation':preserve,
 'limitations':[
 'No live Colab or Python3.13.16 runtime executed here; environment-policy checks use injected TEST-ONLY snapshots, whole official gates remain false on synthetic bank sizes.',
 'Registered D3c, W2, pseudo loaders were actually executed and original pseudo NPZ validated; no physical bank-array intake, bootstrap plan reconstruction or exact OT rerun.',
 'Certificate fixtures invent counts/producer records to exercise acceptance boundaries. They are NOT real blocking evidence or a scientific impossibility certificate.',
 'Whole hash changes are demonstrated on in-memory metadata-only copies, NOT numerical results in the new environment.',
 'No real2000-row screen, global calibration, actual target or independent remote Git tree comparison.',
 'Actual screenshots prove reported version mismatch and an ImportError, not universal unavailability of3.13.15 or incompatibility of NumPy2.1.3 with Python3.12.',
 'Seven new-script tests skipped due to missing external assets. One D3c full-plan test deliberately excluded.',
 'Initial audit environment harness tried nonexistent VerifiedW2Decision.as_dict; corrected to explicit public attributes and repeated successfully; initial log retained, not a submitted-code failure.'
 ],
 'prior_acceptances_preserved':True,'requires_existing_bank_pseudo_D2W_D3c_regeneration':False,
 'artifacts':{'report':'ChatGPT_audit_D4C2a_v3_0.110.0.md','evidence':'D4C2a_v3_0.110.0_audit_evidence.zip','comparison':specname}}
(OUT/'D4C2a_v3_0.110.0_audit_decision.json').write_text(json.dumps(dec,ensure_ascii=False,indent=2)+'\n')
(A/'results/decision_summary.json').write_text(json.dumps(dec,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'tests':dec['tests'],'preservation':preserve},indent=2))
