"""Actual registered-loader checks + TEST-ONLY injected environment policy checks.
No bank-array intake, plan rebuild, physical generation or Colab runtime execution.
"""
from pathlib import Path
import sys,os,json,copy,hashlib,shutil,time
A=Path(__file__).resolve().parents[1];P=A/'work/current/phaseB';sys.path[:0]=[str(P),str(P/'tests')]
from step1_engine import official_gate as og
from step1_engine.d3_profile import twelve_context
from step1_engine.d3c_ledger import intake_registered_d3c_profiles
from step1_engine.d4c0_registry import load_registered_w2_context,load_registered_pseudo_columns
from step1_engine import serialization as ser
res=[]
def run(name,f):
 t=time.monotonic()
 try: v=f();r=dict(name=name,accepted=True,value=v)
 except Exception as e:r=dict(name=name,accepted=False,error=repr(e))
 r['seconds']=time.monotonic()-t;res.append(r);print(json.dumps(r,default=str),flush=True)
 (A/'results/environment_controls.json').write_text(json.dumps(res,indent=2,default=str))
ctx=twelve_context(str(P));pins=ctx.pins
run('current_and_history_policy',lambda:og.registered_environments(pins))
for version in ['3.13.16','3.13.15','3.13.14','3.12.13']:
 run('recorded_version_'+version,lambda version=version:og.recorded_environment_registered(dict(og.EXPECTED_VERS,python=version),pins))
run('wrong_numpy',lambda:og.recorded_environment_registered(dict(og.EXPECTED_VERS,numpy='2.1.4'),pins))
run('d3c_registered_profiles',lambda:{f:intake_registered_d3c_profiles(str(P),ctx).input_fingerprints(f) for f in ('E2',)})
run('w2_registered_context',lambda:(lambda c,v:dict(context=c.context_sha256,decisions={k:dict(trigger=c.decision_for(k,c.context_sha256).trigger, validation_state=c.decision_for(k,c.context_sha256).validation_state, B_final=c.decision_for(k,c.context_sha256).B_final, checksum=c.decision_for(k,c.context_sha256).checksum) for k in c.decisions} ))(*load_registered_w2_context(str(P),ctx)))
run('pseudo_original_npz',lambda:(lambda c:dict(n=c['n'],identity=c['identity']))(load_registered_pseudo_columns(str(P),ctx)))
for variant in ['missing','null','empty','wrong_version','metadata_only']:
 p=copy.deepcopy(pins)
 if variant=='missing':p.pop('environment_history')
 if variant=='null':p['environment_history']=None
 if variant=='empty':p['environment_history']=[]
 if variant=='wrong_version':p['environment_history'][0]['python']='3.13.14'
 if variant=='metadata_only':p['environment_history'][0]['amendment']='UNTRUSTED_AMENDMENT'
 run('history_helper_'+variant,lambda p=p:og.registered_environments(p))
from test_b2_tranche21 import build_pair
reg,man,fm,fn,*_=build_pair()
for v in ['3.13.16','3.13.15','3.13.14']:
 def testgate(v=v):
  g=og.official_gate(fm,fn,'official',env=dict(og.EXPECTED_VERS,python=v,blas_threads=[dict(api='blas',n=2)]))
  return dict(whole_gate_pass=g.passed,version_mismatch=g.diagnostics['version_mismatch'],environment_source=g.diagnostics['environment_source'],failures=g.required_failures)
 run('injected_live_gate_policy_'+v,testgate)
# Mutation only on copied tree; new genuine context reads altered pins.
CP=A/'work/history_copy';
if CP.exists():shutil.rmtree(CP)
shutil.copytree(P,CP)
pf=CP/'d/d3_pins.json';original=pf.read_bytes()
for var in ['missing','null']:
 p=json.loads(original)
 if var=='missing':p.pop('environment_history')
 else:p['environment_history']=None
 pf.write_text(json.dumps(p));cx=twelve_context(str(CP))
 run('real_registered_d3c_load_history_'+var,lambda cx=cx:intake_registered_d3c_profiles(str(CP),cx).input_fingerprints('E2'))
pf.write_bytes(original)
