"""Independent algebra/admission-adapter checks; synthetic statuses only."""
from pathlib import Path
import sys,json,copy,itertools,hashlib
A=Path(__file__).resolve().parents[1];P=A/'work/current/phaseB';sys.path.insert(0,str(P))
from step1_engine.infeasibility import *
from step1_engine.calibration import any_family_truth
pid=dict(n=2000,sha256_T1='a'*64,sha256_T2='b'*64)
results=[]
def ev(f,v,row=0):return {row:dict(kind='evaluated',family=f,status=dict(support=v,strong=v),source_sha256='c'*64)}
def sc(f='E2',row=0):return {row:dict(kind='screen',family=f,status=dict(support='unknown_or_technical',strong='unknown_or_technical'),source_sha256='d'*64)}
def test(name,fn):
 try:v=fn();results.append(dict(name=name,accepted=True,value=v))
 except Exception as e:results.append(dict(name=name,accepted=False,error=repr(e)))
for name,maps in [('different_family_unknown_true',[ev('E2','unknown'),ev('E7','True')]),('different_family_true_tech',[ev('E2','True'),ev('E7','technical_fail')]),('same_family_unknown_true',[ev('E2','unknown'),ev('E2','True')]),('same_family_screen_unknown',[sc(),ev('E2','unknown')]),('same_family_screen_tech',[sc(),ev('E2','technical_fail')]),('same_family_screen_false_manual',[sc(),ev('E2','False')])]:
 test(name,lambda maps=maps:infeasibility_certificate(2000,maps,pseudo_identity=pid)['rows'])
false_rows=blocking_rows_from_statuses('E2',[dict(family='E2',eligible_truths=dict(support=False,strong=False))],0,'c'*64)
results.append(dict(name='all_false_adapter',accepted=True,value=false_rows))
test('screen_false_via_actual_adapter',lambda:infeasibility_certificate(2000,[sc(),false_rows],pseudo_identity=pid)['rows'])
urows=blocking_rows_from_statuses('E2',[dict(family='E2',eligible_truths=dict(support='unknown',strong='unknown'))],0,'e'*64)
test('evaluated_unknown_false_via_adapter',lambda:infeasibility_certificate(2000,[urows,false_rows],pseudo_identity=pid)['rows'])
test('threshold_swap',lambda:infeasibility_certificate(2000,[sc()],pseudo_identity=pid,thresholds=dict(support=.01,strong=.05)))
test('threshold_mapping_correct',lambda:infeasibility_certificate(2000,[sc()],pseudo_identity=pid)['thresholds'])
# A checksum-restamped mapping swap must still fail the checker.
cert=infeasibility_certificate(2000,[sc()],pseudo_identity=pid);cert['thresholds']=dict(support=.01,strong=.05);cert['binding']['certificate_sha256']=hashlib.sha256(ser.dumps({k:v for k,v in cert.items() if k!='binding'}).encode()).hexdigest()
test('checker_threshold_swap_restamped',lambda:check_certificate(cert))
vals=[True,False,UNKNOWN,TECH];fams=['E1','E2','E7','E8'];conversions={True:'True',False:'False',UNKNOWN:'unknown',TECH:'technical_fail'}
count=0
for vv in itertools.product(vals,repeat=4):
 got=aggregate_rows({0:{f:{lvl:conversions[v] for lvl in LEVELS} for f,v in zip(fams,vv)}})[0]['support']['aggregate'];want=conversions[any_family_truth(vv)]
 assert got==want,(vv,got,want);count+=1
results.append(dict(name='four_family_truth_exhaustive',comparisons=count,pass_all=True))
results.append(dict(name='registered_boundaries',value=registered_blocking_counts()))
(A/'results/algebra_boundaries.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
