"""TEST-ONLY admission boundary fixtures. Uses genuine registered metadata/columns,
but invented count tables and producer run claims, NOT production screen evidence.
No bank/POT/calibration execution. Submitted consumer functions are unmodified.
"""
from pathlib import Path
import sys,json,copy,hashlib,importlib.util,types,os,subprocess
import numpy as np
A=Path(__file__).resolve().parents[1];P=A/'work/current/phaseB';sys.path[:0]=[str(P),str(P/'tests')]
from step1_engine import serialization as ser, __version__
from step1_engine.infeasibility import *
from step1_engine.d3_profile import twelve_context
from step1_engine.d4c0_registry import load_registered_w2_context,load_registered_pseudo_columns
from step1_engine.grid_registry import load_registry
from step1_engine.grid_manifest import build_configuration_manifest
sp=importlib.util.spec_from_file_location('audit_submitted_driver',P/'d/d4c1_calibration.py');M=importlib.util.module_from_spec(sp);sp.loader.exec_module(M)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=A/'work/cert_boundary';root.mkdir(exist_ok=True)
ctx=twelve_context(str(P));w2,view=load_registered_w2_context(str(P),ctx);cols=load_registered_pseudo_columns(str(P),ctx)
reg=load_registry(str(P/'tests/assets/a7_circle_geometry.csv'),str(P/'tests/assets/a6_observer_design_points.json'));man=build_configuration_manifest(reg)
pid={'n':cols['n'],'sha256_T1':cols['identity']['T1_sha256'],'sha256_T2':cols['identity']['T2_sha256']}
configids={}
for c in ctx.d2_spec['configurations'].values():configids.setdefault(c['family'],{}).setdefault(c['size_id'],[]).append(c['config_id'])
for d in configids.values():
 for k in d:d[k].sort()
C='c'*64;camp='AUDIT_TEST_ONLY_NO_SCIENCE';src={'script_sha256':sha(P/'d/d4c1_calibration.py'),'inventory_sha256':sha(P/'B2_completion_inventory.json'),'pins_sha256':sha(P/'d/d3_pins.json'),'engine_version':__version__,'phaseb':str(P),'mt':None}
registered=dict(shared_null_asset_sha256=w2.asset_sha256,w2_context_sha256=w2.context_sha256,registry_sha256=reg.registry_sha256,twelve_assets_sha256=ctx.identities['twelve_assets_sha256'])
wchecks={k:w2.decision_for(k,w2.context_sha256).checksum for k in w2.decisions}
sizes=list(configids['E2'])
def stamp(d):d['binding']['screen_sha256']=hashlib.sha256(ser.dumps({k:v for k,v in d.items() if k!='binding'}).encode()).hexdigest()
scr={'schema':SCREEN_SCHEMA,'engine_version':__version__,'family':'E2','sizes':sizes,'registry_sha256':reg.registry_sha256,'manifest_sha256':man.manifest_sha256,'w2_context_sha256':w2.context_sha256,'w2':w2_triggers('E2',sizes,w2.decisions),'w2_applicable':True,'pseudo':pid,'rows':list(range(81)),'n_rows':81,'n_blocking':81,'complete_coverage':True,'stages_required':['N0','N4'],'registered':dict(N0=RULES.N0,N_max=RULES.N_max),'config_ids':configids['E2'],'fingerprints':{},'results':[],'campaign':dict(id=camp,screen=True,formal=True,rows=[0,81]),'target_commitment':C,'rule':{'test_only':'synthetic count fixture, not observed data'},'binding':binding_manifest()}
for i in scr['rows']:
 ss={}
 for s in sizes:
  pos={}
  for cid in configids['E2'][s]:
   pos[str(cid%100)]=dict(evaluation_id=cid,bank_stages=['N0','N4'],stages={st:dict(hits=N//2,N=N,P=.5) for st,N in [('N0',RULES.N0),('N4',RULES.N_max)]})
  ss[s]=dict(positions=pos,min_P=.5,max_P=.5,ratio_bound=1.,all_positive=True,ok=True,complete_coverage=True,stages_covered=['N0','N4'])
 scr['results'].append(dict(row=i,threshold=[float(cols['T1'][i]),float(cols['T2'][i])],sizes=ss,blocking=True,complete_coverage=True,reason='TEST_ONLY count evidence'))
stamp(scr)
def binder(d):return bind_screen_record(d,registry_sha256=reg.registry_sha256,manifest_sha256=man.manifest_sha256,w2_context_sha256=w2.context_sha256,w2_checksums=wchecks,pseudo_identity=pid,T1=cols['T1'],T2=cols['T2'],config_ids=configids['E2'],family='E2',campaign_id=camp,target_commitment=C)
assert binder(scr)['bound']
run0=dict(schema='d4c1_run_record_v1',mode='screen',family='E2',stage='complete',failures=[],required_inventory=list(M.REQUIRED_SCREEN),gates={k:True for k in M.REQUIRED_SCREEN},required_all_true=True,formal=True,selftest=False,probe=False,profile='production_official',attempt={'attempt_id':'AUDIT_TEST_ONLY_0001','launcher_lock_sha256':'a'*64},campaign_id=camp,target_commitment=C,source=src,D4C1_SCREEN_COMPLETE=True,published_evidence={},screen=dict(screen_sha256=scr['binding']['screen_sha256'],n_blocking=81,n_rows=81))
results=[]
def call(tag,docmod=None,runmod=None,restamp=True):
 d=root/tag;d.mkdir();out=root/(tag+'_out');out.mkdir();doc=copy.deepcopy(scr);run=copy.deepcopy(run0)
 if docmod:docmod(doc)
 if restamp:stamp(doc)
 b=ser.dumps(doc).encode();fn='d4c1_screen_E2_record.json';(d/fn).write_bytes(b)
 run['screen']=dict(screen_sha256=doc['binding']['screen_sha256'],n_blocking=doc['n_blocking'],n_rows=doc['n_rows'])
 run['published_evidence']={fn:dict(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))}
 if runmod:runmod(run)
 (d/'d4c1_screen_E2_run.json').write_text(json.dumps(run))
 a=types.SimpleNamespace(screen=[str(d)],evaluated=[],campaign_id=camp,target_commitment=C)
 R={'source':dict(src),'failures':[]};G={k:True for k in M.REQUIRED_CERTIFICATE}
 ret=M._certificate(a,str(out),R,G,lambda *a:None,lambda *a:None,lambda code,stage:dict(code=code,stage=stage),reg,man,w2,ctx,cols,registered,True,M._publish_record,ser)
 results.append(dict(tag=tag,result=ret,admitted=G['G_sources_loaded'],failures=R['failures'],levels=R.get('certificate',{}).get('levels')))
 return d
baseline=call('baseline_synthetic')
call('gate_false_retained',runmod=lambda r:r['gates'].update(G_inputs_resolved=False))
call('gate_removed_from_both_inventories',runmod=lambda r:(r['gates'].pop('G_inputs_resolved'),r['required_inventory'].remove('G_inputs_resolved')))
call('only_env_gate',runmod=lambda r:r.update(gates={'G_env_lock':True},required_inventory=['G_env_lock']))
call('extra_gate_in_both_inventories',runmod=lambda r:(r['gates'].update(TEST_EXTRA=True),r['required_inventory'].append('TEST_EXTRA')))
call('failed_run',runmod=lambda r:r.update(stage='exception',failures=['TEST_FAILURE']))
call('wrong_run_schema',runmod=lambda r:r.update(schema='WRONG'))
call('stale_publication',runmod=lambda r:r['published_evidence']['d4c1_screen_E2_record.json'].update(sha256='0'*64))
call('wrong_source_script',runmod=lambda r:r['source'].update(script_sha256='0'*64))
call('empty_attempt',runmod=lambda r:r.update(attempt={}))
call('wrong_pins_metadata',runmod=lambda r:r['source'].update(pins_sha256='0'*64))
call('wrong_profile',runmod=lambda r:r.update(profile='NOT_OFFICIAL'))
def drop_n4(d):
 for x in d['results']:
  for v in x['sizes'].values():
   v.update(complete_coverage=False,stages_covered=['N0'])
   for p in v['positions'].values():p['stages'].pop('N4');p['bank_stages']=['N0']
  x['complete_coverage']=False
 d['complete_coverage']=False
call('missing_N4_restamped',docmod=drop_n4)
call('changed_row_threshold',docmod=lambda d:d['results'][0]['threshold'].__setitem__(0,d['results'][0]['threshold'][0]+1.))
call('wrong_config',docmod=lambda d:d['config_ids']['L1.00'].__setitem__(0,99901))
call('wrong_W2_checksum',docmod=lambda d:d['w2']['L1.20'].update(checksum='0'*64))
call('wrong_W2_Bfinal_with_correct_checksum',docmod=lambda d:d['w2']['L1.20'].update(B_final=400))
call('wrong_W2_trigger_with_correct_checksum',docmod=lambda d:d['w2']['L1.00'].update(trigger=UNKNOWN))
# A genuine registered-environment-free CLI execution over TEST-ONLY count fixtures;
# never claim this is a production proof of any real row.
out=root/'cli_test_only';env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2')
cmd=[sys.executable,str(P/'d/d4c1_calibration.py'),'--phaseb',str(P),'--mode','certificate','--out',str(out),'--screen',str(baseline),'--campaign-id',camp,'--target-commitment',C]
with (A/'logs/certificate_cli_test_only.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
rr=json.loads((out/'d4c1_certificate_run.json').read_text()) if (out/'d4c1_certificate_run.json').exists() else {}
cli={'command':cmd,'returncode':r.returncode,'stage':rr.get('stage'),'gates':rr.get('gates'),'complete':rr.get('D4C1_CERTIFICATE_COMPLETE'),'env_gate':rr.get('env_gate'),'failures':rr.get('failures'),'scope':'TEST-ONLY invented count/source fixtures, actual certificate CLI with real registered loaders; not production evidence'}
(A/'results/certificate_boundary.json').write_text(json.dumps({'scope':__doc__,'cases':results,'cli':cli},indent=2))
print(json.dumps({'cases':[{k:v for k,v in x.items() if k!='levels'} for x in results],'cli':cli},indent=2),flush=True)
