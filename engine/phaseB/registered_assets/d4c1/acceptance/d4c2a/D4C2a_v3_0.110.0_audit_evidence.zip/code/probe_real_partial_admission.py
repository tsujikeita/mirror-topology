"""Reuse actual synthetic Results emitted by unmodified selected tests.
No generation and no real-bank scientific result. Verifies new evaluated admission.
"""
from pathlib import Path
import sys,json,copy,hashlib
A=Path(__file__).resolve().parents[1];P=A/'work/current/phaseB';sys.path.insert(0,str(P))
from step1_engine.archive import Archive
from step1_engine.d4c1_partial import load_partial_record
from step1_engine.infeasibility import evaluated_rows_from_record,infeasibility_certificate
from step1_engine import serialization as ser
root=A/'work/pytest_new/test_subpartial_combined_feeds0/p_E2'
ar=Archive(str(root));entry=next(e for e in ar._entries() if e['identity'].get('kind')=='family_partial_calibration')
ref={k:entry[k] for k in ('kind','sha256','path','identity')};p=load_partial_record(ar,ref)
regd=dict(shared_null_asset_sha256=p['w2_asset_sha256'],w2_context_sha256=p['w2_context_sha256'],registry_sha256=p['registry_sha256'],twelve_assets_sha256=p['binding']['twelve_assets_sha256'])
pid={k:p['thresholds']['pseudo'][k] for k in ('n','sha256_T1','sha256_T2')}
results=[]
def check(name,d,archive=ar):
 try:r=evaluated_rows_from_record(d,archive,registered=regd,pseudo_identity=pid,family='E2');results.append(dict(name=name,accepted=True,result=r));return r
 except Exception as e:results.append(dict(name=name,accepted=False,error=repr(e)))
p["binding"]["partial_ref"]=ref
r=check('real_synthetic_normal',p)
assert r is not None, results
raw_false=[i for i,s in enumerate(p['per_pseudo_status']) if s['eligible_truths']['support'] is False and s['eligible_truths']['strong'] is False]
if raw_false:
 i=raw_false[0];screen={i:dict(kind='screen',family='E2',status=dict(support='unknown_or_technical',strong='unknown_or_technical'),source_sha256='d'*64)}
 c=infeasibility_certificate(pid['n'],[screen,r['rows']],pseudo_identity=pid)
 results.append(dict(name='false_is_dropped_before_consistency',raw_false_indices=raw_false,admitted_row_keys=list(r['rows']),conflicting_screen_accepted=True,certificate_row=c['rows'][str(i)],scope='synthetic contradiction boundary, not an authentic screen result'))
q=copy.deepcopy(p);q['schema']='WRONG';check('wrong_schema',q)
q=copy.deepcopy(p);q['per_pseudo_status'][0]['eligible_truths']['support']=True
# The payload can be restamped; the authenticated archive must still reject it.
from step1_engine.d4c1_partial import _payload_sha
q['binding']['partial_sha256']=_payload_sha(q);check('restamped_status_change',q)
check('absent_archive',p,Archive(str(A/'work/empty_for_reader')))
(A/'results/real_evaluated_admission.json').write_text(json.dumps({'scope':__doc__,'cases':results},indent=2,default=str))
print(json.dumps({'scope':__doc__,'cases':results},indent=2,default=str))
