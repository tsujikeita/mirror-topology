from pathlib import Path
import json,hashlib,ast,xml.etree.ElementTree as ET,collections,sys,platform,numpy,scipy,re
A=Path(__file__).resolve().parents[1];P=A/'work/current/phaseB';O=A/'work/previous/phaseB'
sha=lambda b:hashlib.sha256(b).hexdigest()
j=json.loads((P/'B2_completion_inventory.json').read_text());pairs=[]
def walk(x,path=()):
 if isinstance(x,dict):
  for k,v in x.items():
   if isinstance(v,str) and len(v)==64 and re.fullmatch('[0-9a-f]{64}',v):
    # Source inventory uses path keys in several submaps.
    q=P/k
    if not q.is_file() and path and path[-1]=='modules':q=P/'step1_engine'/k
    if q.is_file():pairs.append((str(q.relative_to(P)),v,sha(q.read_bytes())))
   else:walk(v,path+(k,))
 elif isinstance(x,list):
  for v in x:walk(v,path)
# Enumerated schema sections: do not silently skip paths with section-relative roots.
for section in ["modules","tests_sha256","fixtures_sha256","assets_sha256","documents_sha256","b3_sha256","registered_assets_sha256","d_sha256"]:
 prefix={"modules":"step1_engine","tests_sha256":"tests","fixtures_sha256":"tests"}.get(section,"")
 for key,h in j[section].items():
  q=P/prefix/key; pairs.append((str(q.relative_to(P)),h,sha(q.read_bytes()) if q.is_file() else None))
# Match previous audit's entire recursive inventory discovery rather than count unique files only.
errors=[a for a in pairs if a[1]!=a[2]]
compiled=[]
for p in P.rglob('*.py'):compile(p.read_text(encoding='utf-8-sig'),str(p),'exec');compiled.append(str(p.relative_to(P)))
nb=[]
for n in ['MirrorTopology_Step1_D4C1_partial_v0.1.ipynb','MirrorTopology_Step1_D4C1_combine_family_v0.1.ipynb','MirrorTopology_Step1_D4C2_screen_v0.1.ipynb']:
 for i,c in enumerate(json.loads((P/'d'/n).read_text())['cells']):
  if c['cell_type']=='code':compile(''.join(c['source']),n+':'+str(i),'exec');nb.append((n,i))
logs=[];jcases=[]
for p in sorted((P/'regression_logs/d4c2a_pytest').glob('j*.xml')):
 r=ET.parse(p).getroot();cases=r.findall('.//testcase');jcases+=cases
 logs.append(dict(file=p.name,cases=len(cases),fail=sum(c.find('failure') is not None for c in cases),error=sum(c.find('error') is not None for c in cases),skip=sum(c.find('skipped') is not None for c in cases)))
collect=(A/'logs/collect.log').read_text();nodes=[s for s in collect.splitlines() if s.startswith('tests/') and '::' in s]
# Normalize only parameter absolute paths and relative module classnames.
def norm(s):
 return re.sub(r'(\[|\|)/[^\]\|]*?/(engine/)?phaseB/',r'\1<PHASEB>/',s)
actual=collections.Counter(norm(x) for x in nodes);expected=collections.Counter()
for c in jcases:
 cl=c.attrib['classname']; f=cl.replace('.','/')
 if not f.startswith('tests/'):f='tests/'+f
 expected[norm(f+'.py::'+c.attrib['name'])]+=1
regs=list((P/'registered_assets').rglob('*'));rf=[x for x in regs if x.is_file()];changes=[str(x.relative_to(P)) for x in rf if not (O/x.relative_to(P)).is_file() or x.read_bytes()!=(O/x.relative_to(P)).read_bytes()]
keyfiles=['d/d4c1_calibration.py','step1_engine/infeasibility.py','step1_engine/official_gate.py','step1_engine/d3c_ledger.py','step1_engine/d4c0_registry.py','step1_engine/d4c1_partial.py','step1_engine/profiling.py','d/MirrorTopology_Step1_D4C1_partial_v0.1.ipynb']
keys={f:dict(sha256=sha((P/f).read_bytes()),same_previous=(P/f).read_bytes()==(O/f).read_bytes()) for f in keyfiles}
pins={}
for f in ['d/d1_pins.json','d/d2_pins.json','d/d3_pins.json','b3/b3_0_pins.json','b3/b3_1_pins.json','b3/b3_2_pins.json']:
 now=json.loads((P/f).read_text());old=json.loads((O/f).read_text());pins[f]={k:{'previous':old.get(k),'current':now.get(k)} for k in now.keys()|old.keys() if now.get(k)!=old.get(k)}
result=dict(inventory_sha256=sha((P/'B2_completion_inventory.json').read_bytes()),inventory_hash_entries=len(pairs),inventory_errors=errors,compiled_python=len(compiled),compiled_notebook_cells=len(nb),junit=logs,junit_cases=len(jcases),collect_cases=len(nodes),multiset_equal=actual==expected,author_only=list((expected-actual).items())[:12],collect_only=list((actual-expected).items())[:12],registered_files=len(rf),registered_changed=changes,keyfiles=keys,pins_diff=pins,environment=dict(python=sys.version,numpy=numpy.__version__,scipy=scipy.__version__,platform=platform.platform()))
(A/'results/metadata.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['pins_diff','junit']},indent=2))
