# D4C-2a v5 audit evidence
This evidence distinguishes unmodified submitted pytest, synthetic producer-fixture boundary checks, and real scientific runs. No new scientific run occurred here.

- results/metadata.json: SHA/compile/JUnit vs collect/diff.
- results/test_summary.json and pytest_*.xml: 129 passed, 7 skipped, one explicitly deselected.
- results/cross_probes.json and cross/: independent rehashed mutations; normal fixture uses unmodified producer0.110 and original specification.
- results/profile_format_summary.json: actual producer Profiler shape on TEST-ONLY trivial segment bodies; Python metadata altered only in this fixture. Not a numerical bridge.
- results/fresh_summary.json: one fresh ZIP comparison, not all pytest repeated.
- results/preservation.json: source byte preservation.
- code/: reproducing code and usage. No production source was patched.

Run code/reproduce.py --input-dir DIRECTORY --work NEW_DIRECTORY to repeat (requires the named v5/v4/v3 ZIPs, original comparison spec and prior audit files supplied in this conversation, plus current report/design/amendment; Python, numpy, scipy, pytest). Full execution may take several minutes. Paths default to /mnt/data for the captured run.
