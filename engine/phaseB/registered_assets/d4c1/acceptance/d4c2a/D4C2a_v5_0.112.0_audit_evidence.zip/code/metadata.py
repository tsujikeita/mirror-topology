import os
from pathlib import Path
import json,hashlib,ast,collections,xml.etree.ElementTree as ET,re,os,subprocess,sys
D=Path(os.environ.get('D4C_AUDIT_ROOT','/mnt/data/audit_D4C2a_v5')); P=D/'work/current/phaseB'; M=json.loads((D/'results/prepared.json').read_text());inv=json.loads((P/'B2_completion_inventory.json').read_text())
S=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); errs=[]; count=0
for key,vals in inv.items():
 if key=='modules' or key.endswith('_sha256'):
  for name,h in vals.items():
   rel=('step1_engine/'+name if key=='modules' else 'tests/'+name if key in ('tests_sha256','fixtures_sha256') else name)
   f=P/rel;count+=1
   if not f.is_file() or S(f)!=h: errs.append([key,rel,h,S(f) if f.is_file() else None])
py=[p for p in P.rglob('*.py')];perrs=[]
for p in py:
 try:compile(p.read_bytes(),str(p),'exec')
 except Exception as e:perrs.append([str(p.relative_to(P)),repr(e)])
nbnames=['d/MirrorTopology_Step1_D4C1_partial_v0.1.ipynb','d/MirrorTopology_Step1_D4C1_combine_family_v0.1.ipynb','d/MirrorTopology_Step1_D4C2_screen_v0.1.ipynb']; nc=0
for rel in nbnames:
 for c in json.loads((P/rel).read_text())['cells']:
  if c['cell_type']=='code':compile(''.join(c['source']),rel,'exec');nc+=1
A=M['current']['file_map'];B=M['previous']['file_map'];regs=[x for x in B if x.startswith('registered_assets/')]; rc=[x for x in regs if A.get(x)!=B[x]]
reghistory=['registered_assets/d4c1/acceptance/d4c2a/file_map.json'];files_changed=[x for x in B if A.get(x)!=B[x]]
keyfiles={k:A[k] for k in ['d/d4c2_bridge_compare.py','d/d4c1_calibration.py','step1_engine/infeasibility.py','step1_engine/profiling.py','step1_engine/official_gate.py','tests/test_d4c2_bridge.py']}
newimports={}
for rel in ['d/d1_pins.json','d/d2_pins.json','d/d3_pins.json','b3/b3_0_pins.json','b3/b3_1_pins.json','b3/b3_2_pins.json']:
 old=json.loads((D/'work/previous/phaseB'/rel).read_text());new=json.loads((P/rel).read_text());newimports[rel]=[k for k in set(old)|set(new) if old.get(k)!=new.get(k)]
XML=list((P/'regression_logs/d4c2a_pytest').glob('j*.xml')); cases=[];states=collections.Counter()
for f in XML:
 for c in ET.parse(f).getroot().iter('testcase'):
  cases.append((c.attrib.get('classname'),c.attrib['name']));states.update(x.tag for x in c if x.tag in ['failure','error','skipped'])
R=dict(inventory_sha=S(P/'B2_completion_inventory.json'),inventory_entries=count,errors=errs,python_compile_count=len(py),python_compile_errors=perrs,notebook_code_cells=nc,old_registered_count=len(regs),changed_old_registered=rc,new_registered_count=sum(k.startswith('registered_assets/') for k in A),keyfiles=keyfiles,changed=files_changed,added=[x for x in A if x not in B],pin_changes=newimports,author_junit_files=len(XML),author_junit_cases=len(cases),author_junit_states=dict(states))
(D/'results/metadata.json').write_text(json.dumps(R,indent=2));(D/'results/author_case_multiset.json').write_text(json.dumps(cases))
# Current collection no cache and no bytecode
cmd=[sys.executable,'-m','pytest','--collect-only','-q','-p','no:cacheprovider']
e=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',AUDIT_WORKDIR=str(D/'work/collect_artifacts'))
p=subprocess.run(cmd,cwd=P,env=e,capture_output=True,text=True,timeout=180)
(D/'logs/collect.txt').write_text(p.stdout+'\n'+p.stderr);R['collect_rc']=p.returncode
nodes=[l.strip() for l in p.stdout.splitlines() if l.startswith('tests/') and '::' in l]
def nnode(v):
 return re.sub(r'\[/[^\]]*?/d/(MirrorTopology[^\]]*?\.ipynb)',r'[<ROOT>/d/\1',v)
def jnode(c,n):
 if c.startswith('tests.') or '.' in c:c=c.replace('.','/')
 if not c.startswith('tests/'):c='tests/'+c
 return nnode(c+'.py::'+n)
a=collections.Counter(jnode(*x) for x in cases);b=collections.Counter(nnode(x) for x in nodes)
R.update(collect_count=len(nodes),normalized_multiset_equal=a==b,author_only=list((a-b).elements())[:20],collect_only=list((b-a).elements())[:20],normalization='module class to tests/file.py; absolute notebook path prefix to <ROOT>')
(D/'results/metadata.json').write_text(json.dumps(R,indent=2));print(json.dumps({k:v for k,v in R.items() if k not in ['changed','added','keyfiles']},indent=2))
