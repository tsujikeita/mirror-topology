import os
"""TEST ONLY: keep accepted scientific records; rebind metadata to producer 0.110.
No bank, bootstrap or physical computation occurs. Source files are not changed.
"""
from pathlib import Path
import sys, types, json, tempfile, hashlib
D=Path(os.environ.get('D4C_AUDIT_ROOT','/mnt/data/audit_D4C2a_v5')); C=D/'work/current/phaseB'; P=D/'work/producer/phaseB'
sys.path[:0]=[str(P),str(P/'tests')]
m=types.ModuleType('audit_cross_fixture');m.__file__=str(P/'tests/test_d4c2_bridge.py')
exec(compile((C/'tests/test_d4c2_bridge.py').read_text(),str(C/'tests/test_d4c2_bridge.py'),'exec'),m.__dict__)
m.SPEC=str(Path(os.environ.get('D4C_INPUT_DIR','/mnt/data'))/'D4C2a_v3_0.110.0_bridge_comparison_spec.json');m.SCRIPT=str(C/'d/d4c2_bridge_compare.py');m.COMMIT='39082b641d8621989ae69a273f4e88e0c59673ba'
class Factory:
 def mktemp(self,name):return Path(tempfile.mkdtemp(prefix='cross_'+name+'_',dir=D/'work'))
p=m.probes.__wrapped__(Factory())
keep={k:p[k] for k in ['root','base','new','nrun']};keep.update(producer_root=str(P),script=m.SCRIPT,spec=m.SPEC,baseline=m.BASE_ZIP,expected_commit=m.COMMIT,synthetic=True)
(D/'results/cross_fixture.json').write_text(json.dumps(keep,indent=2));print(json.dumps(keep,indent=2))
