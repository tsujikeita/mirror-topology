#!/usr/bin/env bash
# Read-only comparison. Arguments: comparator phaseB tree, producer phaseB tree,
# actual new probe ZIP, NEW output JSON path. No scientific run is started.
set -euo pipefail
if [ "$#" -ne 4 ]; then
  echo 'Usage: use_comparator.sh COMPARATOR_PHASEB_0112 PRODUCER_PHASEB_0110 NEW_PROBE_ZIP NEW_REPORT_JSON' >&2
  exit 2
fi
CMP=$1; PROD=$2; NEW=$3; OUT=$4
SPEC="$CMP/registered_assets/d4c1/acceptance/d4c2a/D4C2a_v3_0.110.0_bridge_comparison_spec.json"
BASE="$CMP/registered_assets/d4c1/probes/20261005T100239Z_386d63207c/d4c1_partial_E2_231d37b89271.zip"
python - "$CMP" "$PROD" "$SPEC" "$BASE" "$OUT" <<'PY'
import sys,hashlib,os
cmp,prod,spec,base,out=sys.argv[1:]
expected={
 os.path.join(cmp,'d/d4c2_bridge_compare.py'):'ca545b61c8b867ec2c36210a77012b2a93b125a2cd04d193e4b8e68ce93fc605',
 os.path.join(prod,'B2_completion_inventory.json'):'7df1fb5948eb2c0c0d379a37afa93c0f1dbc0bba77c01c49d6be60665d9bb1ba',
 spec:'a9cb9ab9b622cb0d929006eac01a957003a5eeffef990a40de8c6338a0981373',
 base:'538f5e07f3c4fae84803d17783ff09a03fef5270cd04b600376e2af891644766'}
for p,h in expected.items():
 with open(p,'rb') as f:actual=hashlib.sha256(f.read()).hexdigest()
 if actual!=h:raise SystemExit('SHA mismatch: '+p)
if os.path.lexists(out):raise SystemExit('Output already exists; choose a new path')
for p in (cmp,prod):
 if os.path.commonpath([os.path.realpath(out),os.path.realpath(p)])==os.path.realpath(p):raise SystemExit('Keep output outside source trees')
PY
PYTHONDONTWRITEBYTECODE=1 python "$CMP/d/d4c2_bridge_compare.py" \
  --phaseb "$PROD" --spec "$SPEC" --baseline "$BASE" --new "$NEW" \
  --expected-commit 39082b641d8621989ae69a273f4e88e0c59673ba --out "$OUT"
