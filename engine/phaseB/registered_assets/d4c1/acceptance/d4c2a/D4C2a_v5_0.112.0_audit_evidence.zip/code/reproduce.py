"""Reproduce this audit in a NEW work directory. Never executes a real bank/probe.
Inputs are the v5,v4,v3 ZIPs, original spec/prior files, and current MDs from the conversation.
"""
import argparse,os,subprocess,sys,shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--input-dir',type=Path,required=True);p.add_argument('--work',type=Path,required=True);a=p.parse_args()
if a.work.exists():p.error('--work must not exist')
a.work.mkdir(parents=True)
for name in ('results','logs','work'): (a.work/name).mkdir()
shutil.copytree(Path(__file__).resolve().parent,a.work/'code')
env=dict(os.environ,D4C_AUDIT_ROOT=str(a.work.resolve()),D4C_INPUT_DIR=str(a.input_dir.resolve()),PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',AUDIT_WORKDIR=str(a.work.resolve()/'work/test_artifacts'))
def run(name,cmd,cwd=None):
 print(name,flush=True)
 with open(a.work/'logs'/(name+'.log'),'w') as log:subprocess.run(cmd,env=env,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,check=True)
run('prepare',[sys.executable,str(a.work/'code/prepare.py')]);run('metadata',[sys.executable,str(a.work/'code/metadata.py')])
root=a.work/'work/current/phaseB'
for name,tests in [('bridge',['tests/test_d4c2_bridge.py']),('contracts',['tests/test_d4c2a.py','tests/test_d4c2a_script.py']),('registered',['tests/test_d4c0_registration.py','tests/test_d3c_tranche2.py','-k','not consumer_api_rebuild_and_refusals'])]:
 cmd=[sys.executable,'-m','pytest','-q','-p','no:cacheprovider',*tests,'--basetemp',str(a.work.resolve()/'work'/('pytest_'+name)),'--junitxml',str(a.work.resolve()/'results'/('pytest_'+name+'.xml'))]
 run('pytest_'+name,cmd,root)
for name in ['cross_fixture','cross_probes','profile_format_control','fresh_check','final_checks']:run(name,[sys.executable,str(a.work/'code'/(name+'.py'))])
print('Completed. Inspect results/ and logs/. Synthetic checks are not a numerical bridge result.')
