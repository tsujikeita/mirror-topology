import os
from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,collections,platform,sys
D=Path(os.environ.get('D4C_AUDIT_ROOT','/mnt/data/audit_D4C2a_v5'));M=json.loads((D/'results/prepared.json').read_text());S=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
preserve={}
for label,m in M.items():
 root=Path(m['root']);now={str(p.relative_to(root)):S(p) for p in root.rglob('*') if p.is_file()};before=m['file_map'];preserve[label]={'files':len(now),'changed':[k for k in before if now.get(k)!=before[k]],'added':[k for k in now if k not in before],'unchanged':now==before}
 assert now==before,(label,preserve[label])
P=Path(M['current']['root']);docs={}
for outer,inner in [('Step1_PhaseD_D4C2a_report(4).md','Step1_PhaseD_D4C2a_report.md'),('Step1_PhaseD_D4C2a_design_v0.4.md','Step1_PhaseD_D4C2a_design_v0.4.md'),('Step1_PhaseD_environment_amendment_v0.3.md','Step1_PhaseD_environment_amendment_v0.3.md')]:
 docs[outer]={'sha256':S(Path(os.environ.get('D4C_INPUT_DIR','/mnt/data'))/outer),'matches_inner':(Path(os.environ.get('D4C_INPUT_DIR','/mnt/data'))/outer).read_bytes()==(P/inner).read_bytes()};assert docs[outer]['matches_inner']
reg=P/'registered_assets/d4c1/acceptance/d4c2a';origins={}
for name in ['ChatGPT_audit_D4C2a_v4_0.111.0.md','D4C2a_v4_0.111.0_audit_decision.json','D4C2a_v4_0.111.0_audit_evidence.zip','D4C2a_v3_0.110.0_bridge_comparison_spec.json']:
 origins[name]={'sha256':S(reg/name),'original_equal':(reg/name).read_bytes()==(Path(os.environ.get('D4C_INPUT_DIR','/mnt/data'))/name).read_bytes()};assert origins[name]['original_equal']
summary={};tot=collections.Counter()
for key in ['bridge','contracts','registered']:
 root=E.parse(D/'results'/('pytest_'+key+'.xml')).getroot();cases=list(root.iter('testcase'));nums=collections.Counter();skips=[]
 for c in cases:
  status=next((x.tag for x in c if x.tag in ('failure','error','skipped')),'passed');nums[status]+=1
  if status=='skipped':skips.append({'name':c.get('name'),'message':c.find('skipped').get('message')})
 summary[key]={'cases':len(cases),**dict(nums),'skips':skips};tot.update(nums)
summary['total']=dict(tot);summary['deselected']='test_d3c_tranche2.py::test_consumer_api_rebuild_and_refusals (full-size plan regeneration not run)'
(D/'results/test_summary.json').write_text(json.dumps(summary,indent=2))
(D/'results/preservation.json').write_text(json.dumps(preserve,indent=2));(D/'results/originals.json').write_text(json.dumps({'outer_documents':docs,'prior_audit_originals':origins},indent=2))
import numpy,scipy,pytest
(D/'results/environment.json').write_text(json.dumps({'python':sys.version,'numpy':numpy.__version__,'scipy':scipy.__version__,'pytest':pytest.__version__,'platform':platform.platform(),'production_environment_reproduced':False},indent=2))
print(json.dumps(summary,indent=2));print(json.dumps(preserve,indent=2));print(json.dumps(docs,indent=2))
