import os
from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,stat
base=Path(os.environ.get('D4C_INPUT_DIR','/mnt/data'));out=Path(os.environ.get('D4C_AUDIT_ROOT',str(base/'audit_D4C2a_v5'))); meta={}
for label,name in [('current','phaseB_D4C2a_v5_0.112.0.zip'),('previous','phaseB_D4C2a_v4_0.111.0.zip'),('producer','phaseB_D4C2a_v3_0.110.0.zip')]:
 zpath=base/name; dest=out/'work'/label
 with zipfile.ZipFile(zpath) as z:
  infos=z.infolist(); names=[x.filename for x in infos]
  assert len(names)==len(set(names)); assert z.testzip() is None
  for x in infos:
   p=PurePosixPath(x.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in x.filename
   assert not stat.S_ISLNK(x.external_attr>>16)
  z.extractall(dest)
 root=dest/'phaseB'; fm={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
 meta[label]={'zip':name,'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'bytes':zpath.stat().st_size,'files':len(fm),'root':str(root),'file_map':fm}
(out/'results'/'prepared.json').write_text(json.dumps(meta,indent=2))
for k,m in meta.items():print(k,m['sha256'],m['bytes'],m['files'],m['root'])
a=meta['current']['file_map'];b=meta['previous']['file_map']
print('CHANGED',*[k for k in a if k in b and a[k]!=b[k]],sep='\n')
print('ADDED',*[k for k in a if k not in b],sep='\n')
