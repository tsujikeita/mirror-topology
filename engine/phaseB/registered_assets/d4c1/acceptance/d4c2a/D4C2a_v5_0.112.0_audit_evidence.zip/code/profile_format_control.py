import os
"""Use the *producer* Profiler.report implementation with TEST-ONLY trivial segment bodies.
This verifies format compatibility including unused targets, not any scientific timing.
Only the test profile python metadata is relabeled for the comparator fixture; actual runtime is recorded separately.
"""
from pathlib import Path
import json,sys,os,importlib,hashlib,shutil,subprocess,platform
D=Path(os.environ.get('D4C_AUDIT_ROOT','/mnt/data/audit_D4C2a_v5')); F=json.loads((D/'results/cross_fixture.json').read_text()); P=Path(F['producer_root']);sys.path[:0]=[str(P),str(P/'tests')]
from step1_engine.profiling import Profiler,TARGETS,SEGMENT_TARGET
from step1_engine import serialization as ser
from step1_engine.archive import Archive
mods=[]
def trivial(i):
 a=ser.to_jsonable({'synthetic_row':i,'payload':[float(i),True]});return a
for mod,attr in TARGETS[SEGMENT_TARGET]:
 m=importlib.import_module('step1_engine.'+mod);mods.append((m,attr,getattr(m,attr)));setattr(m,attr,trivial)
try:
 with Profiler(cprofile=True) as prof:
  for i in range(3):getattr(mods[0][0],mods[0][1])(i)
 r=prof.report('AUDIT TEST ONLY; trivial segment bodies, no bank/evaluation')
finally:
 for m,a,fn in mods:setattr(m,a,fn)
actual_python=r['python'];r['python']='3.13.16'
w=D/'work/profile_format';shutil.copytree(F['new'],w);rd=next(w.glob('run_*'));pf=rd/'d4c1_probe_E2_profile.json';pf.write_text(json.dumps(r,indent=1));h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rp=rd/'d4c1_probe_E2_run.json';run=json.loads(rp.read_text());run['profile_record']={'sha256':h(pf),'bytes':pf.stat().st_size};run['profile_summary']={ 'wall_seconds_total':r['wall_seconds_total'],'segments':r['segments']['count'],'segment_wall_seconds':r['segments']['wall_seconds'],'outside_segments_wall_seconds':r['outside_segments_wall_seconds'],'missing_targets':r['missing_targets']};rp.write_text(json.dumps(run));fp=w/'d4c1_partial_final_record.json';f=json.loads(fp.read_text());f['record_sha256']=h(rp);fp.write_text(json.dumps(f))
out=D/'results/profile_format_report.json';cmd=[sys.executable,F['script'],'--phaseb',str(P),'--baseline',F['baseline'],'--spec',F['spec'],'--new',str(w),'--expected-commit',F['expected_commit'],'--out',str(out)]
p=subprocess.run(cmd,capture_output=True,text=True,timeout=180,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1'))
(D/'logs/profile_format.log').write_text(p.stdout+p.stderr)
summary=dict(rc=p.returncode,actual_python=actual_python,metadata_python_in_fixture=r['python'],n_targets=len(r['targets']),unused_targets=sum(v['calls']==0 for v in r['targets'].values()),segments=r['segments']['count'],scope='TEST ONLY trivial bodies; producer Profiler format compatibility, not scientific run')
(D/'results/profile_format_summary.json').write_text(json.dumps(summary,indent=2));print(summary);assert p.returncode==0,json.loads(out.read_text()).get('mismatches')
