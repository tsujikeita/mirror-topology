import os
from pathlib import Path
import json,os,shutil,sys,subprocess,zipfile,hashlib
D=Path(os.environ.get('D4C_AUDIT_ROOT','/mnt/data/audit_D4C2a_v5'));F=json.loads((D/'results/cross_fixture.json').read_text());base=D/'work/fresh';base.mkdir();p=base/'producer';shutil.copytree(F['producer_root'],p)
with zipfile.ZipFile(base/'synthetic_new.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in Path(F['new']).rglob('*'):
  if f.is_file():z.write(f,str(f.relative_to(F['new'])))
out=D/'results/fresh_cross_zip.json';r=subprocess.run([sys.executable,F['script'],'--phaseb',str(p),'--spec',F['spec'],'--baseline',F['baseline'],'--new',str(base/'synthetic_new.zip'),'--expected-commit',F['expected_commit'],'--out',str(out)],env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1'),capture_output=True,text=True,timeout=180)
(D/'logs/fresh_cross.log').write_text(r.stdout+r.stderr);report=json.loads(out.read_text());print(r.returncode,report['n_checks'],report['mismatches']);assert r.returncode==0
M=json.loads((D/'results/prepared.json').read_text())['producer']['file_map'];new={str(q.relative_to(p)):hashlib.sha256(q.read_bytes()).hexdigest() for q in p.rglob('*') if q.is_file()};assert new==M
(D/'results/fresh_summary.json').write_text(json.dumps({'rc':r.returncode,'n_checks':report['n_checks'],'producer_source_unchanged':new==M,'new_input_form':'ZIP','synthetic':True,'all_pytest_repeated':False},indent=2))
