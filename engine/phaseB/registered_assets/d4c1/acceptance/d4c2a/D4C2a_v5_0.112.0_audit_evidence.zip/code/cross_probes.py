import os
"""Independent fully rehashed producer mutations, using unmodified comparator and 0.110 reader.
All producer executions here are TEST-ONLY documents, not Colab/bank executions.
"""
from pathlib import Path
import json,hashlib,shutil,subprocess,os,sys,concurrent.futures,zipfile
D=Path(os.environ.get('D4C_AUDIT_ROOT','/mnt/data/audit_D4C2a_v5')); f=json.loads((D/'results/cross_fixture.json').read_text()); base=Path(f['new']);w=D/'work/independent';w.mkdir(exist_ok=True); res=D/'results/cross';res.mkdir(exist_ok=True)
S=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=1))
CASES=['normal','gate_renamed','gate_order_reversed','gate_value_integer','source_pins_wrong','attempt_wrong_directory','bad_lock_commit_relinked','final_failed','precheck_dirty','prelaunch_assets_wrong','twelve_gate_failed','twelve_gate_injected','typed_index_bool','typed_index_float','profile_missing_targets','profile_cprofile_false','profile_target_dropped','profile_segment_bool','profile_calls_mismatch','profile_missing','record_null','lock_missing']
def test(name):
 p=w/name;shutil.copytree(base,p); rd=next(p.glob('run_*'));rp=rd/'d4c1_probe_E2_record.json';runp=rd/'d4c1_probe_E2_run.json';pf=rd/'d4c1_probe_E2_profile.json';ip=rd/'archive/index.json';lp=p/'d4c1_partial_lock.json';fp=p/'d4c1_partial_final_record.json'
 run=json.loads(runp.read_text());fin=json.loads(fp.read_text());lock=json.loads(lp.read_text());idx=json.loads(ip.read_text());prof=json.loads(pf.read_text())
 if name=='gate_renamed':
  i=run['required_inventory'].index('G_inputs_resolved');run['required_inventory'][i]='TEST_FAKE_GATE';run['gates']['TEST_FAKE_GATE']=run['gates'].pop('G_inputs_resolved')
 elif name=='gate_order_reversed':run['required_inventory'].reverse()
 elif name=='gate_value_integer':run['gates']['G_inputs_resolved']=1
 elif name=='source_pins_wrong':run['source']['pins_sha256']='0'*64
 elif name=='attempt_wrong_directory':run['attempt']['attempt_id']='TEST_OTHER';fin['attempt_id']='TEST_OTHER'
 elif name=='bad_lock_commit_relinked':
  lock['commit']='0'*40;write(lp,lock);run['attempt']['launcher_lock_sha256']=S(lp);fin['lock_sha256']=S(lp);fin['lock']=lock
  for k in ['live_source_precheck','live_source_prelaunch']:fin['bindings'][k]['head']='0'*40
 elif name=='final_failed':fin.update(exit_code=1,launcher_fallback=True,failures=['TEST_FAIL'])
 elif name=='precheck_dirty':fin['bindings']['live_source_precheck']['clean']=False
 elif name=='prelaunch_assets_wrong':fin['bindings']['live_source_prelaunch']['registered_assets_sha256'][next(iter(fin['bindings']['live_source_prelaunch']['registered_assets_sha256']))]='0'*64
 elif name=='twelve_gate_failed':run['twelve']['gate'].update(passed=False,required_failures=['TEST_FAIL'])
 elif name=='twelve_gate_injected':run['twelve_gate']={'mode':'official','passed':True}
 elif name.startswith('typed_index_'):
  for e in idx['entries']:
   if e['kind']=='family_result' and e['identity'].get('pseudo_index')==0:e['identity']['pseudo_index']=False if name.endswith('bool') else 0.0
  write(ip,idx)
 elif name=='profile_missing_targets':prof['missing_targets']=['TEST_MISSING']
 elif name=='profile_cprofile_false':prof['instrumentation']['cprofile']=False
 elif name=='profile_target_dropped':prof['targets'].pop(next(iter(prof['targets'])))
 elif name=='profile_segment_bool':prof['segments']['per_segment'][0]['index']=False
 elif name=='profile_calls_mismatch':prof['targets']['threshold_evaluator.evaluate_family_full']['calls']+=1
 elif name=='record_null':rp.write_text('null')
 if name.startswith('profile_'):
  if name=='profile_missing':pf.unlink()
  else:write(pf,prof);run['profile_record']={'sha256':S(pf),'bytes':pf.stat().st_size}
 # Reconcile *outer* run/file receipts so local expected guards, not a stale outer hash, reject.
 write(runp,run);fin['record_sha256']=S(runp);fin['gates']=run['gates'];write(fp,fin)
 if name=='lock_missing':lp.unlink()
 outfile=res/(name+'.json');args=[sys.executable,f['script'],'--phaseb',f['producer_root'],'--spec',f['spec'],'--baseline',f['baseline'],'--new',str(p),'--expected-commit',f['expected_commit'],'--out',str(outfile)]
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
 cp=subprocess.run(args,env=env,capture_output=True,text=True,timeout=180);(D/'logs'/('cross_'+name+'.log')).write_text(cp.stdout+cp.stderr)
 r=json.loads(outfile.read_text()) if outfile.exists() else {}
 ans=dict(case=name,rc=cp.returncode,expected=0 if name=='normal' else 1,report_exists=outfile.exists(),checks=r.get('n_checks'),mismatches=r.get('mismatches'),own_reader=(r.get('checks',{}).get('new_record_own_reader_current_source_binding') or {}).get('ok'),synthetic=True)
 print(json.dumps(ans),flush=True);return ans
if __name__=='__main__':
 normal=test('normal');assert normal['rc']==0,normal
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:out=[normal]+list(pool.map(test,CASES[1:]))
 (D/'results/cross_probes.json').write_text(json.dumps(out,indent=2));assert all(x['rc']==x['expected'] and x['report_exists'] for x in out)
