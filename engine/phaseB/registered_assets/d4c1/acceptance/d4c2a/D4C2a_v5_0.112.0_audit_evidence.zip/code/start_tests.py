import os
from pathlib import Path
import os,subprocess,json
out=Path(os.environ.get('D4C_AUDIT_ROOT','/mnt/data/audit_D4C2a_v5')); root=out/'work/current/phaseB'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',AUDIT_WORKDIR=str(out/'work/test_artifacts'))
tests=[('bridge',['tests/test_d4c2_bridge.py']),('contracts',['tests/test_d4c2a.py','tests/test_d4c2a_script.py']),('registered',['tests/test_d4c0_registration.py','tests/test_d3c_tranche2.py','-k','not consumer_api_rebuild_and_refusals'])]
ps=[]
for name,args in tests:
 cmd=['python','-m','pytest','-q','-p','no:cacheprovider',*args,'--basetemp',str(out/'work'/('pytest_'+name)),'--junitxml',str(out/'results'/('pytest_'+name+'.xml'))]
 log=open(out/'logs'/('pytest_'+name+'.log'),'w');p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 ps.append(dict(name=name,pid=p.pid,cmd=cmd));print(name,p.pid)
(out/'results/processes.json').write_text(json.dumps(ps,indent=2))
