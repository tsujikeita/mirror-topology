"""Reproduce this audit without executing production bank calculations.
Needs the approved source ZIP, probe ZIP, executed notebook, report and prior GO JSON.
Usage: python reproduce.py --inputs DIR --work NEW_DIR
The input files are never edited. A fresh work directory is required.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,os,stat,subprocess,sys,zipfile,json
p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--work',type=Path,required=True);a=p.parse_args()
I=a.inputs.resolve();B=a.work.resolve()
if B.exists():raise SystemExit('Refusing an existing work directory')
B.mkdir(parents=True);[(B/x).mkdir() for x in ('logs','results','work')]
archives=[('phaseB_D4C1_v2_0.107.0.zip','5ce358e12b9d4f756e561912066d9c284792038bc57ed90c4b879410c3795775',B/'work/source'),('d4c1_partial_E2_231d37b89271.zip','538f5e07f3c4fae84803d17783ff09a03fef5270cd04b600376e2af891644766',B/'work/run')]
for name,expected,dest in archives:
 body=(I/name).read_bytes()
 if hashlib.sha256(body).hexdigest()!=expected:raise SystemExit('Input hash mismatch: '+name)
 with zipfile.ZipFile(I/name) as z:
  seen=set()
  if z.testzip() is not None:raise SystemExit('ZIP CRC failure')
  for info in z.infolist():
   q=PurePosixPath(info.filename)
   if q.is_absolute() or '..' in q.parts or info.filename in seen or stat.S_ISLNK(info.external_attr>>16):raise SystemExit('Unsafe ZIP member')
   seen.add(info.filename)
  z.extractall(dest)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',AUDIT_INPUTS=str(I))
commands=[]
for name in ('audit_records.py','verify_reader.py','scientific_controls.py'):
 with (B/'logs'/name.replace('.py','.log')).open('w') as log:
  proc=subprocess.run([sys.executable,str(Path(__file__).parent/name),str(B)],env=env,stdout=log,stderr=subprocess.STDOUT)
 commands.append({'script':name,'returncode':proc.returncode})
 if proc.returncode:raise SystemExit('Audit script failed; inspect '+str(log.name))
for name,_,dest in archives:
 with zipfile.ZipFile(I/name) as z:
  for i in z.infolist():
   if not i.is_dir() and (dest/i.filename).read_bytes()!=z.read(i):raise SystemExit('Extracted source or probe was modified')
(B/'results/reproduction.json').write_text(json.dumps({'commands':commands,'input_source_and_probe_unchanged':True},indent=2))
print(json.dumps(commands));print('Source and probe files remain byte-identical.')
