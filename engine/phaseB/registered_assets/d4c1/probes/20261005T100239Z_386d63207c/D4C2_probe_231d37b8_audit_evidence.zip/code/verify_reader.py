"""Read-only verification of the submitted probe through the unchanged 0.107 reader."""
import sys,json,time,pathlib,copy,hashlib
B=pathlib.Path(sys.argv[1]).resolve(); S=B/'work/source/phaseB'; R=B/'work/run'; U=next(R.glob('run_*'))
sys.path.insert(0,str(S))
from step1_engine.d4c1_partial import verify_partial_record,_payload_sha
from step1_engine.archive import Archive
from step1_engine import serialization as ser
r=json.loads((U/'d4c1_probe_E2_run.json').read_text()); p=ser.from_jsonable(json.loads((U/'d4c1_probe_E2_record.json').read_text())); pins=json.loads((S/'d/d3_pins.json').read_text())
print('PIN_KEYS',[(k,v) for k,v in pins.items() if 'w2' in k or 'twelve' in k])
# Values come from the fixed source's registered assets/pins, not the probe's self-report.
shared=json.loads((S/'registered_assets/b3_2_shared_null_asset.json').read_text())
registered=dict(shared_null_asset_sha256=shared['sha256'],w2_context_sha256=pins['d2w_context_sha256'],registry_sha256=pins['registry_sha256'],twelve_assets_sha256=json.loads((S/'registered_assets/b3_2_twelve_assets.json').read_text())['sha256'])
a=Archive(str(U/'archive')); t=time.time(); v=verify_partial_record(p,a,registered=registered,current_source_binding=True)
print('VERIFY',v,'SECONDS',time.time()-t)
res={'verification':v,'seconds':time.time()-t,'registered':registered,'mutations':[]}
# These edits are performed in memory; originals and archive files remain untouched.
mutations={
 'promote_unknown_to_false':lambda q:q['per_pseudo_status'][0]['eligible_truths'].update(support=False),
 'change_threshold':lambda q:q['thresholds']['pseudo']['T1'].__setitem__(0,0.0),
 'drop_pseudo_status':lambda q:q['per_pseudo_status'].pop(),
 'change_context':lambda q:q.__setitem__('w2_context_sha256','0'*64),
 'change_plan_objects':lambda q:q['plan_objects'].__setitem__('stable_after',False),
 'change_end_fingerprint':lambda q:q['fingerprints']['at_end'].__setitem__('E2',{'matched':'0'*64,'native':'0'*64}),
}
for label,edit in mutations.items():
 q=copy.deepcopy(p);edit(q);q['binding']['partial_sha256']=_payload_sha(q)
 try: verify_partial_record(q,a,registered=registered,current_source_binding=True)
 except Exception as ex: res['mutations'].append({'name':label,'rejected':True,'exception':type(ex).__name__,'message':str(ex)})
 else: res['mutations'].append({'name':label,'rejected':False})
print('MUTATIONS',res['mutations'])
(B/'results/reader.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
assert v['ok'] and all(x['rejected'] for x in res['mutations'])
