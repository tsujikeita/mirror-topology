"""Read-only input/publication/notebook/metadata audit; no production bank calculation."""
from pathlib import Path
import sys,json,ast,hashlib,zipfile,collections,difflib,math,os
B=Path(sys.argv[1]).resolve(); S=B/'work/source/phaseB'; R=B/'work/run'; U=next(R.glob('run_*')); root=Path(os.environ.get('AUDIT_INPUTS','/mnt/data'))
sys.path.insert(0,str(S))
from step1_engine import serialization as ser
from step1_engine.archive import Archive,ArchiveRef
from step1_engine.official_gate import EXPECTED_VERS
import numpy as np
sha=lambda b:hashlib.sha256(b).hexdigest()
fsha=lambda p:sha(Path(p).read_bytes())
read=lambda p:json.loads(Path(p).read_text())
checks=[]
def check(name,value):
 checks.append({'name':name,'passed':bool(value)})
 if not value: raise AssertionError(name)
inputs={p.name:{'bytes':p.stat().st_size,'sha256':fsha(p)} for p in [root/'d4c1_partial_E2_231d37b89271.zip',root/'MirrorTopology_Step1_D4C1_partial_v0_1_executed_231d37b89271.ipynb',root/'D4C2_probe_resource_report.md',root/'phaseB_D4C1_v2_0.107.0.zip',root/'D4C1_v2_0.107.0_audit_decision.json']}
expected_zip='538f5e07f3c4fae84803d17783ff09a03fef5270cd04b600376e2af891644766';expected_nb='72af76c8b161b09eae3815ede13da9416ab5c71a16781e3784fc5c70b4707cd8'
check('run zip hash',inputs['d4c1_partial_E2_231d37b89271.zip']['sha256']==expected_zip)
check('executed notebook hash',inputs['MirrorTopology_Step1_D4C1_partial_v0_1_executed_231d37b89271.ipynb']['sha256']==expected_nb)
go=read(root/'D4C1_v2_0.107.0_audit_decision.json'); subj=go['subject'];inv=read(S/'B2_completion_inventory.json')
check('approved source zip',inputs['phaseB_D4C1_v2_0.107.0.zip']['sha256']==subj['archive']['sha256'])
check('approved inventory',fsha(S/'B2_completion_inventory.json')==subj['inventory_sha256'])
errors=[];nsha=0
for key,prefix in [('modules','step1_engine'),('tests_sha256','tests'),('fixtures_sha256','tests'),('assets_sha256',''),('documents_sha256',''),('b3_sha256',''),('registered_assets_sha256',''),('d_sha256','')]:
 for rel,sh in inv[key].items():
  nsha+=1;path=S/prefix/rel
  if not path.is_file() or fsha(path)!=sh: errors.append(str(path))
check('inventory all source hashes',not errors)
l=read(R/'d4c1_partial_lock.json');f=read(R/'d4c1_partial_final_record.json');r=read(U/'d4c1_probe_E2_run.json');p=ser.loads((U/'d4c1_probe_E2_record.json').read_text())
check('lock bytes and embedded value',f['lock']==l and f['lock_sha256']==fsha(R/'d4c1_partial_lock.json'))
check('attempt and run binding',r['attempt']['attempt_id']==f['attempt_id']==U.name.removeprefix('run_') and r['attempt']['launcher_lock_sha256']==f['lock_sha256'])
check('final source approved',l['commit']==subj['author_supplied_commit'] and l['inventory_sha256']==subj['inventory_sha256'] and l['engine']=='0.107.0')
for path,sh in subj['key_files_sha256'].items():check('approved key file '+path,fsha(S/path)==sh)
check('script source binding',r['source']['script_sha256']==l['script_sha256']==fsha(S/'d/d4c1_calibration.py'))
check('pins binding',r['pins_sha256']==l['pins_sha256']==fsha(S/'d/d3_pins.json'))
check('run record bytes',f['record_sha256']==fsha(U/'d4c1_probe_E2_run.json'))
for phase in ('live_source_precheck','live_source_prelaunch'):
 obs=f['bindings'][phase]
 check(phase+' HEAD and clean',obs['head']==l['commit'] and obs['clean'] is True)
 for key in ('inventory_sha256','script_sha256','inventory_script_sha256','pins_sha256','engine','registered_assets_sha256'):check(phase+' '+key,obs[key]==l[key])
for rel,sh in l['registered_assets_sha256'].items():check('registered lock '+rel,fsha(S/rel)==sh)
# Parse trusted REQUIRED from the approved source without executing its script.
t=ast.parse((S/'d/d4c1_calibration.py').read_text()); const={}
for n in t.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:const[n.targets[0].id]=ast.literal_eval(n.value)
  except (ValueError,TypeError):pass
# REQUIRED_PARTIAL is a concatenation, evaluate only literal list/name operations.
def literal(node):
 if isinstance(node,ast.Name):return const[node.id]
 if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Add):return literal(node.left)+literal(node.right)
 return ast.literal_eval(node)
for n in t.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:const[n.targets[0].id]=literal(n.value)
  except (ValueError,TypeError,KeyError):pass
req=const['REQUIRED_PARTIAL'];check('24 trusted REQUIRED',len(req)==24 and r['required_inventory']==list(req) and set(r['gates'])==set(req) and all(r['gates'][k] is True for k in req) and r['required_all_true'] is True)
check('probe not formal pass',r['probe'] is True and r['probe_n']==3 and r['D4C1_PARTIAL_PASS'] is False and f['partial_pass'] is False and f['exit_code']==0 and f['launcher_fallback'] is False)
check('normal completion',r['stage']=='complete' and not r['failures'] and not r['notes'] and not f['failures'] and f['exception'] is None)
check('formal intake',r['formal'] is True and r['selftest'] is False and r['profile']=='production_official')
check('gate scope separation',p['gate']['mode']=='smoke' and p['gate']['passed'] is True and p['gate']['diagnostics']['environment_source']=='live_collected' and r['twelve']['gate']=={'mode':'official','passed':True,'required_failures':[],'environment_source':'live_collected'})
check('recorded environment version and pools',r['env_gate']['versions_ok'] is True and r['env_gate']['pools_ok'] is True)
check('actual recorded environment',all(r['env'][k]==v for k,v in EXPECTED_VERS.items()) and all(x['n']==2 if x['owner']=='numpy' else x['n']<=2 for x in r['env']['blas_threads']))
check('actual final acceptance guards',f['gates_ok'] is True and f['bindings_ok'] is True and f['evidence_ok'] is True)
check('expected version dictionary',all(r['env_gate']['expected'][k]==v for k,v in EXPECTED_VERS.items()))
for file,meta in r['published_evidence'].items():check('publication '+file,fsha(U/file)==meta['sha256'] and (U/file).stat().st_size==meta['bytes'])
check('published record payload binding',p['binding']['partial_sha256']==r['partial']['partial_sha256'])
check('fingerprint before after',p['fingerprints']['at_gate']==p['fingerprints']['at_end'])
check('plan objects',all(r['plan_objects'][k] is True for k in ('first_wave_shared','twelve_shared','twelve_present','twelve_shares_first_wave','stable_after','script_views_same_objects_after')))
check('all supplies recorded',len(r['supplies'])==72)
# Compare every supply manifest to its accepted D-3c original. Origin strings differ because caller stage names differ.
d3l=read(S/'registered_assets/d3c/d3c_profile_ledger.json'); accepted=list((S/'registered_assets/d3c/runs').rglob('d3c_profile_record_E2.json'));check('one accepted E2 profile',len(accepted)==1)
old=read(accepted[0]);check('supply key equality',set(old['supplies'])==set(r['supplies']))
for key,v in r['supplies'].items():check('supply identity '+key, v['manifests']==old['supplies'][key]['manifests'] and v['n_clusters']=={'0':10000,'1':30000} and v['fitting_clusters']==2000)
check('accepted D3c fingerprints',r['twelve']['assembled_fingerprints']==r['twelve']['d3c_binding']['input_fingerprints'])
check('D3c original fingerprint anchor',r['twelve']['assembled_fingerprints']==old['input_fingerprints_after_gate'])
check('accepted plan identity',r['twelve']['d3c_binding']['plan_identity_sha256']=='86a7db7b4aa31d172cf402785072adbd2ff2beefce964d9cf6a1cd3948c81d3e')
# Exact pseudo prefix from registered original NPZ.
npzs=list((S/'registered_assets/d4c0/pseudo/runs').rglob('d4_pseudo_columns.npz'));check('one registered pseudo',len(npzs)==1)
with np.load(npzs[0],allow_pickle=False) as npz:
 for k in ('T1','T2'):check('exact pseudo prefix '+k,np.array_equal(np.asarray(p['thresholds']['pseudo'][k]),npz[k][:3]))
# Notebook static comparison: all noneditable sources exact; editable AST contains same assignment names only.
nb=read(root/'MirrorTopology_Step1_D4C1_partial_v0_1_executed_231d37b89271.ipynb'); nb0=read(S/'d/MirrorTopology_Step1_D4C1_partial_v0.1.ipynb')
check('notebook cells',len(nb['cells'])==len(nb0['cells'])==5)
for i in [0,2,3,4]:check('notebook source cell '+str(i),nb['cells'][i]['source']==nb0['cells'][i]['source'])
nba=ast.parse(''.join(nb['cells'][1]['source']));vals={n.targets[0].id:ast.literal_eval(n.value) for n in nba.body if isinstance(n,ast.Assign)}
check('editable cell literal assignments only',len(vals)==len(nba.body) and set(vals)=={n.targets[0].id for n in ast.parse(''.join(nb0['cells'][1]['source'])).body if isinstance(n,ast.Assign)})
for key in ['REPO_COMMIT','EXPECTED_INVENTORY_SHA256','FAMILY','PROBE_N','STAGE_LOCAL','STAGE_ROOT','D2_RUN_ROOT','D3B_RUN_ROOTS']:
 check('notebook setting '+key,vals[key]==go['probe_conditions']['source_and_inventory_fixed'][key])
check('notebook campaign',vals['TARGET_COMMITMENT']==l['target_commitment'] and vals['CAMPAIGN_ID']==l['campaign_id'])
check('execution count',[c.get('execution_count') for c in nb['cells'][1:]]==[1,2,3,4])
check('notebook no errors',not any(o.get('output_type')=='error' for c in nb['cells'] for o in c.get('outputs',[])))
# Archive integrity, records and key scientific quantities.
a=Archive(str(U/'archive'));idx=read(U/'archive/index.json'); entries=idx['entries'];check('archive 17',len(entries)==17)
agg=collections.Counter();raw=0;position=[]
for e in entries:
 b=(U/'archive'/e['path']).read_bytes();check('archive file '+e['path'],sha(b)==e['sha256'] and len(b)==e['bytes'])
 q=ser.from_jsonable(a.get(ArchiveRef(**{k:e[k] for k in ('kind','sha256','path','identity')})));agg[e['kind']]+=1;raw+=len(b)
 if e['kind']=='three_position_result':position.append(q)
rows=[]
for i,st in enumerate(p['per_pseudo_status']):
 fr=ser.from_jsonable(a.get(ArchiveRef(**st['parent_ref'])))
 rows.append(dict(index=i,threshold=[p['thresholds']['pseudo']['T1'][i],p['thresholds']['pseudo']['T2'][i]],Q_matched=fr['Q_point'],logD=fr['logD']['point'],logD_CI=fr['logD']['ci'],bandwidth_sensitivity_pass=fr['logD']['sensitivity_pass'],precision=fr['precision'],core_truths=st['core_truths'],eligible_truths=st['eligible_truths'],per_config_probability={str(k):v['P_model'] for k,v in fr['per_config'].items()}))
 check('pseudo row state '+str(i),st['core_technical'] is False and st['expand_family'] is False and st['twelve'] is None and st['eligible_truths']==dict(support='unknown',strong='unknown',unsupported='unknown'))
res=dict(inputs=inputs,checks=checks,source_sha_entries=nsha,source_sha_errors=errors,archive=dict(entries=len(entries),by_kind=dict(agg),entry_bytes=raw,index_bytes=(U/'archive/index.json').stat().st_size,total_bytes=raw+(U/'archive/index.json').stat().st_size),rows=rows,position_records=position,timing=r['timings'],staging=f['staging'],seconds_total=f['seconds_total'],rss=r['stages_rss_mb'],peak=r['stages_peak_rss_mb'],environment=r['env_gate'],run_filemap={str(x.relative_to(R)):{'bytes':x.stat().st_size,'sha256':fsha(x)} for x in R.rglob('*') if x.is_file()},notebook_settings=vals)
(B/'results/records.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print(json.dumps(dict(checks=len(checks),all_passed=all(x['passed'] for x in checks),source_sha_entries=nsha,archive=res['archive'],rows=[{k:v for k,v in x.items() if k!='per_config_probability'} for x in rows]),ensure_ascii=False,indent=2))
