"""State-contract/counterfactual checks. No bank/OT/pseudo regenerated; no real target evaluation."""
import sys,json,pathlib,copy,itertools,dataclasses,time
from fractions import Fraction
import numpy as np
B=pathlib.Path(sys.argv[1]).resolve();S=B/'work/source/phaseB';U=next((B/'work/run').glob('run_*'));sys.path.insert(0,str(S))
from step1_engine import serialization as ser
from step1_engine.d3_profile import twelve_context
from step1_engine.w2_cases import load_registered_w2_context
from step1_engine.positions import position_decision,event_ratio_trigger
from step1_engine.stage12 import transition_after_three,StageTransition
from step1_engine.coordinator import plan_family_expansion,family_completion
from step1_engine.threshold_evaluator import derive_outcome
from step1_engine.calibration import any_family_truth,wilson_upper,calibrate
from step1_engine import w2_stop as ws
from step1_engine.rules_config import RULES
ctx=twelve_context(str(S));w2,view=load_registered_w2_context(str(S),ctx); reg=ctx.registry;ta=ctx.twelve_assets
p=ser.loads((U/'d4c1_probe_E2_record.json').read_text());index=json.loads((U/'archive/index.json').read_text()); pos=[ser.loads((U/'archive'/e['path']).read_text()) for e in index['entries'] if e['kind']=='three_position_result']
replays=[]
for d in pos:
 key=d['family']+'/'+d['size_id'];got=position_decision(w2.decision_for(key,w2.context_sha256),d['evidence']['position_probabilities'])
 assert got==d['position_status'];replays.append({'key':key,'threshold':d['evidence']['threshold'],'same':True})
# Counterfactual: trigger L1.00 by ratio; keep genuine registered W2 decision at L1.20 unknown.
base=[d for d in pos if d['evidence']['threshold']==[p['thresholds']['pseudo']['T1'][0],p['thresholds']['pseudo']['T2'][0]]]
man={s:ta.get('E2',s) for s in reg.surviving['E2']};tr={}
for old in base:
 d=copy.deepcopy(old);s=d['size_id']
 if s=='L1.00':
  d['evidence']['position_probabilities']={k:dict(P=v,hits=int(v*1000000),N=1000000,precision='pass',stage='N0') for k,v in zip([1,2,3],[.2,.6,.2])}
 st=position_decision(w2.decision_for('E2/'+s,w2.context_sha256),d['evidence']['position_probabilities']);d['position_status']=st
 tr[s]=transition_after_three('E2',s,d,dict(state=st['state'],expand=st['expand']),man[s] if st['expand'] else None)
plan=plan_family_expansion('E2',list(reg.surviving['E2']),tr,man)
assert tr['L1.20'].phase=='provisional_unresolved' and plan.expand_family and set(plan.required_manifests)==set(reg.surviving['E2'])
# Only local completion contract fixture, NOT a complete numerical Result or measured bank.
completion={s:dict(family='E2',size_id=s,decision=dict(technical_status='ok'),precision=dict(state='pass'),evidence=dict(stage='12-position',twelve_manifest_sha256=man[s].sha256,coverage_ok=True)) for s in man}
c=family_completion(plan,completion,{s:'not-expanded' for s in man},man)
assert c['family_local_completion'] is True
outcomes={}
for value in (False,True,'unknown'):
 label,truth=derive_outcome('E2',dict(support=False,strong=False,unsupported=False),False,plan.status,True,dict(tech12=False,completion=True,truths=dict(support=value,strong=value,unsupported=False)))
 assert truth['support']==value;outcomes[str(value)]={'eligibility':label,'truths':truth}
label,truth=derive_outcome('E2',dict(support=False,strong=False,unsupported=False),True,plan.status,True,dict(tech12=False,completion=True,truths=dict(support=False,strong=False,unsupported=False)))
assert truth['support']=='technical_fail'
# Same observed data + exact unchanged null prefix, but larger stopping horizon and arbitrary tail.
shared=ser.loads((S/'registered_assets/b3_2_shared_null_asset.json').read_text());null={n:np.array(shared['null'][n]['values']) for n in RULES.n_subs}
stop_controls=[]
for f in sorted((S/'registered_assets/d4c0/d2w/runs').rglob('d2w_case_*.json')):
 d=ser.loads(f.read_text());obs=d['result']['observed'];observed={int(n):{int(s):v['value'] if isinstance(v,dict) and 'value' in v else v for s,v in by.items()} for n,by in obs.items()}
 # The exact stop input is stored explicitly.
 observed=d['result']['stop']['observed']; prefix_id=d['result']['stop']['null_prefix_id']
 original=ws.w2_stop(null,observed,prefix_id);assert original.B_final==d['decision']['B_final']
 old_rules=ws.RULES
 try:
  ws.RULES=dataclasses.replace(RULES,B_levels=tuple(range(200,2001,200)))
  extended={n:np.concatenate([v,np.full(1000,1e6)]) for n,v in null.items()}
  again=ws.w2_stop(extended,observed,prefix_id)
 finally:ws.RULES=old_rules
 assert original.as_dict()==again.as_dict()
 stop_controls.append({'case':d['key'],'B_final':original.B_final,'stop_state':original.state,'decision':d['decision']['trigger'],'tail_only_extension_same_stop':True,'validation':d['result']['validation']})
# Algebraic certificate thresholds, NOT issuing a completed calibration or estimating uncomputed outcomes.
thresholds=[]
for th in [RULES.usable_support,RULES.usable_strong]:
 k=next(k for k in range(2001) if wilson_upper(k,2000)>th)
 assert wilson_upper(k-1,2000)<=th
 thresholds.append({'threshold':th,'first_blocking_count':k,'previous_upper':wilson_upper(k-1,2000),'blocking_upper':wilson_upper(k,2000),'three_rows_best_completion_upper':wilson_upper(3,2000)})
# any-family cannot turn a known blocking row (True or unknown) into False.
vals=[False,True,'unknown','technical_fail']; rows=0
for state in [True,'unknown']:
 for rest in itertools.product(vals,repeat=3):
  assert any_family_truth([state,*rest]) in [True,'unknown','technical_fail'];rows+=1
# Sufficient screening condition across ALL possible mixed N0/Nmax choices, not same-stage ratios alone.
# Fractions make the proposal's bound an exact count/N comparison. This is a synthetic contract demonstration only.
fixture={s:{j:{'N0':(600000+j*10000,1000000),'N4':(2400000+j*20000,4000000)} for j in (1,2,3)} for s in reg.surviving['E2']}
mixed=0
for bits in itertools.product((0,1),repeat=9):
 for si,s in enumerate(reg.surviving['E2']):
  q={}
  for ji,j in enumerate((1,2,3)):
   stage=('N0','N4')[bits[si*3+ji]];h,n=fixture[s][j][stage];q[j]=dict(P=h/n,hits=h,N=n,precision='pass',stage=stage)
  val,why=event_ratio_trigger(q);assert val is False
 mixed+=1
allprob=[Fraction(h,n) for one in fixture.values() for stages in one.values() for h,n in stages.values()];assert max(allprob)<=2*min(allprob)
res={'scope':'read-only replay of saved metadata plus explicit synthetic/counterfactual state controls; no new production evaluations','context_sha256':w2.context_sha256,'position_replay':replays,'counterfactual':{'triggering_size':'L1.00','unknown_size_remains':'L1.20','plan':plan.as_dict(),'local_completion_fixture':c,'outcomes':outcomes,'required_technical_fail_preserved':truth},'stop_tail_controls':stop_controls,'wilson_thresholds':thresholds,'blocking_row_truth_controls':rows,'mixed_prefix_screen_fixture':{'choices_checked':mixed,'scope':'synthetic sufficient-bound demonstration, not production screen','ratio_upper_bound':str(max(allprob)/min(allprob))}}
(B/'results/scientific_controls.json').write_text(json.dumps(ser.to_jsonable(res),ensure_ascii=False,indent=2))
print(json.dumps({'position_replays':len(replays),'counterfactual_expand':plan.expand_family,'local_completion':c['family_local_completion'],'tail_invariance':len(stop_controls),'wilson_thresholds':thresholds,'blocking_row_truth_controls':rows,'mixed_prefix_choices':mixed},indent=2))
