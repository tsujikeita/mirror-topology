# D4C-2 E2 N=3 probe audit evidence

Scope: read-only checks of the submitted 0.107.0 probe and state/aggregation reasoning. No full physical bank, exact OT, 2,000-row calibration, or actual target evaluation was executed.

## Files
- `results/records.json`: input identities, 173 grouped checks, 2,198 inventory SHAs, archive inventory and exact recorded quantities.
- `results/reader.json`: unchanged reader success and six in-memory, rehashed inconsistent-record rejection tests.
- `results/scientific_controls.json`: nine actual position-record replays, a clearly synthetic ratio-trigger/completion counterexample using genuine registered W2/manifest objects, nine null-tail stopping invariance controls, Wilson integer thresholds, and abstract feasibility-screen controls.
- `results/preservation.json`: original source/probe preservation.
- `code/`: executable audit scripts. No production code was patched.
- `input_originals/`: probe ZIP, executed notebook, resource report and preceding audit decision, byte-preserved. The 28 MB approved source ZIP is not duplicated here.

## Reproduction
Place `phaseB_D4C1_v2_0.107.0.zip` and the four files from `input_originals/` together in an input directory, then run:

```sh
python code/reproduce.py --inputs /path/to/inputs --work /path/to/new-audit-work
```

The existing runtime had Python 3.13 with NumPy/SciPy available. The scripts add the extracted approved source to their own import path, disable bytecode generation, and do not reproduce the Colab environment or official gate. No network, Drive write, calibration bank generation, full plan construction, or target evaluation is invoked. Third-party dependency versions are not installation recommendations.

The W2 tail experiment temporarily changes ONLY the audit process's `w2_stop.RULES.B_levels` to test a counterfactual horizon and appends arbitrary positive tail values. It is not an amended official calculation, not an authenticated new shared-null asset, and not a source-file modification. Twelve-position completion in the counterexample is a local-contract fixture, not a computed twelve-position numerical Result.

## Harness adaptations
Initial audit-harness assumptions were corrected before the successful final runs: shared-null identity comes from the authenticated asset, REQUIRED is a tuple in source/list in JSON, the first-wave gate's environment source is nested in diagnostics, and the editable notebook cell is checked against the original assignment-name set rather than a guessed count. These are audit-harness corrections, not submitted-program failures. Initial logs retained where captured. No changes to submitted source or run bytes were made.
