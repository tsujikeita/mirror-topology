"""Four controlled mutations of copies of the actual run. Originals are not changed."""
from pathlib import Path
import copy,hashlib,json,os,shutil,subprocess,sys
A=Path(os.environ.get('BRIDGE_AUDIT_ROOT','/mnt/data/bridge_run_audit_20261007'));D=Path(os.environ.get('BRIDGE_INPUT_ROOT','/mnt/data'))
Q=A/'work/pipeline/phaseB'; P=A/'work/producer/phaseB'; R=A/'results'; results=[]
def load(p):return json.loads(p.read_text())
def put(p,d):p.write_text(json.dumps(d,indent=1),encoding='utf-8')
def info(p):return dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
for case in ['required_gate_renamed','profile_missing_rehashed','typed_index_bool','science_record_byte_change']:
    dest=A/'work'/('mutation_'+case);shutil.copytree(A/'work/new',dest,dirs_exist_ok=False)
    run=next(dest.glob('run_*'));rp=run/'d4c1_probe_E2_run.json';fp=dest/'d4c1_partial_final_record.json';pr=run/'d4c1_probe_E2_profile.json';ip=run/'archive/index.json'
    r,f=load(rp),load(fp)
    if case=='required_gate_renamed':
        k='G_inputs_resolved';new='G_TEST_NOT_THE_REQUIRED_NAME'
        r['required_inventory']=[new if v==k else v for v in r['required_inventory']];r['gates'][new]=r['gates'].pop(k);f['gates']=copy.deepcopy(r['gates']); put(rp,r);f['record_sha256']=info(rp)['sha256'];put(fp,f)
    elif case=='profile_missing_rehashed':
        p=load(pr);p['missing_targets']=['TEST_MISSING_TARGET'];put(pr,p);r['profile_record']=info(pr);put(rp,r);f['record_sha256']=info(rp)['sha256'];put(fp,f)
    elif case=='typed_index_bool':
        ix=load(ip);ent=next(e for e in ix['entries'] if e['kind']=='family_result' and e['identity']['pseudo_index']==0);ent['identity']['pseudo_index']=False;put(ip,ix)
    elif case=='science_record_byte_change':
        ix=load(ip);ent=next(e for e in ix['entries'] if e['kind']=='family_result' and e['identity']['pseudo_index']==0);p=run/'archive'/ent['path'];data=p.read_bytes();p.write_bytes(data+b' ')
    out=R/(case+'.json');cmd=[sys.executable,str(Q/'d/d4c2_bridge_compare.py'),'--phaseb',str(P),'--spec',str(D/'D4C2a_v3_0.110.0_bridge_comparison_spec.json'),'--baseline',str(D/'d4c1_partial_E2_231d37b89271.zip'),'--new',str(dest),'--expected-commit','39082b641d8621989ae69a273f4e88e0c59673ba','--out',str(out)]
    c=subprocess.run(cmd,text=True,capture_output=True,timeout=90,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2'))
    (R/(case+'.stdout')).write_text(c.stdout);(R/(case+'.stderr')).write_text(c.stderr)
    d=load(out);results.append(dict(case=case,returncode=c.returncode,report_written=True,rejected=c.returncode==1 and d['exit_code']==1,mismatches=d['mismatches']))
(R/'actual_run_mutation_controls.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2));assert all(r['rejected'] for r in results)
