# Reproduction

The original attachments are inputs; this bundle does not redistribute the source trees or scientific bank arrays.

```
export BRIDGE_INPUT_ROOT=/mnt/data
export BRIDGE_AUDIT_ROOT=/mnt/data/bridge_replay_new_directory
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2
python code/prepare_and_compare.py
python code/audit_raw_bridge.py
```

The second command also needs the previous decision JSONs, the two uploads before/after replacement, and the executed notebook listed in `results/input_metadata.json`. It compares exact local original bytes, not a remote Git repository.

`probe_comparator_refusals.py` is an optional four-case test on copies of the ACTUAL run. It deliberately creates invalid evidence. Allow several minutes. Run once in a fresh work tree. These are evidence-contract tests, not scientific reruns. `results/actual_run_mutation_controls.json` lists the four observed refusals.

The five selected unchanged module tests were run as follows, from the pipeline phaseB directory (AUDIT_WORKDIR must be outside the source tree):
```
python -m pytest -q -p no:cacheprovider tests/test_d4c2a.py \
  -k 'wilson_blocking or envelope_bound or certificate_counting or registered_environment or screen_w2_summary' \
  --junitxml=/absolute/output/selected_contract_tests.xml
```

The full 1,953-case historical suite was NOT rerun. The source in this review is the previously accepted 0.112.0 packet, not a newly changed packet.
