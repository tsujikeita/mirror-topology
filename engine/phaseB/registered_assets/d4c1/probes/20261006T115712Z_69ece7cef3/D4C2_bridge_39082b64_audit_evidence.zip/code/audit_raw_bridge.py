"""Independent read-only audit of the resubmitted bridge evidence.
Run after the archives have been extracted by prepare_and_compare.py.
No production bank, physical kernel, large plan generation, or target evaluation.
"""
from pathlib import Path
import ast, collections, difflib, hashlib, json, math, os, platform, zipfile
import numpy as np
A=Path(os.environ.get('BRIDGE_AUDIT_ROOT','/mnt/data/bridge_run_audit_20261007'))
D=Path(os.environ.get('BRIDGE_INPUT_ROOT','/mnt/data'))
P=A/'work/producer/phaseB'; Q=A/'work/pipeline/phaseB'; N=A/'work/new'; B=A/'work/baseline'
checks=[]
def check(name, value, detail=None):
    checks.append(dict(name=name,ok=bool(value), **({'detail':detail} if detail is not None else {})))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def doc(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def teq(a,b):
    if type(a) is not type(b): return False
    if isinstance(a,dict): return a.keys()==b.keys() and all(teq(a[k],b[k]) for k in a)
    if isinstance(a,list): return len(a)==len(b) and all(teq(x,y) for x,y in zip(a,b))
    return a==b
def filemap(root): return {str(p.relative_to(root)): {'sha256':sha(p),'bytes':p.stat().st_size} for p in root.rglob('*') if p.is_file()}
def constants(path):
    out={}
    for n in ast.parse(Path(path).read_text()).body:
        if isinstance(n,ast.Assign):
            try: v=ast.literal_eval(n.value)
            except (ValueError,TypeError): continue
            for t in n.targets:
                if isinstance(t,ast.Name): out[t.id]=v
    return out
newrun=next(N.glob('run_*')); oldrun=next(B.glob('run_*'))
r=doc(newrun/'d4c1_probe_E2_run.json'); rec=doc(newrun/'d4c1_probe_E2_record.json'); old=doc(oldrun/'d4c1_probe_E2_record.json')
fin=doc(N/'d4c1_partial_final_record.json'); lock=doc(N/'d4c1_partial_lock.json'); profile=doc(newrun/'d4c1_probe_E2_profile.json')
spec=doc(D/'D4C2a_v3_0.110.0_bridge_comparison_spec.json'); prior=doc(D/'D4C2a_v5_0.112.0_audit_decision.json'); go110=doc(D/'D4C2a_v3_0.110.0_audit_decision.json')
# Source authenticity and byte preservation.
source_maps={}
inventories={}
for name,root,zname,expected_sha in [('producer',P,'phaseB_D4C2a_v3_0.110.0.zip',prior['comparison_invocation_conditions']['producer_zip_sha256']),('pipeline',Q,'phaseB_D4C2a_v5_0.112.0.zip',prior['subject']['zip_sha256'])]:
    check(name+'_outer_zip_sha',sha(D/zname)==expected_sha)
    source_maps[name]=filemap(root); inv=doc(root/'B2_completion_inventory.json')
    check(name+'_inventory_sha',sha(root/'B2_completion_inventory.json')==(prior['comparison_invocation_conditions']['producer_inventory_sha256'] if name=='producer' else prior['subject']['inventory_sha256']))
    entries=[]; errors=[]
    for section,prefix in [('modules','step1_engine/'),('tests_sha256','tests/'),('fixtures_sha256','tests/'),('assets_sha256',''),('documents_sha256',''),('b3_sha256',''),('registered_assets_sha256',''),('d_sha256','')]:
        for rel,h in inv[section].items():
            p=root/(prefix+rel); entries.append(str(p.relative_to(root)))
            if not p.is_file() or sha(p)!=h: errors.append(str(p.relative_to(root)))
    inventories[name]=dict(n=len(entries),errors=errors,engine=inv['engine_version'])
    check(name+'_all_inventory_entries',not errors,dict(entries=len(entries),errors=errors))
    with zipfile.ZipFile(D/zname) as z:
        zipmap={f.filename.removeprefix('phaseB/'):dict(sha256=hashlib.sha256(z.read(f)).hexdigest(),bytes=f.file_size) for f in z.infolist() if not f.is_dir()}
    check(name+'_source_equals_zip',teq(source_maps[name],zipmap),len(source_maps[name]))
check('comparator_script_fixed',sha(Q/'d/d4c2_bridge_compare.py')==prior['subject']['script_sha256'])
check('spec_fixed',sha(D/'D4C2a_v3_0.110.0_bridge_comparison_spec.json')==prior['comparison_invocation_conditions']['spec_sha256'])
# Direct comparison to previous upload, not just a repeated author statement.
for name in ['d4c2_bridge_report_20261006T115712Z_69ece7cef3(1).json','d4c1_partial_E2_39082b641d86(1).zip','MirrorTopology_Step1_D4C1_partial_v0_1_executed_39082b641d86(1).ipynb']:
    check('resubmission_identical/'+name,(D/name).read_bytes()==(D/name.replace('(1)','')).read_bytes())
# Notebook source and all literal execution settings.
nb=doc(D/'MirrorTopology_Step1_D4C1_partial_v0_1_executed_39082b641d86(1).ipynb')
nb0=doc(P/'d/MirrorTopology_Step1_D4C1_partial_v0.1.ipynb')
check('notebook_ncells',len(nb['cells'])==len(nb0['cells'])==5)
for i in [0,2,3,4]:check('notebook_unchanged_cell_source/'+str(i),teq(nb['cells'][i]['source'],nb0['cells'][i]['source']))
source=''.join(nb['cells'][1]['source']); tree=ast.parse(source)
check('editable_cell_only_literal_assignments',all(isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) for n in tree.body))
settings={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body}
expected={k:v for k,v in go110['probe_execution_settings'].items() if k!='scope'}
expected['REPO_URL']='https://github.com/tsujikeita/mirror-topology.git'
check('exact_editable_setting_names',settings.keys()==expected.keys())
for k,v in expected.items():check('notebook_setting/'+k,teq(settings.get(k),v))
check('notebook_execution_counts',[c.get('execution_count') for c in nb['cells'] if c['cell_type']=='code']==[1,2,3,4])
check('notebook_no_error_outputs',not any(o.get('output_type')=='error' for c in nb['cells'] for o in c.get('outputs',[])))
text2=''.join(o.get('text','') if isinstance(o.get('text',''),str) else ''.join(o['text']) for o in nb['cells'][2]['outputs'])
line=next(x for x in text2.splitlines() if x.startswith("{'schema':")); loggedlock=ast.literal_eval(line)
check('notebook_logged_lock_equals_raw',teq(loggedlock,{k:v for k,v in lock.items() if k!='registered_assets_sha256'}))
check('notebook_lock_sha_present',sha(N/'d4c1_partial_lock.json') in text2)
text3=''.join(''.join(o.get('text',[])) for o in nb['cells'][3]['outputs'])
stdout=(N/f"d4c1_partial_stdout_{fin['attempt_id']}.txt").read_text()
check('notebook_printed_child_stdout_tail',stdout[-3000:].strip() in text3)
check('notebook_attempt_and_status',f"attempt {fin['attempt_id']} | stage complete | partial_pass False | probe True | failures []" in text3)
check('notebook_zip_length',str((D/'d4c1_partial_E2_39082b641d86(1).zip').stat().st_size) in ''.join(nb['cells'][4]['outputs'][0]['text']))
stderr=(N/f"d4c1_partial_stderr_{fin['attempt_id']}.txt").read_text(); check('stderr_tail_preserved',fin['stderr_tail']==stderr[-2000:], {'bytes':len(stderr.encode()),'text':stderr})
# Bind recorded CLI arguments to fixed settings and exactly approved mode.
args=fin['args']; check('run_directory_matches_attempt',newrun.name=='run_'+fin['attempt_id']==Path(r['out']).name)
check('argv_is_instrumented_three_row_probe',args[args.index('--probe-n')+1]=='3' and '--instrument' in args and '--row-range' not in args and not any(x.startswith('--selftest') for x in args))
check('argv_campaign_commitment',args[args.index('--target-commitment')+1]==settings['TARGET_COMMITMENT'] and args[args.index('--campaign-id')+1]==settings['CAMPAIGN_ID'])
# Direct independent metadata bindings.
d2=doc(P/'registered_assets/d2/d2_generation_ledger.json')['families']['E2']; d3b=doc(P/'registered_assets/d3b/d3b_generation_ledger.json')
check('D2_registry_bytes_bound',r['inputs']['d2']['registry_sha256']==d2['records']['bank_registry_sha256'])
check('D2_original_root_bound',lock['d2_run_root']==d2['run_root']+'/out/d2')
for s,v in r['inputs']['d3b'].items():
    part=d3b['partitions']['E2_'+s]
    check('D3b_root/'+s,lock['d3b_run_roots'][s]==part['run_root']+'/d3b' and v['run_id']==part['run_id'])
check('supply_count_and_origins',len(r['supplies'])==72 and sum(v['origin']=='first_wave_D1' for v in r['supplies'].values())==18)
for key,v in r['supplies'].items():
    cid,system=key.split('/'); m=v['manifests']; units=d2['units'] if v['origin']=='first_wave_D1' else d3b['partitions']['E2_'+{'201':'L1.00','202':'L1.20','203':'L1.50'}[cid[:3]]]['units']
    expected_m={'eval':{str(b):units[f'cfg{cid}_b{b}']['manifest_sha256'] for b in [0,1]},'ref':{str(b):d2['units'][f'ref_E2_b{b}']['manifest_sha256'] for b in [0,1]},'fit':units[f'cfg{cid}_fit']['manifest_sha256'],'ref_fit':d2['units']['ref_E2_fit']['manifest_sha256']}
    check('supply_manifest/'+key,teq(m,expected_m))
    check('supply_cluster_counts/'+key,teq(v['n_clusters'],{'0':10000,'1':30000}) and v['fitting_clusters']==2000)
# 15 exact bytes; index identity checked recursively including bool/int distinctions.
ix=doc(newrun/'archive/index.json'); ix0=doc(oldrun/'archive/index.json')
ents=ix['entries']; by={(e['kind'],e['sha256']):e for e in ents}
check('index_count_unique',len(ents)==len(by)==17)
for e in ents:
    path=newrun/'archive'/e['path'];check('archive_entry/'+e['kind']+'/'+e['sha256'],sha(path)==e['sha256'] and type(e['bytes']) is int and e['bytes']==path.stat().st_size)
for req in spec['required_exact_per_row_records']:
    e=by[(req['kind'],req['sha256'])];p=newrun/'archive'/e['path'];p0=oldrun/'archive'/e['path']
    check('exact_per_row/'+req['sha256'],p.read_bytes()==p0.read_bytes() and sha(p)==req['sha256'] and len(p.read_bytes())==req['bytes'] and teq(e['identity'],req['identity']))
for f in spec['required_equal_partial_fields']:check('invariant_partial_field/'+f,teq(rec[f],old[f]))
# Pseudo raw values; no regeneration, use the registered NPZ directly.
npzs=list((P/'registered_assets/d4c0/pseudo').glob('**/d4_pseudo_columns.npz'));check('one_registered_pseudo_npz',len(npzs)==1)
with np.load(npzs[0],allow_pickle=False) as z:
    check('registered_pseudo_file_sha',sha(npzs[0])=='c62a965b3b649870977d95ba247bf84a9580131109fc8572971e06b98da490f2')
    for col in ['T1','T2']:check('threshold_first3/'+col,np.array_equal(np.asarray(rec['thresholds']['pseudo'][col],dtype=np.float64),z[col][:3]))
check('fingerprint_unchanged_at_end',teq(rec['fingerprints']['at_gate'],rec['fingerprints']['at_end']))
# Independent report comparison, only non-portable paths / timestamps omitted.
author=doc(D/'d4c2_bridge_report_20261006T115712Z_69ece7cef3(1).json');ind=doc(A/'results/independent_bridge_comparison.json')
check('comparator_all_36',ind['n_checks']==36 and ind['n_failed']==0 and ind['exit_code']==0 and all(v['ok'] is True for v in ind['checks'].values()))
def norm(x):
    if isinstance(x,dict):return {k:norm(v) for k,v in x.items() if k not in {'started_utc','finished_utc','phaseb','file'}}
    if isinstance(x,list):return [norm(v) for v in x]
    return x
check('author_report_reproduced_excluding_paths_times',teq(norm(author),norm(ind)))
# Resource accounting and source-supported call placement (not speedup).
resources={'total_seconds':fin['seconds_total'],'script_seconds':r['seconds'],'staging':fin['staging'],'rss_mb':r['stages_rss_mb'],'peak_rss_mb':r['stages_peak_rss_mb'],'timings':r['timings'],'segments':profile['segments'],'outside_seconds':profile['outside_segments_wall_seconds'],'targets':profile['targets'],'cprofile':profile['cprofile']}
check('profile_segment_accounting',math.isclose(sum(x['wall_seconds'] for x in profile['segments']['per_segment']),profile['segments']['wall_seconds'],rel_tol=1e-12))
check('profile_total_accounting',math.isclose(profile['segments']['wall_seconds']+profile['outside_segments_wall_seconds'],profile['wall_seconds_total'],rel_tol=1e-12))
check('fingerprint_calls_outside_segments',profile['targets']['formal_runner.input_fingerprint']['calls']==profile['targets']['formal_runner.input_fingerprint']['outside_segments']['calls']==42)
check('scientific_rows_all_unknown',all(v['eligible_truths'][l]=='unknown' for v in rec['per_pseudo_status'] for l in ['support','strong','unsupported']))
check('not_full_calibration',rec['mode']=='smoke' and r['D4C1_PARTIAL_PASS'] is False and r['partial']['n_pseudo']==3 and r['partial']['expanded']==0 and r['partial']['twelve_evaluated']==0)
# Future pipeline identity: use previously accepted v5, NOT the bridge producer.
Dq=constants(Q/'d/d4c1_calibration.py'); nbq=doc(Q/'d/MirrorTopology_Step1_D4C2_screen_v0.1.ipynb'); cs='\n'.join(''.join(c['source']) for c in nbq['cells'] if c['cell_type']=='code')
compile(cs,'screen_notebook','exec')
check('pipeline_fixed_driver',sha(Q/'d/d4c1_calibration.py')=='814557791d7f295fbb981c20806c7374ddf7ae19148380c41c004afef3e597b0')
check('screen_certificate_required_counts',len(Dq['REQUIRED_SCREEN'])==20 and len(Dq['REQUIRED_CERTIFICATE'])==12)
# a screen notebook has its own literal REQUIRED copied from the producer; extract AST nodes from cells
nbconst={}
for c in nbq['cells']:
    if c['cell_type']=='code':
        for node in ast.walk(ast.parse(''.join(c['source']))):
            if isinstance(node,ast.Assign):
                for t in node.targets:
                    if isinstance(t,ast.Name):
                        try:nbconst[t.id]=ast.literal_eval(node.value)
                        except Exception:pass
check('screen_notebook_required_exact',tuple(nbconst.get('REQUIRED_EXPECTED',()))==Dq['REQUIRED_SCREEN'])
pi=doc(Q/'d/d3_pins.json')
check('screen_current_versions',all(pi['environment'][k]==v for k,v in {'python':'3.13.16','numpy':'2.1.3','scipy':'1.16.3','healpy':'1.20.0','pot':'0.9.7.post1','camb':'2.0.4'}.items()))
changes=[k for k in source_maps['producer'] if k.startswith('step1_engine/') and k in source_maps['pipeline'] and source_maps['producer'][k]!=source_maps['pipeline'][k]]
check('postbridge_engine_changes_only_accepted_guards',set(changes)=={'step1_engine/__init__.py','step1_engine/infeasibility.py','step1_engine/official_gate.py'},changes)
for key in ['orchestrator.py','bootstrap_plan.py','density.py','quantity.py','positions.py','threshold_evaluator.py','d4c1_partial.py','profiling.py']:
    check('numerical_module_unmodified/'+key,(P/'step1_engine'/key).read_bytes()==(Q/'step1_engine'/key).read_bytes())
res={'schema':'independent_bridge_raw_checks_v1','scope':'read-only actual evidence audit; source and metadata verification, no original numerical rerun','environment':dict(python=platform.python_version(),numpy=np.__version__), 'checks':checks,'n_checks':len(checks),'n_failed':sum(not x['ok'] for x in checks),'inventories':inventories,'files':{'producer':len(source_maps['producer']),'pipeline':len(source_maps['pipeline']),'new_run':len(filemap(N)),'baseline_run':len(filemap(B))},'source_changes':changes}
(A/'results/raw_bridge_checks.json').write_text(json.dumps(res,indent=2,ensure_ascii=False))
(A/'results/resource_accounting.json').write_text(json.dumps(resources,indent=2,ensure_ascii=False))
(A/'results/source_maps_before.json').write_text(json.dumps(source_maps))
(A/'results/new_run_file_map.json').write_text(json.dumps(filemap(N),indent=2))
(A/'results/notebook_cell0_diff.patch').write_text(''.join(difflib.unified_diff(nb0['cells'][1]['source'],nb['cells'][1]['source'])))
print(f"{len(checks)-res['n_failed']}/{len(checks)} direct checks; failures:",[x for x in checks if not x['ok']]);raise SystemExit(bool(res['n_failed']))
