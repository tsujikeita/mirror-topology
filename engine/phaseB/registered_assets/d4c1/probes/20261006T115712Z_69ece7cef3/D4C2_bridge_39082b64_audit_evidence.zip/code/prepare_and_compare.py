"""Reproduce the accepted comparator on the ACTUAL attached bridge evidence.
Supply the original named attachments in BRIDGE_INPUT_ROOT; choose a fresh
BRIDGE_AUDIT_ROOT. The producer tree is not changed or replaced by the consumer.
"""
from pathlib import Path
import hashlib, json, os, subprocess, sys, zipfile
D=Path(os.environ.get('BRIDGE_INPUT_ROOT','/mnt/data'))
A=Path(os.environ.get('BRIDGE_AUDIT_ROOT','/mnt/data/bridge_run_audit_replay'))
A.mkdir(parents=True,exist_ok=True);(A/'results').mkdir(exist_ok=True);(A/'work').mkdir(exist_ok=True)
expected={
'phaseB_D4C2a_v3_0.110.0.zip':'3ae56bf1d4911e0955b312e5b44335d9a3398d5dab0b654d713e4fce7e677646',
'phaseB_D4C2a_v5_0.112.0.zip':'0f52a66f53656fd0e686d2ff9a095724e3f834bcd1db26259509005ca323b62c',
'D4C2a_v3_0.110.0_bridge_comparison_spec.json':'a9cb9ab9b622cb0d929006eac01a957003a5eeffef990a40de8c6338a0981373',
'd4c1_partial_E2_231d37b89271.zip':'538f5e07f3c4fae84803d17783ff09a03fef5270cd04b600376e2af891644766',
'd4c1_partial_E2_39082b641d86(1).zip':'d5bb91b103fa33c6e1ae3764e47aa4e3e2ae3e0326fb4966c0cad52978329ded'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,h in expected.items():
    if sha(D/name)!=h:raise SystemExit('untrusted original bytes: '+name)
for name,sub in [('phaseB_D4C2a_v3_0.110.0.zip','producer'),('phaseB_D4C2a_v5_0.112.0.zip','pipeline'),('d4c1_partial_E2_39082b641d86(1).zip','new'),('d4c1_partial_E2_231d37b89271.zip','baseline')]:
    dest=A/'work'/sub
    if dest.exists():raise SystemExit('Use a fresh audit work directory; not overwritten: '+str(dest))
    with zipfile.ZipFile(D/name) as z:
        if len(z.namelist())!=len(set(z.namelist())):raise SystemExit('duplicate ZIP path')
        for f in z.infolist():
            p=Path(f.filename)
            if p.is_absolute() or '..' in p.parts or ((f.external_attr>>16)&0o170000)==0o120000:raise SystemExit('unsafe ZIP path')
        if z.testzip() is not None:raise SystemExit('ZIP CRC failure')
        z.extractall(dest)
P=A/'work/producer/phaseB';Q=A/'work/pipeline/phaseB'
script=Q/'d/d4c2_bridge_compare.py'
if sha(script)!='ca545b61c8b867ec2c36210a77012b2a93b125a2cd04d193e4b8e68ce93fc605':raise SystemExit('comparator bytes changed')
cmd=[sys.executable,str(script),'--phaseb',str(P),'--spec',str(D/'D4C2a_v3_0.110.0_bridge_comparison_spec.json'),'--baseline',str(D/'d4c1_partial_E2_231d37b89271.zip'),'--new',str(D/'d4c1_partial_E2_39082b641d86(1).zip'),'--expected-commit','39082b641d8621989ae69a273f4e88e0c59673ba','--out',str(A/'results/independent_bridge_comparison.json')]
c=subprocess.run(cmd,capture_output=True,text=True,timeout=120,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2'))
(A/'results/comparator_stdout.txt').write_text(c.stdout);(A/'results/comparator_stderr.txt').write_text(c.stderr)
(A/'results/comparator_invocation.json').write_text(json.dumps(dict(command=cmd,returncode=c.returncode),indent=2))
print(c.stdout);raise SystemExit(c.returncode)
