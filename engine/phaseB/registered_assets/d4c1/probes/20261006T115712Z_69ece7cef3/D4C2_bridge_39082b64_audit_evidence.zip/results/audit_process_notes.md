# Audit-process notes

The first versions of the independent metadata script assumed a nested raw D-3b ledger key and only 18 supplies. Inspecting the actual raw ledger/run established flat `E2_L1.00` keys and 72 supplies (18 first-wave + 54 added), and the audit harness was corrected. This was not a modification or a failure of the submitted program. A first check also assumed empty stderr and a 5,000-character stdout tail; the original launcher prints 3,000 characters and stderr contains four retained CUDA-driver/log-initialization messages. The final checks compare the actual recorded behavior and never delete these messages.

An attempted interactive tool session was unavailable; the five selected pytest tests were subsequently executed normally and passed.

The batch of four actual-record mutation comparisons exceeded the orchestration time limit after three completed cases. The fourth comparison was rerun separately on the same deliberately altered copy; it refused as expected. No production computation or valid bridge attempt was repeated for this reason. All original input ZIPs, notebooks, original scientific result files and source files remained unchanged.
